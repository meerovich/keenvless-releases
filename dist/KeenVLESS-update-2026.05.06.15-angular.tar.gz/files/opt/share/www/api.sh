#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
. /opt/etc/keenvless/keenvless.conf

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  post_body="$(dd bs=1 count="${CONTENT_LENGTH:-0}" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    if [ -n "$request_params" ]; then
      request_params="$request_params&$post_body"
    else
      request_params="$post_body"
    fi
  fi
fi

decode() {
  printf '%s' "$1" | sed 's/+/ /g;s/%2E/./Ig;s/%2D/-/Ig;s/%5F/_/Ig;s/%2F/\//Ig;s/%2C/,/Ig;s/%3A/:/Ig;s/%20/ /Ig;s/%2A/*/Ig;s/%24/$/Ig;s/%5B/[/Ig;s/%5D/]/Ig;s/%5C/\\/Ig;s/%7C/|/Ig;s/%3F/?/Ig;s/%2B/+/Ig;s/%3D/=/Ig;s/%5E/^/Ig;s/%7B/{/Ig;s/%7D/}/Ig'
}

param() {
  key="$1"
  printf '%s' "$request_params" | tr '&' '\n' | awk -F= -v k="$key" '$1 == k {print substr($0, length(k) + 2); exit}'
}

action="$(decode "$(param action)")"
token="$(decode "$(param token)")"
target="$(decode "$(param target)")"
token_required="$(decode "$(param token_required)")"
web_token="$(decode "$(param web_token)")"
remote_web_enabled="$(decode "$(param remote_web_enabled)")"
remote_web_port="$(decode "$(param remote_web_port)")"
remote_web_sources="$(decode "$(param remote_web_sources)")"
server="$(decode "$(param server)")"
client="$(decode "$(param client)")"
sources="$(decode "$(param sources)")"
proxy_sources="$(decode "$(param proxy_sources)")"
direct_sources="$(decode "$(param direct_sources)")"
ports="$(decode "$(param ports)")"
block_udp443="$(decode "$(param block_udp443)")"
proxy_domains="$(decode "$(param proxy_domains)")"
proxy_ips="$(decode "$(param proxy_ips)")"
direct_domains="$(decode "$(param direct_domains)")"
direct_ips="$(decode "$(param direct_ips)")"
favorites="$(decode "$(param favorites)")"
import_b64="$(decode "$(param import_b64)")"
manual_id="$(decode "$(param manual_id)")"
manual_name_b64="$(decode "$(param manual_name_b64)")"
manual_link_b64="$(decode "$(param manual_link_b64)")"
backup="$(decode "$(param backup)")"
router_id="$(decode "$(param router_id)")"
router_name_b64="$(decode "$(param router_name_b64)")"
router_url_b64="$(decode "$(param router_url_b64)")"
router_token_b64="$(decode "$(param router_token_b64)")"
router_local_name_b64="$(decode "$(param router_local_name_b64)")"
update_id="$(decode "$(param update_id)")"
update_version="$(decode "$(param update_version)")"
update_size="$(decode "$(param update_size)")"
update_sha256="$(decode "$(param update_sha256)")"
update_chunk_b64="$(decode "$(param update_chunk_b64)")"
github_tag="$(decode "$(param github_tag)")"
github_repo="$(decode "$(param github_repo)")"
github_token="$(decode "$(param github_token)")"
watchdog_enabled="$(decode "$(param watchdog_enabled)")"
watchdog_interval_min="$(decode "$(param watchdog_interval_min)")"
watchdog_probe_after_fails="$(decode "$(param watchdog_probe_after_fails)")"
watchdog_switch_after_fails="$(decode "$(param watchdog_switch_after_fails)")"
watchdog_candidate_count="$(decode "$(param watchdog_candidate_count)")"
watchdog_fallback_direct="$(decode "$(param watchdog_fallback_direct)")"
watchdog_restore_original="$(decode "$(param watchdog_restore_original)")"
mobile_watchdog_enabled="$(decode "$(param mobile_watchdog_enabled)")"
mobile_watchdog_interval_min="$(decode "$(param mobile_watchdog_interval_min)")"
mobile_watchdog_fail_min="$(decode "$(param mobile_watchdog_fail_min)")"
mobile_watchdog_usb_off_sec="$(decode "$(param mobile_watchdog_usb_off_sec)")"
mobile_watchdog_iface="$(decode "$(param mobile_watchdog_iface)")"
router_name=""
router_url=""
router_token=""
router_local_name=""
[ -n "$router_name_b64" ] && router_name="$(printf '%s' "$router_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_url_b64" ] && router_url="$(printf '%s' "$router_url_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_token_b64" ] && router_token="$(printf '%s' "$router_token_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_local_name_b64" ] && router_local_name="$(printf '%s' "$router_local_name_b64" | base64 -d 2>/dev/null || true)"

client_ip="${REMOTE_ADDR:-}"
if [ "$client_ip" = "127.0.0.1" ] || [ "$client_ip" = "::1" ]; then
  forwarded="${HTTP_X_FORWARDED_FOR:-${HTTP_X_REAL_IP:-}}"
  if [ -n "$forwarded" ]; then
    client_ip="$(printf '%s' "$forwarded" | sed 's/,.*//;s/[[:space:]]//g')"
  fi
fi
[ -n "$client_ip" ] || client_ip="${REMOTE_ADDR:-127.0.0.1}"

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

TOKEN_REQUIRED="${TOKEN_REQUIRED:-0}"
if [ "$TOKEN_REQUIRED" = "1" ] && [ "$token" != "${TOKEN:-}" ]; then
  printf '{"ok":false,"error":"unauthorized"}\n'
  exit 0
fi

if [ -n "$target" ] && [ "$target" != "local" ]; then
  case "$action" in
    router_targets|router_local_name|router_target_add|router_target_delete|router_target_test)
      ;;
    *)
      /opt/bin/keenvless router-proxy "$target" "$request_params"
      exit 0
      ;;
  esac
fi

case "$action" in
  status|"") /opt/bin/keenvless status ;;
  version) /opt/bin/keenvless version ;;
  list) /opt/bin/keenvless list ;;
  update) /opt/bin/keenvless update ;;
  scan) /opt/bin/keenvless scan ;;
  scan_current) /opt/bin/keenvless scan "$server" ;;
  scan_async) /opt/bin/keenvless scan-async "$server" ;;
  scan_status) /opt/bin/keenvless scan-status ;;
  watchdog) /opt/bin/keenvless watchdog ;;
  watchdog_status) /opt/bin/keenvless watchdog-status ;;
  set_watchdog) /opt/bin/keenvless set-watchdog "${watchdog_enabled:-0}" "${watchdog_interval_min:-5}" "${watchdog_probe_after_fails:-3}" "${watchdog_switch_after_fails:-6}" "${watchdog_candidate_count:-5}" "${watchdog_fallback_direct:-1}" "${watchdog_restore_original:-1}" ;;
  mobile_watchdog) /opt/bin/keenvless mobile-watchdog-now ;;
  mobile_watchdog_status) /opt/bin/keenvless mobile-watchdog-status ;;
  set_mobile_watchdog) /opt/bin/keenvless set-mobile-watchdog "${mobile_watchdog_enabled:-1}" "${mobile_watchdog_interval_min:-5}" "${mobile_watchdog_fail_min:-60}" "${mobile_watchdog_usb_off_sec:-10}" "${mobile_watchdog_iface:-auto}" ;;
  external_ip) /opt/bin/keenvless external-ip ;;
  manual_list) /opt/bin/keenvless manual-list ;;
  manual_add)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-add "$manual_name" "$manual_link"
    ;;
  manual_delete) /opt/bin/keenvless manual-delete "$manual_id" ;;
  install_auto) /opt/bin/keenvless install-auto ;;
  disable_auto) /opt/bin/keenvless disable-auto ;;
  clients) /opt/bin/keenvless clients ;;
  backup_config) /opt/bin/keenvless backup-config ;;
  backups) /opt/bin/keenvless backups ;;
  backup_preview) /opt/bin/keenvless backup-preview "$backup" ;;
  restore_backup) /opt/bin/keenvless restore-backup "$backup" ;;
  favorites) /opt/bin/keenvless favorites ;;
  set_favorites) /opt/bin/keenvless set-favorites "$favorites" ;;
  export_config) /opt/bin/keenvless export-config ;;
  import_config) /opt/bin/keenvless import-config-b64 "$import_b64" ;;
  logs) /opt/bin/keenvless logs ;;
  check_current) /opt/bin/keenvless check-current ;;
  whoami) printf '{"ok":true,"ip":"%s","remote_addr":"%s"}\n' "$client_ip" "$REMOTE_ADDR" ;;
  diagnostics) /opt/bin/keenvless diagnostics ;;
  self_test) /opt/bin/keenvless self-test ;;
  router_info) /opt/bin/keenvless router-info ;;
  update_status) /opt/bin/keenvless update-status ;;
  update_begin) /opt/bin/keenvless update-begin "$update_version" "$update_size" "$update_sha256" ;;
  update_chunk) /opt/bin/keenvless update-chunk "$update_id" "$update_chunk_b64" ;;
  update_apply) /opt/bin/keenvless update-apply "$update_id" ;;
  update_export) /opt/bin/keenvless update-export ;;
  update_github)
    id="github-$(date +%s)-$$"
    jq -n --arg id "$id" --arg tag "$github_tag" --arg repo "$github_repo" '{ok:true,state:"github_queued",id:$id,tag:$tag,repo:$repo}' > /opt/var/lib/keenvless/update-status.json 2>/dev/null || true
    ( /opt/bin/keenvless update-github "$github_tag" "$github_repo" "$github_token" >> /opt/var/log/keenvless-update.log 2>&1 ) &
    printf '{"ok":true,"state":"github_started","id":"%s"}\n' "$id"
    ;;
  github_probe) /opt/bin/keenvless github-probe "$github_tag" "$github_repo" ;;
  router_targets) /opt/bin/keenvless router-targets ;;
  router_local_name) /opt/bin/keenvless router-local-name "$router_local_name" ;;
  router_target_add) /opt/bin/keenvless router-target-add "$router_name" "$router_url" "$router_token" ;;
  router_target_delete) /opt/bin/keenvless router-target-delete "$router_id" ;;
  router_target_test) /opt/bin/keenvless router-target-test "${router_id:-local}" ;;
  bootstrap) /opt/bin/keenvless bootstrap ;;
  select) /opt/bin/keenvless select "$server" ;;
  enable|start) /opt/bin/keenvless enable ;;
  disable|stop) /opt/bin/keenvless disable ;;
  route_on) /opt/bin/keenvless route-on "${client:-$client_ip}" ;;
  route_off) /opt/bin/keenvless route-off "$client" ;;
  config) /opt/bin/keenvless config ;;
  set_config) /opt/bin/keenvless set-config "${sources:-$client_ip}" "${ports:-80,443}" "${block_udp443:-1}" "$proxy_sources" "$direct_sources" ;;
  set_dest_config) /opt/bin/keenvless set-dest-config "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  set_web_auth) /opt/bin/keenvless set-web-auth "${token_required:-0}" "$web_token" ;;
  set_remote_web) /opt/bin/keenvless set-remote-web "${remote_web_enabled:-0}" "${remote_web_port:-8088}" "$remote_web_sources" ;;
  apply_config) /opt/bin/keenvless route-on "${sources:-$client_ip}" ;;
  *) printf '{"ok":false,"error":"unknown action"}\n' ;;
esac
