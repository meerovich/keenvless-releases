(() => {
  if (window.__keenvlessEnhancer) return;
  window.__keenvlessEnhancer = true;

  const token = new URL(location.href).searchParams.get("token") || "";
  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (value) => String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const b64 = (value) => btoa(unescape(encodeURIComponent(value)));
  const short = (value, max = 80) => {
    const text = String(value ?? "");
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
  };

  function xhrPost(body, timeoutMs) {
    return new Promise((resolve) => {
      if (typeof XMLHttpRequest !== "function") {
        resolve({ ok: false, error: "fetch/XMLHttpRequest is not available" });
        return;
      }
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "api.sh", true);
      xhr.timeout = timeoutMs;
      xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
      xhr.onload = () => resolve({ ok: true, status: xhr.status, text: xhr.responseText || "" });
      xhr.onerror = () => resolve({ ok: false, error: "xhr network error" });
      xhr.ontimeout = () => resolve({ ok: false, error: "xhr timeout" });
      xhr.send(body);
    });
  }

  async function api(params, timeoutMs = 120000) {
    try {
      const body = new URLSearchParams({ token, ...params });
      let text = "";
      let status = 0;
      if (typeof fetch === "function" && typeof AbortController === "function") {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
          const resp = await fetch("api.sh", {
            method: "POST",
            headers: { "content-type": "application/x-www-form-urlencoded" },
            body,
            signal: ctrl.signal
          });
          status = resp.status;
          text = await resp.text();
        } finally {
          clearTimeout(timer);
        }
      } else {
        const xhr = await xhrPost(body.toString(), timeoutMs);
        if (!xhr.ok) return xhr;
        status = xhr.status;
        text = xhr.text;
      }
      try {
        return JSON.parse(text);
      } catch {
        return { ok: false, status, text: text.slice(0, 1000) };
      }
    } catch (err) {
      return { ok: false, error: err?.message || String(err) };
    }
  }

  const css = `
    .kvx-fab{position:fixed;right:14px;bottom:14px;z-index:2000;border:1px solid var(--line-strong,#c3ced8);border-radius:999px;background:var(--panel,#fff);color:var(--text,#17212b);box-shadow:0 8px 24px #0003;min-height:42px;padding:0 14px;font:600 13px Inter,system-ui,sans-serif;cursor:pointer}
    .kvx-fab.ok{border-color:#1e665480}.kvx-fab.warn{border-color:#a66a0080}.kvx-fab.fail{border-color:#a9343480}
    .kvx-backdrop{position:fixed;inset:0;z-index:2001;background:#0005;display:none}.kvx-backdrop.open{display:block}
    .kvx-panel{position:fixed;right:10px;bottom:62px;z-index:2002;width:min(920px,calc(100vw - 20px));max-height:calc(100vh - 84px);overflow:auto;border:1px solid var(--line-strong,#c3ced8);border-radius:14px;background:var(--panel,#fff);color:var(--text,#17212b);box-shadow:0 14px 44px #0005;padding:14px;font:13px Inter,system-ui,sans-serif;display:none}
    .kvx-panel.open{display:block}.kvx-head{display:flex;justify-content:space-between;gap:10px;align-items:start;margin-bottom:10px}.kvx-head h3{margin:0;font-size:17px}.kvx-head p{margin:4px 0 0;color:var(--muted,#5f7080)}
    .kvx-actions,.kvx-row-actions{display:flex;flex-wrap:wrap;gap:6px}.kvx-btn{border:1px solid var(--line-strong,#c3ced8);border-radius:8px;background:var(--panel-soft,#f8fafc);color:var(--text,#17212b);min-height:32px;padding:0 10px;cursor:pointer}.kvx-btn.primary{background:var(--brand,#0b5cad);border-color:var(--brand,#0b5cad);color:#fff}.kvx-btn.danger{border-color:#a9343480;color:#a93434}.kvx-btn:disabled{opacity:.55;cursor:progress}
    .kvx-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));gap:8px;margin:10px 0}.kvx-card{border:1px solid var(--line,#d8e0e8);border-radius:10px;background:var(--panel-soft,#f8fafc);padding:10px;display:grid;gap:5px}.kvx-card b{font-size:13px}.kvx-card span,.kvx-card em{color:var(--muted,#5f7080);font-style:normal;overflow-wrap:anywhere}
    .kvx-tag{display:inline-flex;align-items:center;min-height:24px;border-radius:999px;border:1px solid var(--line-strong,#c3ced8);padding:0 8px;color:var(--muted,#5f7080);background:var(--panel,#fff);font-size:12px}.kvx-tag.ok{border-color:#1e665480;color:#1e6654}.kvx-tag.warn{border-color:#a66a0080;color:#a66a00}.kvx-tag.fail{border-color:#a9343480;color:#a93434}.kvx-tag.hy2{border-color:#0b5cad80;color:#0b5cad}
    .kvx-table{display:grid;gap:6px}.kvx-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;border:1px solid var(--line,#d8e0e8);border-radius:9px;background:var(--panel-soft,#f8fafc);padding:8px}.kvx-row.active{border-color:var(--brand,#0b5cad);box-shadow:inset 0 0 0 1px #0b5cad80}.kvx-row.fail{border-color:#a9343480}.kvx-row.warn{border-color:#a66a0080}.kvx-row-main{display:grid;gap:3px;min-width:0}.kvx-row-main strong,.kvx-row-main span{overflow-wrap:anywhere}.kvx-muted{color:var(--muted,#5f7080)}.kvx-form{display:grid;gap:8px;margin-top:10px}.kvx-form input,.kvx-form textarea,.kvx-script{width:100%;border:1px solid var(--line-strong,#c3ced8);border-radius:8px;background:var(--panel,#fff);color:var(--text,#17212b);padding:8px;font:inherit}.kvx-form textarea{min-height:88px;resize:vertical}.kvx-script{box-sizing:border-box;min-height:180px;white-space:pre;font:12px ui-monospace,SFMono-Regular,Consolas,monospace}.kvx-script.small{min-height:120px}.kvx-textgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(280px,100%),1fr));gap:8px;margin-top:8px}.kvx-textgrid label{display:grid;gap:5px;color:var(--muted,#5f7080)}.kvx-log{margin-top:10px;border:1px solid var(--line,#d8e0e8);border-radius:9px;background:var(--panel-soft,#f8fafc);padding:8px;white-space:pre-wrap;max-height:160px;overflow:auto;color:var(--muted,#5f7080)}
    @media(max-width:720px){.kvx-panel{left:8px;right:8px;bottom:58px;width:auto}.kvx-row{grid-template-columns:1fr}.kvx-row-actions{justify-content:stretch}.kvx-row-actions .kvx-btn{flex:1}}
  `;

  let panel;
  let fab;
  let state = { busy: false, data: null, profileById: {}, refreshPromise: null, lastRefreshAt: 0 };

  function setBusy(busy) {
    state.busy = busy;
    document.querySelectorAll(".kvx-btn").forEach((btn) => { btn.disabled = busy; });
    if (fab) fab.textContent = busy ? "VPN…" : "VPN / Профили";
  }

  function renderLoading(message = "Загружаю данные пульта…") {
    if (!panel) return;
    panel.innerHTML = `
      <div class="kvx-head">
        <div>
          <h3>VPN / Профили</h3>
          <p>Безопасное управление профилями поверх текущей панели.</p>
        </div>
        <div class="kvx-actions">
          <button class="kvx-btn" data-kvx="close">Закрыть</button>
        </div>
      </div>
      <div class="kvx-card">
        <b>Загрузка</b>
        <span>${esc(message)}</span>
        <em>Запросы идут ограниченной очередью, чтобы не перегружать KeenDNS/CGI.</em>
      </div>
    `;
  }

  async function runLimited(tasks, limit = 2) {
    const results = {};
    let next = 0;
    const workers = Array.from({ length: Math.min(limit, tasks.length) }, async () => {
      while (next < tasks.length) {
        const task = tasks[next++];
        try {
          results[task.key] = await task.run();
        } catch (err) {
          results[task.key] = { ok: false, error: err?.message || String(err) };
        }
      }
    });
    await Promise.all(workers);
    return results;
  }

  function checkTag(stateName) {
    const name = stateName || "warn";
    return `<span class="kvx-tag ${esc(name)}">${esc(name)}</span>`;
  }

  function doctorRows(doctor) {
    const checks = Array.isArray(doctor?.checks) ? doctor.checks : [];
    const visible = checks
      .filter((c) => c.state === "fail" || c.state === "warn")
      .slice(0, 12);
    if (!visible.length) {
      return '<div class="kvx-muted">Критичных замечаний doctor не видит.</div>';
    }
    return visible.map((c) => `
      <div class="kvx-row ${esc(c.state)}">
        <div class="kvx-row-main">
          <strong>${checkTag(c.state)} ${esc(c.label || c.id)}</strong>
          <span>${esc(c.detail || "")}</span>
          <em>${esc(c.fix || "")}</em>
        </div>
      </div>
    `).join("");
  }

  function profileName(profile) {
    return profile?.name || profile?.name_ru || profile?.name_en || profile?.id || "—";
  }

  function profilePriority(profile) {
    if (profile?.active) return 0;
    if (profile?.health === "ok") return 1;
    if (profile?.source === "manual" || profile?.protocol === "hysteria2") return 2;
    if (profile?.health === "manual" || profile?.health === "unknown" || !profile?.health) return 3;
    return 4;
  }

  function profileDetails(profile) {
    return [
      profile?.source === "provider" ? `id=${profile.id}` : "",
      profile?.source === "provider" ? "provider" : "manual",
      profile?.user && `user=${profile.user}`,
      profile?.server,
      profile?.sni && `sni=${profile.sni}`,
      profile?.obfs && `obfs=${profile.obfs}`,
      profile?.pin_present ? "pin" : "",
      profile?.latency_ms !== null && profile?.latency_ms !== undefined && profile?.latency_ms !== "" && Number.isFinite(Number(profile.latency_ms)) ? `${profile.latency_ms} ms` : ""
    ].filter(Boolean).join(" · ");
  }

  function sortedProfiles(profiles) {
    return (profiles || []).slice()
      .sort((a, b) => profilePriority(a) - profilePriority(b)
        || Number(a.latency_ms ?? 999999) - Number(b.latency_ms ?? 999999)
        || profileName(a).localeCompare(profileName(b), "ru"))
      .slice(0, 80);
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.left = "-9999px";
    document.body.appendChild(area);
    area.focus();
    area.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { ok = false; }
    area.remove();
    return ok;
  }

  function downloadText(filename, text) {
    const blob = new Blob([text], { type: "text/x-shellscript;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function render(data, message = "") {
    const selected = data.profiles?.selected_profile || {};
    const health = data.health || {};
    const doctor = data.doctor || {};
    const bootstrap = data.bootstrap || {};
    const rescue = data.rescue || {};
    const rescueState = rescue.status?.status || rescue.status || {};
    const rescueTopology = rescue.status?.topology || {};
    const rescueArtifacts = rescue.artifacts || {};
    const checks = data.hy?.checks || [];
    const profiles = sortedProfiles(data.profiles?.profiles || []);
    const duplicateUsers = data.profiles?.duplicate_hysteria_users || [];
    const healthClass = health.ok && doctor.ok !== false ? "ok" : "fail";
    const doctorSummary = doctor.summary || {};
    const bootstrapScript = bootstrap.script || "";
    fab.className = `kvx-fab ${healthClass}`;

    panel.innerHTML = `
      <div class="kvx-head">
        <div>
          <h3>VPN / Профили</h3>
          <p>Безопасное переключение provider VLESS и manual HY2/VLESS поверх текущей панели.</p>
        </div>
        <div class="kvx-actions">
          <button class="kvx-btn" data-kvx="refresh">Обновить</button>
          <button class="kvx-btn" data-kvx="health">Health</button>
          <button class="kvx-btn" data-kvx="close">Закрыть</button>
        </div>
      </div>
      <div class="kvx-grid">
        <article class="kvx-card">
          <b>Активный профиль</b>
          <span>${esc(selected.name || data.status?.selected || "—")}</span>
          <div><span class="kvx-tag ${selected.protocol === "hysteria2" ? "hy2" : ""}">${esc(selected.display_protocol || selected.protocol || "—")}</span> ${selected.active ? '<span class="kvx-tag ok">selected</span>' : ""}</div>
          <em>${esc([selected.user && `user=${selected.user}`, selected.server, selected.sni && `sni=${selected.sni}`, selected.obfs && `obfs=${selected.obfs}`, selected.pin_present ? "pin" : ""].filter(Boolean).join(" · ") || "metadata нет")}</em>
        </article>
        <article class="kvx-card">
          <b>Health</b>
          <span>${checkTag(health.overall || (health.ok ? "ok" : "warn"))} checks=${esc(health.summary?.checks ?? "—")} fail=${esc(health.summary?.fails ?? "—")} warn=${esc(health.summary?.warns ?? "—")}</span>
          <em>check_current: ${esc(data.current?.ok ? "ok" : "—")} ${esc(data.current?.ip || "")} ${esc(data.current?.youtube || "")}</em>
        </article>
        <article class="kvx-card">
          <b>HY2 диагностика</b>
          <span>${checks.map((c) => `${esc(c.id)}:${esc(c.state)}`).join(" · ") || "—"}</span>
          <em>${duplicateUsers.length ? `Дубликаты HY2 users: ${duplicateUsers.map((d) => `${d.user}×${d.count}`).join(", ")}` : "Дубликатов HY2 users нет"}</em>
        </article>
        <article class="kvx-card">
          <b>Окружение / Doctor</b>
          <span>${checkTag(doctor.ok === false ? "fail" : (doctorSummary.warn ? "warn" : "ok"))} checks=${esc(doctorSummary.checks ?? "—")} fail=${esc(doctorSummary.fail ?? "—")} warn=${esc(doctorSummary.warn ?? "—")}</span>
          <em>/opt free: ${esc(doctor.storage?.opt_free_kb ?? "—")}K · bootstrap=${esc(bootstrap.version || "—")}</em>
        </article>
        <article class="kvx-card">
          <b>Rescue VPN</b>
          <span>${checkTag(rescue.ok ? (rescueState.behind_nat ? "warn" : "ok") : "fail")} WAN=${esc(rescueState.wan_ip || "—")} ${esc(rescueState.wan_class || "")}</span>
          <em>${esc(rescueTopology.vps || "—")}:${esc(rescueTopology.port || "—")} · LAN ${esc(rescueTopology.home_lan || rescueState.home_lan || "—")}</em>
        </article>
      </div>
      <h4>Окружение / Bootstrap</h4>
      <div class="kvx-actions">
        <button class="kvx-btn" data-kvx="doctor">Doctor</button>
        <button class="kvx-btn" data-kvx="bootstrap-copy" ${bootstrapScript ? "" : "disabled"}>Скопировать bootstrap</button>
        <button class="kvx-btn" data-kvx="bootstrap-download" ${bootstrapScript ? "" : "disabled"}>Скачать bootstrap.sh</button>
      </div>
      <div class="kvx-table" style="margin-top:8px">${doctorRows(doctor)}</div>
      <textarea class="kvx-script" readonly>${esc(bootstrapScript)}</textarea>
      <h4>Rescue VPN / WireGuard</h4>
      <div class="kvx-actions">
        <button class="kvx-btn" data-kvx="rescue-refresh">Обновить rescue</button>
        <button class="kvx-btn primary" data-kvx="rescue-copy-vps_script" ${rescueArtifacts.vps_script ? "" : "disabled"}>Скопировать VPS script</button>
        <button class="kvx-btn" data-kvx="rescue-download-vps_script" ${rescueArtifacts.vps_script ? "" : "disabled"}>Скачать VPS script</button>
        <button class="kvx-btn" data-kvx="rescue-copy-router_template" ${rescueArtifacts.router_template ? "" : "disabled"}>Router template</button>
        <button class="kvx-btn" data-kvx="rescue-download-router_template" ${rescueArtifacts.router_template ? "" : "disabled"}>Скачать router</button>
        <button class="kvx-btn" data-kvx="rescue-copy-operator_template" ${rescueArtifacts.operator_template ? "" : "disabled"}>Operator template</button>
        <button class="kvx-btn" data-kvx="rescue-download-operator_template" ${rescueArtifacts.operator_template ? "" : "disabled"}>Скачать operator</button>
        <button class="kvx-btn" data-kvx="rescue-download-readme" ${rescueArtifacts.readme ? "" : "disabled"}>README</button>
      </div>
      <div class="kvx-grid">
        <article class="kvx-card">
          <b>Что делает</b>
          <span>Read-only генератор: пульт ничего не применяет сам.</span>
          <em>${esc(rescue.status?.recommendation?.reason || "Сначала генерируем артефакты, apply — отдельной безопасной фазой.")}</em>
        </article>
        <article class="kvx-card">
          <b>Топология</b>
          <span>VPS ${esc(rescueTopology.vps || "—")}:${esc(rescueTopology.port || "—")} · сеть ${esc(rescueTopology.network || "—")}</span>
          <em>Keenetic ${esc(rescueTopology.router_addr || "—")} · operator ${esc(rescueTopology.operator_addr || "—")}</em>
        </article>
      </div>
      <div class="kvx-textgrid">
        <label>VPS setup script<textarea class="kvx-script small" readonly>${esc(rescueArtifacts.vps_script || "")}</textarea></label>
        <label>Keenetic router template<textarea class="kvx-script small" readonly>${esc(rescueArtifacts.router_template || "")}</textarea></label>
        <label>Operator client template<textarea class="kvx-script small" readonly>${esc(rescueArtifacts.operator_template || "")}</textarea></label>
      </div>
      <h4>VPN-профили</h4>
      <div class="kvx-table">
        ${profiles.map((p) => `
          <div class="kvx-row ${p.active ? "active" : ""}" data-id="${esc(p.id)}">
            <div class="kvx-row-main">
              <strong>${esc(profileName(p))}</strong>
              <span><span class="kvx-tag ${p.protocol === "hysteria2" ? "hy2" : ""}">${esc(p.display_protocol || p.protocol)}</span> ${esc(profileDetails(p))}</span>
              <em>${esc(p.health || "manual")} ${p.checked_at ? `· checked ${p.checked_at}` : ""}</em>
            </div>
            <div class="kvx-row-actions">
              <button class="kvx-btn" data-kvx="${p.source === "manual" ? "test" : "scan-profile"}" data-id="${esc(p.id)}">Проверить</button>
              <button class="kvx-btn primary" data-kvx="select" data-id="${esc(p.id)}" ${p.active ? "disabled" : ""}>Выбрать</button>
              ${p.source === "manual" ? `
                <button class="kvx-btn" data-kvx="rename" data-id="${esc(p.id)}">Имя</button>
                <button class="kvx-btn" data-kvx="duplicate" data-id="${esc(p.id)}">Копия</button>
                <button class="kvx-btn danger" data-kvx="delete" data-id="${esc(p.id)}" ${p.active ? 'disabled title="Нельзя удалить активный профиль"' : ""}>Удалить</button>
              ` : ""}
            </div>
          </div>
        `).join("") || '<div class="kvx-muted">Профили пока не загружены.</div>'}
      </div>
      <div class="kvx-form">
        <h4>Добавить HY2/VLESS ссылку</h4>
        <input class="kvx-name" placeholder="Название, например HEL-user3 HY2">
        <textarea class="kvx-link" placeholder="hysteria2://... или vless://..."></textarea>
        <div class="kvx-actions">
          <button class="kvx-btn" data-kvx="test-new">Проверить ссылку</button>
          <button class="kvx-btn primary" data-kvx="add-new">Добавить</button>
        </div>
      </div>
      <pre class="kvx-log">${esc(message)}</pre>
    `;
    setBusy(false);
  }

  async function refresh(message = "", options = {}) {
    if (state.refreshPromise) return state.refreshPromise;
    state.refreshPromise = (async () => {
      setBusy(true);
      if (!state.data) renderLoading(message || "Первичная загрузка…");
      const tasks = [
        { key: "version", run: () => api({ action: "version" }, 60000) },
        { key: "status", run: () => api({ action: "status" }, 60000) },
        { key: "profiles", run: () => api({ action: "profiles" }, 90000) },
        { key: "manualList", run: () => api({ action: "manual_list" }, 60000) },
        { key: "bootstrap", run: () => api({ action: "bootstrap_script" }, 60000) },
        { key: "doctor", run: () => api({ action: "dependency_doctor" }, 120000) },
        { key: "rescue", run: () => api({ action: "rescue_wireguard" }, 90000) },
        { key: "health", run: () => api({ action: "health_report" }, 180000) }
      ];
      const data = await runLimited(tasks, options.limit || 2);
      const health = data.health || {};
      const hy = health.hysteria_diagnostics || { ok: false, skipped: true, reason: "from health_report unavailable" };
      const current = health.current_server || { ok: false, skipped: true, reason: "from health_report unavailable" };
      const manualList = Array.isArray(data.manualList) ? data.manualList : [];
      const manualMap = {};
      manualList.forEach((item) => { manualMap[item.id] = item; });
      const profileList = Array.isArray(data.profiles?.profiles) ? data.profiles.profiles : [];
      state.profileById = {};
      profileList.forEach((item) => { state.profileById[item.id] = { ...item, ...(manualMap[item.id] || {}) }; });
      manualList.forEach((item) => { if (!state.profileById[item.id]) state.profileById[item.id] = item; });
      state.data = {
        version: data.version || {},
        status: data.status || {},
        profiles: data.profiles || {},
        hy,
        health,
        current,
        manualList,
        doctor: data.doctor || {},
        bootstrap: data.bootstrap || {},
        rescue: data.rescue || {}
      };
      state.lastRefreshAt = Date.now();
      const failures = Object.entries(data).filter(([, value]) => value && value.ok === false).map(([key]) => key);
      const suffix = failures.length ? `\nЧасть запросов не ответила: ${failures.join(", ")}` : "";
      render(state.data, (message || `version=${state.data.version.version || "?"}`) + suffix);
      return state.data;
    })().catch((err) => {
      const data = state.data || {};
      render(data, `Ошибка refresh: ${err?.message || String(err)}`);
      return data;
    }).finally(() => {
      state.refreshPromise = null;
      setBusy(false);
    });
    return state.refreshPromise;
  }

  async function handleAction(action, target) {
    const id = target.getAttribute("data-id");
    const item = id ? state.profileById[id] : null;
    if (action === "close") {
      panel.classList.remove("open");
      $(".kvx-backdrop")?.classList.remove("open");
      return;
    }
    if (action === "refresh") return refresh("Обновлено");
    if (action === "health") return refresh("Health обновлён");
    if (action === "doctor") return refresh("Dependency doctor обновлён");
    if (action === "rescue-refresh") return refresh("Rescue VPN обновлён");
    if (action.startsWith("rescue-copy-") || action.startsWith("rescue-download-")) {
      const download = action.startsWith("rescue-download-");
      const key = action.replace(download ? "rescue-download-" : "rescue-copy-", "");
      const text = state.data?.rescue?.artifacts?.[key] || "";
      const filename = state.data?.rescue?.filenames?.[key] || `${key}.txt`;
      if (!text) return render(state.data || {}, "Rescue artifact пуст.");
      if (download) {
        downloadText(filename, text);
        return render(state.data || {}, `Скачан ${filename}`);
      }
      const ok = await copyText(text);
      return render(state.data || {}, ok ? `Скопирован ${filename}` : "Не смог скопировать автоматически; выдели textarea вручную.");
    }
    if (action === "bootstrap-copy") {
      const script = state.data?.bootstrap?.script || $(".kvx-script", panel)?.value || "";
      if (!script) return render(state.data || {}, "Bootstrap script пуст.");
      const ok = await copyText(script);
      return render(state.data || {}, ok ? "Bootstrap script скопирован." : "Не смог скопировать автоматически; выдели textarea вручную.");
    }
    if (action === "bootstrap-download") {
      const script = state.data?.bootstrap?.script || $(".kvx-script", panel)?.value || "";
      if (!script) return render(state.data || {}, "Bootstrap script пуст.");
      downloadText(`keenvless-bootstrap-${state.data?.bootstrap?.version || "latest"}.sh`, script);
      return render(state.data || {}, "Bootstrap script скачан.");
    }
    if (action === "test" && item?.link) {
      setBusy(true);
      const res = await api({ action: "manual_test", manual_link_b64: b64(item.link) }, 90000);
      return refresh(`manual_test ${item.name_ru || item.name_en || id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "scan-profile" && id) {
      setBusy(true);
      const res = await api({ action: "scan_current", server: id }, 120000);
      return refresh(`scan ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "select" && id) {
      if (!confirm(`Переключить на ${profileName(item)}? Select делает реальную проверку и откат при ошибке.`)) return;
      setBusy(true);
      const res = await api({ action: "select", server: id }, 150000);
      return refresh(`select ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "rename" && id) {
      const name = prompt("Новое название профиля", item?.name_ru || item?.name_en || "");
      if (!name) return;
      setBusy(true);
      const res = await api({ action: "manual_rename", manual_id: id, manual_name_b64: b64(name) }, 60000);
      return refresh(`rename ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "duplicate" && id) {
      const name = prompt("Название копии", `${item?.name_ru || item?.name_en || "Manual"} copy`);
      if (name === null) return;
      setBusy(true);
      const res = await api({ action: "manual_duplicate", manual_id: id, manual_name_b64: b64(name) }, 60000);
      return refresh(`duplicate ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "delete" && id) {
      if (item?.active) return refresh("Активный профиль не удаляю: сначала выбери другой и дождись успешной проверки.");
      if (!confirm(`Удалить профиль ${item?.name_ru || item?.name_en || id}?`)) return;
      setBusy(true);
      const res = await api({ action: "manual_delete", manual_id: id }, 60000);
      return refresh(`delete ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "test-new" || action === "add-new") {
      const name = $(".kvx-name", panel)?.value?.trim() || "";
      const link = $(".kvx-link", panel)?.value?.trim() || "";
      if (!link) return render(state.data || {}, "Сначала вставь ссылку.");
      setBusy(true);
      const test = await api({ action: "manual_test", manual_link_b64: b64(link) }, 90000);
      if (!test.ok || action === "test-new") return refresh(`manual_test new:\n${JSON.stringify(test, null, 2)}`);
      const add = await api({ action: "manual_add", manual_name_b64: b64(name), manual_link_b64: b64(link) }, 60000);
      return refresh(`manual_add:\n${JSON.stringify(add, null, 2)}`);
    }
  }

  function mount() {
    const style = document.createElement("style");
    style.textContent = css;
    document.head.appendChild(style);

    const backdrop = document.createElement("div");
    backdrop.className = "kvx-backdrop";
    document.body.appendChild(backdrop);

    panel = document.createElement("section");
    panel.className = "kvx-panel";
    document.body.appendChild(panel);

    fab = document.createElement("button");
    fab.className = "kvx-fab";
    fab.type = "button";
    fab.textContent = "VPN / Профили";
    document.body.appendChild(fab);

    fab.addEventListener("click", async () => {
      panel.classList.toggle("open");
      backdrop.classList.toggle("open", panel.classList.contains("open"));
      if (panel.classList.contains("open")) {
        const stale = Date.now() - (state.lastRefreshAt || 0) > 120000;
        if (!state.data || stale) await refresh();
        else render(state.data, `version=${state.data.version?.version || "?"}`);
      }
    });
    backdrop.addEventListener("click", () => handleAction("close", backdrop));
    panel.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-kvx]");
      if (!btn) return;
      event.preventDefault();
      handleAction(btn.getAttribute("data-kvx"), btn);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount, { once: true });
  } else {
    mount();
  }
})();
