#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
. /opt/etc/keenvless/keenvless.conf

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  post_body="$(dd bs=1 count="${CONTENT_LENGTH:-0}" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    if [ -n "$request_params" ]; then
      request_params="$request_params&$post_body"
    else
      request_params="$post_body"
    fi
  fi
fi

decode() {
  printf '%s' "$1" | sed 's/+/ /g;s/%2E/./Ig;s/%2D/-/Ig;s/%5F/_/Ig;s/%2F/\//Ig;s/%2C/,/Ig;s/%3A/:/Ig;s/%20/ /Ig;s/%2A/*/Ig;s/%24/$/Ig;s/%5B/[/Ig;s/%5D/]/Ig;s/%5C/\\/Ig;s/%7C/|/Ig;s/%3F/?/Ig;s/%2B/+/Ig;s/%3D/=/Ig;s/%5E/^/Ig;s/%7B/{/Ig;s/%7D/}/Ig'
}

param() {
  key="$1"
  printf '%s' "$request_params" | tr '&' '\n' | awk -F= -v k="$key" '$1 == k {print substr($0, length(k) + 2); exit}'
}

action="$(decode "$(param action)")"
token="$(decode "$(param token)")"
target="$(decode "$(param target)")"
token_required="$(decode "$(param token_required)")"
web_token="$(decode "$(param web_token)")"
remote_web_enabled="$(decode "$(param remote_web_enabled)")"
remote_web_port="$(decode "$(param remote_web_port)")"
remote_web_sources="$(decode "$(param remote_web_sources)")"
server="$(decode "$(param server)")"
select_id="$(decode "$(param select_id)")"
client="$(decode "$(param client)")"
sources="$(decode "$(param sources)")"
proxy_sources="$(decode "$(param proxy_sources)")"
direct_sources="$(decode "$(param direct_sources)")"
ports="$(decode "$(param ports)")"
block_udp443="$(decode "$(param block_udp443)")"
proxy_domains="$(decode "$(param proxy_domains)")"
proxy_ips="$(decode "$(param proxy_ips)")"
direct_domains="$(decode "$(param direct_domains)")"
direct_ips="$(decode "$(param direct_ips)")"
destination="$(decode "$(param destination)")"
route_destinations="$(decode "$(param route_destinations)")"
health_client="$(decode "$(param health_client)")"
route_profile="$(decode "$(param route_profile)")"
route_scenario="$(decode "$(param route_scenario)")"
client_mode="$(decode "$(param client_mode)")"
group_id="$(decode "$(param group_id)")"
group_mode="$(decode "$(param group_mode)")"
group_name_b64="$(decode "$(param group_name_b64)")"
group_members="$(decode "$(param group_members)")"
rule_apply_dest="$(decode "$(param rule_apply_dest)")"
preset_id="$(decode "$(param preset_id)")"
preset_name_b64="$(decode "$(param preset_name_b64)")"
server_group="$(decode "$(param server_group)")"
event_kind="$(decode "$(param event_kind)")"
favorites="$(decode "$(param favorites)")"
import_b64="$(decode "$(param import_b64)")"
rules_b64="$(decode "$(param rules_b64)")"
manual_id="$(decode "$(param manual_id)")"
manual_name_b64="$(decode "$(param manual_name_b64)")"
manual_link_b64="$(decode "$(param manual_link_b64)")"
backup="$(decode "$(param backup)")"
router_id="$(decode "$(param router_id)")"
sync_from="$(decode "$(param sync_from)")"
sync_to="$(decode "$(param sync_to)")"
router_name_b64="$(decode "$(param router_name_b64)")"
router_url_b64="$(decode "$(param router_url_b64)")"
router_token_b64="$(decode "$(param router_token_b64)")"
router_local_name_b64="$(decode "$(param router_local_name_b64)")"
update_id="$(decode "$(param update_id)")"
update_version="$(decode "$(param update_version)")"
update_size="$(decode "$(param update_size)")"
update_sha256="$(decode "$(param update_sha256)")"
update_offset="$(decode "$(param update_offset)")"
update_chunk_sha256="$(decode "$(param update_chunk_sha256)")"
update_chunk_b64="$(decode "$(param update_chunk_b64)")"
github_tag="$(decode "$(param github_tag)")"
github_repo="$(decode "$(param github_repo)")"
github_token="$(decode "$(param github_token)")"
watchdog_enabled="$(decode "$(param watchdog_enabled)")"
watchdog_interval_min="$(decode "$(param watchdog_interval_min)")"
watchdog_probe_after_fails="$(decode "$(param watchdog_probe_after_fails)")"
watchdog_switch_after_fails="$(decode "$(param watchdog_switch_after_fails)")"
watchdog_candidate_count="$(decode "$(param watchdog_candidate_count)")"
watchdog_switch_cooldown_min="$(decode "$(param watchdog_switch_cooldown_min)")"
watchdog_fallback_direct="$(decode "$(param watchdog_fallback_direct)")"
watchdog_restore_original="$(decode "$(param watchdog_restore_original)")"
watchdog_quarantine_min="$(decode "$(param watchdog_quarantine_min)")"
watchdog_restore_ok_count="$(decode "$(param watchdog_restore_ok_count)")"
watchdog_flap_window_min="$(decode "$(param watchdog_flap_window_min)")"
watchdog_max_switches_window="$(decode "$(param watchdog_max_switches_window)")"
mobile_watchdog_enabled="$(decode "$(param mobile_watchdog_enabled)")"
mobile_watchdog_interval_min="$(decode "$(param mobile_watchdog_interval_min)")"
mobile_watchdog_fail_min="$(decode "$(param mobile_watchdog_fail_min)")"
mobile_watchdog_usb_off_sec="$(decode "$(param mobile_watchdog_usb_off_sec)")"
mobile_watchdog_iface="$(decode "$(param mobile_watchdog_iface)")"
dns_monitor_enabled="$(decode "$(param dns_monitor_enabled)")"
dns_monitor_interval_min="$(decode "$(param dns_monitor_interval_min)")"
dns_monitor_hosts="$(decode "$(param dns_monitor_hosts)")"
router_name=""
router_url=""
router_token=""
router_local_name=""
[ -n "$router_name_b64" ] && router_name="$(printf '%s' "$router_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_url_b64" ] && router_url="$(printf '%s' "$router_url_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_token_b64" ] && router_token="$(printf '%s' "$router_token_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_local_name_b64" ] && router_local_name="$(printf '%s' "$router_local_name_b64" | base64 -d 2>/dev/null || true)"
preset_name=""
[ -n "$preset_name_b64" ] && preset_name="$(printf '%s' "$preset_name_b64" | base64 -d 2>/dev/null || true)"
group_name=""
[ -n "$group_name_b64" ] && group_name="$(printf '%s' "$group_name_b64" | base64 -d 2>/dev/null || true)"

client_ip="${REMOTE_ADDR:-}"
if [ "$client_ip" = "127.0.0.1" ] || [ "$client_ip" = "::1" ]; then
  forwarded="${HTTP_X_FORWARDED_FOR:-${HTTP_X_REAL_IP:-}}"
  if [ -n "$forwarded" ]; then
    client_ip="$(printf '%s' "$forwarded" | sed 's/,.*//;s/[[:space:]]//g')"
  fi
fi
[ -n "$client_ip" ] || client_ip="${REMOTE_ADDR:-127.0.0.1}"

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

TOKEN_REQUIRED="${TOKEN_REQUIRED:-0}"
if [ "$TOKEN_REQUIRED" = "1" ] && [ "$token" != "${TOKEN:-}" ]; then
  printf '{"ok":false,"error":"unauthorized"}\n'
  exit 0
fi

if [ -n "$target" ] && [ "$target" != "local" ]; then
  case "$action" in
    router_targets|router_local_name|router_target_add|router_target_delete|router_target_test)
      ;;
    *)
      /opt/bin/keenvless router-proxy "$target" "$request_params"
      exit 0
      ;;
  esac
fi

case "$action" in
  status|"") /opt/bin/keenvless status ;;
  version) /opt/bin/keenvless version ;;
  list) /opt/bin/keenvless list ;;
  update) /opt/bin/keenvless update ;;
  scan) /opt/bin/keenvless scan ;;
  scan_current) /opt/bin/keenvless scan "$server" ;;
  scan_async) /opt/bin/keenvless scan-async "$server" ;;
  scan_status) /opt/bin/keenvless scan-status ;;
  watchdog) /opt/bin/keenvless watchdog ;;
  watchdog_status) /opt/bin/keenvless watchdog-status ;;
  watchdog_candidates) /opt/bin/keenvless watchdog-candidates ;;
  route_guard) /opt/bin/keenvless route-guard ;;
  set_watchdog) /opt/bin/keenvless set-watchdog "${watchdog_enabled:-0}" "${watchdog_interval_min:-5}" "${watchdog_probe_after_fails:-3}" "${watchdog_switch_after_fails:-6}" "${watchdog_candidate_count:-5}" "${watchdog_switch_cooldown_min:-15}" "${watchdog_fallback_direct:-1}" "${watchdog_restore_original:-1}" "${watchdog_quarantine_min:-30}" "${watchdog_restore_ok_count:-2}" "${watchdog_flap_window_min:-60}" "${watchdog_max_switches_window:-3}" ;;
  mobile_watchdog) /opt/bin/keenvless mobile-watchdog-now ;;
  mobile_watchdog_status) /opt/bin/keenvless mobile-watchdog-status ;;
  set_mobile_watchdog) /opt/bin/keenvless set-mobile-watchdog "${mobile_watchdog_enabled:-1}" "${mobile_watchdog_interval_min:-5}" "${mobile_watchdog_fail_min:-60}" "${mobile_watchdog_usb_off_sec:-10}" "${mobile_watchdog_iface:-auto}" ;;
  dns_monitor) /opt/bin/keenvless dns-monitor ;;
  dns_monitor_status) /opt/bin/keenvless dns-monitor-status ;;
  set_dns_monitor) /opt/bin/keenvless set-dns-monitor "${dns_monitor_enabled:-0}" "${dns_monitor_interval_min:-15}" "$dns_monitor_hosts" ;;
  external_ip) /opt/bin/keenvless external-ip ;;
  manual_list) /opt/bin/keenvless manual-list ;;
  manual_add)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-add "$manual_name" "$manual_link"
    ;;
  manual_rename)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-rename "$manual_id" "$manual_name"
    ;;
  manual_duplicate)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-duplicate "$manual_id" "$manual_name"
    ;;
  manual_test)
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-test "$manual_link"
    ;;
  profiles) /opt/bin/keenvless profiles ;;
  hysteria_diagnostics) /opt/bin/keenvless hysteria-diagnostics ;;
  dependency_doctor|doctor) /opt/bin/keenvless dependency-doctor ;;
  bootstrap_script) /opt/bin/keenvless bootstrap-script ;;
  rescue_status|rescue_wg_status) /opt/bin/keenvless rescue-status ;;
  rescue_wireguard|rescue_wg_plan|rescue_plan) /opt/bin/keenvless rescue-wireguard ;;
  manual_delete) /opt/bin/keenvless manual-delete "$manual_id" ;;
  install_auto) /opt/bin/keenvless install-auto ;;
  disable_auto) /opt/bin/keenvless disable-auto ;;
  clients) /opt/bin/keenvless clients ;;
  backup_config) /opt/bin/keenvless backup-config ;;
  backups) /opt/bin/keenvless backups ;;
  backup_preview) /opt/bin/keenvless backup-preview "$backup" ;;
  restore_backup) /opt/bin/keenvless restore-backup "$backup" ;;
  favorites) /opt/bin/keenvless favorites ;;
  set_favorites) /opt/bin/keenvless set-favorites "$favorites" ;;
  export_config) /opt/bin/keenvless export-config ;;
  import_config) /opt/bin/keenvless import-config-b64 "$import_b64" ;;
  route_profiles) /opt/bin/keenvless route-profiles ;;
  apply_profile) /opt/bin/keenvless apply-profile "${route_profile:-geo}" ;;
  route_scenarios) /opt/bin/keenvless route-scenarios ;;
  apply_scenario) /opt/bin/keenvless apply-scenario "${route_scenario:-geo_home}" ;;
  client_mode) /opt/bin/keenvless client-mode "${client:-$client_ip}" "${client_mode:-inherit}" ;;
  device_groups) /opt/bin/keenvless device-groups ;;
  device_group_save) /opt/bin/keenvless device-group-save "$group_id" "$group_name" "${group_mode:-inherit}" "$group_members" ;;
  device_group_delete) /opt/bin/keenvless device-group-delete "$group_id" ;;
  device_group_apply) /opt/bin/keenvless device-group-apply "$group_id" ;;
  rule_center) /opt/bin/keenvless rule-center "${client:-$client_ip}" ;;
  rule_preview) /opt/bin/keenvless rule-preview "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$route_destinations" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  rule_apply) /opt/bin/keenvless rule-apply "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$group_id" "${rule_apply_dest:-0}" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  route_presets) /opt/bin/keenvless route-presets ;;
  route_preset_save) /opt/bin/keenvless route-preset-save "$preset_name" "$preset_id" ;;
  route_preset_apply) /opt/bin/keenvless route-preset-apply "$preset_id" ;;
  route_preset_delete) /opt/bin/keenvless route-preset-delete "$preset_id" ;;
  server_groups) /opt/bin/keenvless server-groups ;;
  set_server_group) /opt/bin/keenvless set-server-group "${server_group:-auto}" ;;
  route_explain) /opt/bin/keenvless route-explain "${client:-$client_ip}" "$destination" ;;
  dns_check) /opt/bin/keenvless dns-check "$destination" ;;
  connections) /opt/bin/keenvless connections ;;
  events) /opt/bin/keenvless events "${event_kind:-all}" ;;
  update_history) /opt/bin/keenvless update-history ;;
  alerts) /opt/bin/keenvless alerts ;;
  dashboard_summary) /opt/bin/keenvless dashboard-summary ;;
  route_batch) /opt/bin/keenvless route-batch "${client:-$client_ip}" "$route_destinations" ;;
  traffic_plan) /opt/bin/keenvless traffic-plan "${client:-$client_ip}" "$route_destinations" ;;
  support_report) /opt/bin/keenvless support-report ;;
  rules_export) /opt/bin/keenvless rules-export ;;
  rules_import) /opt/bin/keenvless rules-import-b64 "$rules_b64" ;;
  logs) /opt/bin/keenvless logs ;;
  check_current) /opt/bin/keenvless check-current ;;
  whoami) printf '{"ok":true,"ip":"%s","remote_addr":"%s"}\n' "$client_ip" "$REMOTE_ADDR" ;;
  diagnostics) /opt/bin/keenvless diagnostics ;;
  health_report) /opt/bin/keenvless health-report "$health_client" ;;
  health_history) /opt/bin/keenvless health-history ;;
  metrics_history) /opt/bin/keenvless metrics-history ;;
  self_test) /opt/bin/keenvless self-test ;;
  router_info) /opt/bin/keenvless router-info ;;
  update_status) /opt/bin/keenvless update-status ;;
  update_begin) /opt/bin/keenvless update-begin "$update_version" "$update_size" "$update_sha256" ;;
  update_chunk) /opt/bin/keenvless update-chunk "$update_id" "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  update_apply) /opt/bin/keenvless update-apply "$update_id" ;;
  update_cancel) /opt/bin/keenvless update-cancel "$update_id" ;;
  update_cleanup) /opt/bin/keenvless update-cleanup "$update_id" ;;
  update_export) /opt/bin/keenvless update-export ;;
  github_check) /opt/bin/keenvless github-check "$github_repo" ;;
  update_github)
    id="github-$(date +%s)-$$"
    jq -n --arg id "$id" --arg tag "$github_tag" --arg repo "$github_repo" '{ok:true,state:"github_queued",id:$id,tag:$tag,repo:$repo}' > /opt/var/lib/keenvless/update-status.json 2>/dev/null || true
    ( /opt/bin/keenvless update-github "$github_tag" "$github_repo" "$github_token" >> /opt/var/log/keenvless-update.log 2>&1 ) &
    printf '{"ok":true,"state":"github_started","id":"%s"}\n' "$id"
    ;;
  github_probe) /opt/bin/keenvless github-probe "$github_tag" "$github_repo" ;;
  github_asset_probe) /opt/bin/keenvless github-asset-probe "$github_tag" "$github_repo" ;;
  router_targets) /opt/bin/keenvless router-targets ;;
  router_local_name) /opt/bin/keenvless router-local-name "$router_local_name" ;;
  router_target_add) /opt/bin/keenvless router-target-add "$router_name" "$router_url" "$router_token" ;;
  router_target_delete) /opt/bin/keenvless router-target-delete "$router_id" ;;
  router_target_test) /opt/bin/keenvless router-target-test "${router_id:-local}" ;;
  router_compare) /opt/bin/keenvless router-compare ;;
  router_sync_rules) /opt/bin/keenvless router-sync-rules "${sync_from:-$router_id}" "${sync_to:-$update_id}" ;;
  router_backup_all) /opt/bin/keenvless router-backup-all ;;
  bootstrap) /opt/bin/keenvless bootstrap ;;
  select) /opt/bin/keenvless select "$server" ;;
  select_async) /opt/bin/keenvless select-async "$server" ;;
  select_status) /opt/bin/keenvless select-status "$select_id" ;;
  select_raw) /opt/bin/keenvless select-raw "$server" ;;
  enable|start) /opt/bin/keenvless enable ;;
  disable|stop) /opt/bin/keenvless disable ;;
  route_on) /opt/bin/keenvless route-on "${client:-$client_ip}" ;;
  route_off) /opt/bin/keenvless route-off "$client" ;;
  config) /opt/bin/keenvless config ;;
  set_config) /opt/bin/keenvless set-config "${sources:-$client_ip}" "${ports:-80,443}" "${block_udp443:-1}" "$proxy_sources" "$direct_sources" ;;
  set_dest_config) /opt/bin/keenvless set-dest-config "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  set_web_auth) /opt/bin/keenvless set-web-auth "${token_required:-0}" "$web_token" ;;
  set_remote_web) /opt/bin/keenvless set-remote-web "${remote_web_enabled:-0}" "${remote_web_port:-8088}" "$remote_web_sources" ;;
  apply_config) /opt/bin/keenvless route-on "${sources:-$client_ip}" ;;
  *) printf '{"ok":false,"error":"unknown action"}\n' ;;
esac
