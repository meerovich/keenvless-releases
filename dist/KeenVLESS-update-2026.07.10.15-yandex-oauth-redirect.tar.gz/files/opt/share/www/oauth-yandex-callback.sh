#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
CONF=/opt/etc/keenvless/keenvless.conf
[ -r "$CONF" ] && . "$CONF"
. /opt/share/www/oauth-yandex-lib.sh

if ! kvx_oauth_ready; then
  kvx_html_error "Вход через Яндекс не настроен" "OAuth выключен или не хватает ClientID, Client secret, списка телефонов."
  exit 0
fi

err="$(kvx_urldecode "$(kvx_param error)")"
err_desc="$(kvx_urldecode "$(kvx_param error_description)")"
if [ -n "$err" ]; then
  kvx_html_error "Яндекс не выдал доступ" "${err_desc:-$err}"
  exit 0
fi

code="$(kvx_urldecode "$(kvx_param code)")"
state="$(kvx_urldecode "$(kvx_param state)")"
[ -n "$code" ] || { kvx_html_error "Нет OAuth code" "Яндекс вернул callback без кода подтверждения."; exit 0; }
[ -n "$state" ] || { kvx_html_error "Нет OAuth state" "Нельзя проверить одноразовый state; вход отклонён."; exit 0; }

state_json="$(kvx_state_read_and_delete "$state" 2>/dev/null || true)"
[ -n "$state_json" ] || { kvx_html_error "OAuth state устарел" "Повторите вход через Яндекс из пульта."; exit 0; }

return_to="$(printf '%s' "$state_json" | jq -r '.return_to // "/"' 2>/dev/null || echo "/")"
return_to="$(kvx_safe_return "$return_to")"
redirect_uri="$(printf '%s' "$state_json" | jq -r '.redirect_uri // ""' 2>/dev/null || true)"
[ -n "$redirect_uri" ] || redirect_uri="$(kvx_redirect_uri)"

token_body="grant_type=authorization_code&code=$(kvx_urlenc "$code")&client_id=$(kvx_urlenc "$YANDEX_CLIENT_ID")&client_secret=$(kvx_urlenc "$YANDEX_CLIENT_SECRET")"
token_json="$(curl -fsS -m 25 -X POST -H 'Content-Type: application/x-www-form-urlencoded' --data "$token_body" "$YANDEX_TOKEN_ENDPOINT" 2>/tmp/keenvless-yandex-token.err || true)"
access_token="$(printf '%s' "$token_json" | jq -r '.access_token // empty' 2>/dev/null || true)"
if [ -z "$access_token" ]; then
  detail="$(printf '%s' "$token_json" | jq -r '.error_description // .error // empty' 2>/dev/null || true)"
  [ -n "$detail" ] || detail="$(cat /tmp/keenvless-yandex-token.err 2>/dev/null || true)"
  kvx_html_error "Не удалось получить OAuth-токен" "${detail:-Проверьте Redirect URI, ClientID/secret и права приложения Яндекса.}"
  exit 0
fi

info_json="$(curl -fsS -m 25 -H "Authorization: OAuth $access_token" "${YANDEX_INFO_ENDPOINT}?format=json" 2>/tmp/keenvless-yandex-info.err || true)"
phone="$(printf '%s' "$info_json" | jq -r '.default_phone.number // .number // empty' 2>/dev/null || true)"
login="$(printf '%s' "$info_json" | jq -r '.login // empty' 2>/dev/null || true)"
uid="$(printf '%s' "$info_json" | jq -r '.id // .uid // empty' 2>/dev/null || true)"
phone="$(kvx_phone_normalize "$phone")"
if [ -z "$phone" ]; then
  detail="$(cat /tmp/keenvless-yandex-info.err 2>/dev/null || true)"
  kvx_html_error "Яндекс не вернул телефон" "${detail:-В приложении Яндекса нужно включить право API Yandex ID → Phone number и разрешить его при входе.}"
  exit 0
fi
if ! kvx_phone_allowed "$phone"; then
  kvx_html_error "Телефон не разрешён" "Аккаунт Яндекса вернул номер $phone, но его нет в whitelist пульта."
  exit 0
fi

cookie_value="$(kvx_session_create "$phone" "$login" "$uid")"
ttl="${YANDEX_SESSION_TTL_SEC:-2592000}"
case "$ttl" in
  ''|*[!0-9]*) ttl=2592000 ;;
esac
[ "$ttl" -ge 3600 ] 2>/dev/null || ttl=3600
[ "$ttl" -le 31536000 ] 2>/dev/null || ttl=31536000

printf 'Status: 302 Found\r\n'
printf 'Set-Cookie: %s=%s; Max-Age=%s; Path=/; HttpOnly; Secure; SameSite=Lax\r\n' "$KVX_OAUTH_COOKIE" "$cookie_value" "$ttl"
printf 'Location: %s\r\n' "$return_to"
printf 'Cache-Control: no-store\r\n\r\n'
