#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
CONF=/opt/etc/keenvless/keenvless.conf
[ -r "$CONF" ] && . "$CONF"
. /opt/share/www/oauth-yandex-lib.sh

if ! kvx_oauth_ready; then
  kvx_html_error "Вход через Яндекс не настроен" "OAuth включается в конфиге пульта: нужен ClientID, Client secret и список разрешённых телефонов."
  exit 0
fi

return_raw="$(kvx_urldecode "$(kvx_param return)")"
[ -n "$return_raw" ] || return_raw="/"
return_to="$(kvx_safe_return "$return_raw")"
redirect_uri="$(kvx_redirect_uri)"
state="$(kvx_state_create "$return_to" "$redirect_uri")"

auth_url="${YANDEX_AUTH_ENDPOINT}?response_type=code&client_id=$(kvx_urlenc "$YANDEX_CLIENT_ID")&redirect_uri=$(kvx_urlenc "$redirect_uri")&state=$(kvx_urlenc "$state")"

printf 'Status: 302 Found\r\n'
printf 'Location: %s\r\n' "$auth_url"
printf 'Cache-Control: no-store\r\n\r\n'
