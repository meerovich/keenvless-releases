#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
. /opt/etc/keenvless/keenvless.conf
[ -r /opt/share/www/oauth-yandex-lib.sh ] && . /opt/share/www/oauth-yandex-lib.sh

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  post_body="$(head -c "${CONTENT_LENGTH:-0}" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    if [ -n "$request_params" ]; then
      request_params="$request_params&$post_body"
    else
      request_params="$post_body"
    fi
  fi
fi

decode() {
  printf '%s' "$1" | sed 's/+/ /g;s/%2E/./Ig;s/%2D/-/Ig;s/%5F/_/Ig;s/%2F/\//Ig;s/%2C/,/Ig;s/%3A/:/Ig;s/%20/ /Ig;s/%2A/*/Ig;s/%24/$/Ig;s/%5B/[/Ig;s/%5D/]/Ig;s/%5C/\\/Ig;s/%7C/|/Ig;s/%3F/?/Ig;s/%2B/+/Ig;s/%3D/=/Ig;s/%5E/^/Ig;s/%7B/{/Ig;s/%7D/}/Ig'
}

param() {
  printf '%s' "$request_params" | awk -v RS='&' -F= -v k="$1" '$1 == k {print substr($0, length(k) + 2); exit}'
}

has_p() {
  case "&$request_params" in
    *"&$1="*) return 0 ;;
  esac
  return 1
}

dv() {
  if has_p "$1"; then
    value="$(decode "$(param "$1")")"
    value_quoted="$(printf "%s" "$value" | sed "s/'/'\\\\''/g")"
    eval "$1='$value_quoted'"
  else
    eval "$1=''"
  fi
}

# Decode only parameters actually present in the request (was: 86 eager decodes on
# every request). Result is identical: absent keys decode to empty either way, but
# a typical param-free poll now spawns no per-parameter processes.
dv action
dv token
dv target
dv token_required
dv web_token
dv remote_web_enabled
dv remote_web_port
dv remote_web_sources
dv server
dv select_id
dv client
dv sources
dv proxy_sources
dv direct_sources
dv ports
dv block_udp443
dv proxy_domains
dv proxy_ips
dv direct_domains
dv direct_ips
dv destination
dv route_destinations
dv health_client
dv route_profile
dv route_scenario
dv client_mode
dv group_id
dv group_mode
dv group_name_b64
dv group_members
dv rule_apply_dest
dv preset_id
dv preset_name_b64
dv server_group
dv event_kind
dv favorites
dv import_b64
dv rules_b64
dv manual_id
dv manual_name_b64
dv manual_link_b64
dv backup
dv router_id
dv sync_from
dv sync_to
dv router_name_b64
dv router_url_b64
dv router_token_b64
dv router_local_name_b64
dv update_id
dv update_version
dv update_size
dv update_sha256
dv update_offset
dv update_chunk_sha256
dv update_chunk_b64
dv xray_url_b64
dv github_tag
dv github_repo
dv github_token
dv watchdog_enabled
dv watchdog_interval_min
dv watchdog_probe_after_fails
dv watchdog_switch_after_fails
dv watchdog_candidate_count
dv watchdog_switch_cooldown_min
dv watchdog_fallback_direct
dv watchdog_restore_original
dv watchdog_quarantine_min
dv watchdog_restore_ok_count
dv watchdog_flap_window_min
dv watchdog_max_switches_window
dv mobile_watchdog_enabled
dv mobile_watchdog_interval_min
dv mobile_watchdog_fail_min
dv mobile_watchdog_usb_off_sec
dv mobile_watchdog_iface
dv dns_monitor_enabled
dv dns_monitor_interval_min
dv dns_monitor_hosts
dv yandex_oauth_enabled
dv yandex_client_id
dv yandex_client_secret
dv yandex_allowed_phones
dv yandex_session_ttl_sec
dv yandex_redirect_uri
router_name=""
router_url=""
router_token=""
router_local_name=""
xray_url=""
[ -n "$router_name_b64" ] && router_name="$(printf '%s' "$router_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_url_b64" ] && router_url="$(printf '%s' "$router_url_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_token_b64" ] && router_token="$(printf '%s' "$router_token_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_local_name_b64" ] && router_local_name="$(printf '%s' "$router_local_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$xray_url_b64" ] && xray_url="$(printf '%s' "$xray_url_b64" | base64 -d 2>/dev/null || true)"
preset_name=""
[ -n "$preset_name_b64" ] && preset_name="$(printf '%s' "$preset_name_b64" | base64 -d 2>/dev/null || true)"
group_name=""
[ -n "$group_name_b64" ] && group_name="$(printf '%s' "$group_name_b64" | base64 -d 2>/dev/null || true)"

client_ip="${REMOTE_ADDR:-}"
if [ "$client_ip" = "127.0.0.1" ] || [ "$client_ip" = "::1" ]; then
  forwarded="${HTTP_X_FORWARDED_FOR:-${HTTP_X_REAL_IP:-}}"
  if [ -n "$forwarded" ]; then
    client_ip="$(printf '%s' "$forwarded" | sed 's/,.*//;s/[[:space:]]//g')"
  fi
fi
[ -n "$client_ip" ] || client_ip="${REMOTE_ADDR:-127.0.0.1}"

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

TOKEN_REQUIRED="${TOKEN_REQUIRED:-0}"
auth_method="none"
if [ "$TOKEN_REQUIRED" = "1" ]; then
  auth_ok=0
  if [ "$token" = "${TOKEN:-}" ]; then
    auth_ok=1
    auth_method="token"
  elif command -v kvx_session_valid >/dev/null 2>&1 && kvx_session_valid; then
    auth_ok=1
    auth_method="yandex"
  fi
  if [ "$auth_ok" != "1" ]; then
  printf '{"ok":false,"error":"unauthorized"}\n'
  exit 0
  fi
fi

if [ -n "$target" ] && [ "$target" != "local" ]; then
  case "$action" in
    router_targets|router_local_name|router_target_add|router_target_delete|router_target_test)
      ;;
    *)
      /opt/bin/keenvless router-proxy "$target" "$request_params"
      exit 0
      ;;
  esac
fi

# ---- hot-read snapshot cache (RAM/tmpfs, short TTL) ----
# Accelerates dashboard polling of status/dashboard_summary without touching the
# core. Disable by setting KV_STATUS_CACHE_TTL=0 in keenvless.conf. Any
# state-changing action below invalidates the snapshot immediately.
KV_CACHE_DIR="${KV_CACHE_DIR:-/tmp/keenvless-cache}"
KV_STATUS_CACHE_TTL="${KV_STATUS_CACHE_TTL:-3}"
case "$KV_STATUS_CACHE_TTL" in ''|*[!0-9]*) KV_STATUS_CACHE_TTL=0 ;; esac
case "$action" in
  select|select_async|select_raw|set_config|set_dest_config|apply_profile|apply_scenario|enable|start|disable|stop|route_on|route_off|route_batch|set_watchdog|set_mobile_watchdog|set_dns_monitor|set_server_group|set_favorites|device_group_save|device_group_delete|device_group_apply|rule_apply|route_preset_save|route_preset_apply|route_preset_delete|client_mode|manual_add|manual_rename|manual_duplicate|manual_delete|import_config|restore_backup|set_web_auth|set_yandex_oauth|set_remote_web|remote_web_apply|remote_web_off|update_apply|xray_candidate_install|update_github|install_auto|disable_auto|bootstrap|backup_config|rules_import|apply_config)
    rm -f "$KV_CACHE_DIR/status.json" "$KV_CACHE_DIR/status.json.at" "$KV_CACHE_DIR/dashboard_summary.json" "$KV_CACHE_DIR/dashboard_summary.json.at" 2>/dev/null || true
    ;;
esac
kv_cache_cmd=""
kv_cache_file=""
case "$action" in
  status|"") kv_cache_cmd="status"; kv_cache_file="$KV_CACHE_DIR/status.json" ;;
  dashboard_summary) kv_cache_cmd="dashboard-summary"; kv_cache_file="$KV_CACHE_DIR/dashboard_summary.json" ;;
esac
if [ -n "$kv_cache_cmd" ] && [ "$KV_STATUS_CACHE_TTL" -gt 0 ]; then
  if [ -f "$kv_cache_file" ]; then
    kv_now="$(date +%s)"
    kv_gen="$(cat "$kv_cache_file.at" 2>/dev/null || echo 0)"
    kv_age=$((kv_now - kv_gen))
    if [ "$kv_age" -ge 0 ] && [ "$kv_age" -lt "$KV_STATUS_CACHE_TTL" ]; then
      cat "$kv_cache_file"
      exit 0
    fi
  fi
  kv_out="$(/opt/bin/keenvless "$kv_cache_cmd")"
  printf '%s' "$kv_out"
  if printf '%s' "$kv_out" | jq -e . >/dev/null 2>&1; then
    mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
    printf '%s' "$kv_out" > "$kv_cache_file.tmp.$$" 2>/dev/null && mv "$kv_cache_file.tmp.$$" "$kv_cache_file" 2>/dev/null || true
    date +%s > "$kv_cache_file.at.tmp.$$" 2>/dev/null && mv "$kv_cache_file.at.tmp.$$" "$kv_cache_file.at" 2>/dev/null || true
  fi
  exit 0
fi

case "$action" in
  status|"") /opt/bin/keenvless status ;;
  version) /opt/bin/keenvless version ;;
  list) /opt/bin/keenvless list ;;
  update) /opt/bin/keenvless update ;;
  scan) /opt/bin/keenvless scan ;;
  scan_current) /opt/bin/keenvless scan "$server" ;;
  scan_async) /opt/bin/keenvless scan-async "$server" ;;
  scan_status) /opt/bin/keenvless scan-status ;;
  scan_cancel) /opt/bin/keenvless scan-cancel ;;
  watchdog) /opt/bin/keenvless watchdog ;;
  watchdog_status) /opt/bin/keenvless watchdog-status ;;
  watchdog_candidates) /opt/bin/keenvless watchdog-candidates ;;
  route_guard) /opt/bin/keenvless route-guard ;;
  set_watchdog) /opt/bin/keenvless set-watchdog "${watchdog_enabled:-0}" "${watchdog_interval_min:-5}" "${watchdog_probe_after_fails:-3}" "${watchdog_switch_after_fails:-6}" "${watchdog_candidate_count:-5}" "${watchdog_switch_cooldown_min:-15}" "${watchdog_fallback_direct:-1}" "${watchdog_restore_original:-1}" "${watchdog_quarantine_min:-30}" "${watchdog_restore_ok_count:-2}" "${watchdog_flap_window_min:-60}" "${watchdog_max_switches_window:-3}" ;;
  mobile_watchdog) /opt/bin/keenvless mobile-watchdog-now ;;
  mobile_watchdog_status) /opt/bin/keenvless mobile-watchdog-status ;;
  set_mobile_watchdog) /opt/bin/keenvless set-mobile-watchdog "${mobile_watchdog_enabled:-1}" "${mobile_watchdog_interval_min:-5}" "${mobile_watchdog_fail_min:-60}" "${mobile_watchdog_usb_off_sec:-10}" "${mobile_watchdog_iface:-auto}" ;;
  dns_monitor) /opt/bin/keenvless dns-monitor ;;
  dns_monitor_status) /opt/bin/keenvless dns-monitor-status ;;
  set_dns_monitor) /opt/bin/keenvless set-dns-monitor "${dns_monitor_enabled:-0}" "${dns_monitor_interval_min:-15}" "$dns_monitor_hosts" ;;
  external_ip) /opt/bin/keenvless external-ip ;;
  manual_list) /opt/bin/keenvless manual-list ;;
  manual_add)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-add "$manual_name" "$manual_link"
    ;;
  manual_rename)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-rename "$manual_id" "$manual_name"
    ;;
  manual_duplicate)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-duplicate "$manual_id" "$manual_name"
    ;;
  manual_test)
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-test "$manual_link"
    ;;
  provider_debug) /opt/bin/keenvless provider-debug "$server" ;;
  xray_env) /opt/bin/keenvless xray-env ;;
  profiles) /opt/bin/keenvless profiles ;;
  hysteria_diagnostics) /opt/bin/keenvless hysteria-diagnostics ;;
  dependency_doctor|doctor) /opt/bin/keenvless dependency-doctor ;;
  bootstrap_script) /opt/bin/keenvless bootstrap-script ;;
  rescue_status|rescue_wg_status) /opt/bin/keenvless rescue-status ;;
  rescue_wireguard|rescue_wg_plan|rescue_plan) /opt/bin/keenvless rescue-wireguard ;;
  manual_delete) /opt/bin/keenvless manual-delete "$manual_id" ;;
  install_auto) /opt/bin/keenvless install-auto ;;
  disable_auto) /opt/bin/keenvless disable-auto ;;
  clients) /opt/bin/keenvless clients ;;
  backup_config) /opt/bin/keenvless backup-config ;;
  backups) /opt/bin/keenvless backups ;;
  backup_preview) /opt/bin/keenvless backup-preview "$backup" ;;
  restore_backup) /opt/bin/keenvless restore-backup "$backup" ;;
  favorites) /opt/bin/keenvless favorites ;;
  set_favorites) /opt/bin/keenvless set-favorites "$favorites" ;;
  export_config) /opt/bin/keenvless export-config ;;
  import_config) /opt/bin/keenvless import-config-b64 "$import_b64" ;;
  route_profiles) /opt/bin/keenvless route-profiles ;;
  apply_profile) /opt/bin/keenvless apply-profile "${route_profile:-geo}" ;;
  route_scenarios) /opt/bin/keenvless route-scenarios ;;
  apply_scenario) /opt/bin/keenvless apply-scenario "${route_scenario:-geo_home}" ;;
  client_mode) /opt/bin/keenvless client-mode "${client:-$client_ip}" "${client_mode:-inherit}" ;;
  device_groups) /opt/bin/keenvless device-groups ;;
  device_group_save) /opt/bin/keenvless device-group-save "$group_id" "$group_name" "${group_mode:-inherit}" "$group_members" ;;
  device_group_delete) /opt/bin/keenvless device-group-delete "$group_id" ;;
  device_group_apply) /opt/bin/keenvless device-group-apply "$group_id" ;;
  rule_center) /opt/bin/keenvless rule-center "${client:-$client_ip}" ;;
  rule_preview) /opt/bin/keenvless rule-preview "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$route_destinations" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  rule_apply) /opt/bin/keenvless rule-apply "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$group_id" "${rule_apply_dest:-0}" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  route_presets) /opt/bin/keenvless route-presets ;;
  route_preset_save) /opt/bin/keenvless route-preset-save "$preset_name" "$preset_id" ;;
  route_preset_apply) /opt/bin/keenvless route-preset-apply "$preset_id" ;;
  route_preset_delete) /opt/bin/keenvless route-preset-delete "$preset_id" ;;
  server_groups) /opt/bin/keenvless server-groups ;;
  set_server_group) /opt/bin/keenvless set-server-group "${server_group:-auto}" ;;
  route_explain) /opt/bin/keenvless route-explain "${client:-$client_ip}" "$destination" ;;
  dns_check) /opt/bin/keenvless dns-check "$destination" ;;
  connections) /opt/bin/keenvless connections ;;
  events) /opt/bin/keenvless events "${event_kind:-all}" ;;
  update_history) /opt/bin/keenvless update-history ;;
  alerts) /opt/bin/keenvless alerts ;;
  dashboard_summary) /opt/bin/keenvless dashboard-summary ;;
  route_batch) /opt/bin/keenvless route-batch "${client:-$client_ip}" "$route_destinations" ;;
  traffic_plan) /opt/bin/keenvless traffic-plan "${client:-$client_ip}" "$route_destinations" ;;
  support_report) /opt/bin/keenvless support-report ;;
  rules_export) /opt/bin/keenvless rules-export ;;
  rules_import) /opt/bin/keenvless rules-import-b64 "$rules_b64" ;;
  logs) /opt/bin/keenvless logs ;;
  check_current) /opt/bin/keenvless check-current ;;
  whoami) printf '{"ok":true,"ip":"%s","remote_addr":"%s","auth":"%s","phone":"%s"}\n' "$client_ip" "$REMOTE_ADDR" "$auth_method" "${KVX_AUTH_PHONE:-}" ;;
  diagnostics) /opt/bin/keenvless diagnostics ;;
  health_report) /opt/bin/keenvless health-report "$health_client" ;;
  health_history) /opt/bin/keenvless health-history ;;
  metrics_history) /opt/bin/keenvless metrics-history ;;
  self_test) /opt/bin/keenvless self-test ;;
  router_info) /opt/bin/keenvless router-info ;;
  update_status) /opt/bin/keenvless update-status ;;
  update_begin) /opt/bin/keenvless update-begin "$update_version" "$update_size" "$update_sha256" ;;
  update_chunk) /opt/bin/keenvless update-chunk "$update_id" "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  update_apply) /opt/bin/keenvless update-apply "$update_id" ;;
  xray_candidate_begin) /opt/bin/keenvless xray-candidate-begin "$update_size" "$update_sha256" ;;
  xray_candidate_chunk) /opt/bin/keenvless xray-candidate-chunk "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  xray_candidate_status) /opt/bin/keenvless xray-candidate-status ;;
  xray_candidate_check) /opt/bin/keenvless xray-candidate-check ;;
  xray_candidate_fetch) /opt/bin/keenvless xray-candidate-fetch "$xray_url" "$update_sha256" ;;
  xray_candidate_provider_debug) /opt/bin/keenvless xray-candidate-provider-debug "$server" ;;
  xray_candidate_install) /opt/bin/keenvless xray-candidate-install "$update_sha256" ;;
  update_cancel) /opt/bin/keenvless update-cancel "$update_id" ;;
  update_cleanup) /opt/bin/keenvless update-cleanup "$update_id" ;;
  update_export) /opt/bin/keenvless update-export ;;
  github_check) /opt/bin/keenvless github-check "$github_repo" ;;
  update_github)
    id="github-$(date +%s)-$$"
    jq -n --arg id "$id" --arg tag "$github_tag" --arg repo "$github_repo" '{ok:true,state:"github_queued",id:$id,tag:$tag,repo:$repo}' > /opt/var/lib/keenvless/update-status.json 2>/dev/null || true
    ( /opt/bin/keenvless update-github "$github_tag" "$github_repo" "$github_token" >> /opt/var/log/keenvless-update.log 2>&1 ) &
    printf '{"ok":true,"state":"github_started","id":"%s"}\n' "$id"
    ;;
  github_probe) /opt/bin/keenvless github-probe "$github_tag" "$github_repo" ;;
  github_asset_probe) /opt/bin/keenvless github-asset-probe "$github_tag" "$github_repo" ;;
  router_targets) /opt/bin/keenvless router-targets ;;
  router_local_name) /opt/bin/keenvless router-local-name "$router_local_name" ;;
  router_target_add) /opt/bin/keenvless router-target-add "$router_name" "$router_url" "$router_token" ;;
  router_target_delete) /opt/bin/keenvless router-target-delete "$router_id" ;;
  router_target_test) /opt/bin/keenvless router-target-test "${router_id:-local}" ;;
  router_compare) /opt/bin/keenvless router-compare ;;
  router_sync_rules) /opt/bin/keenvless router-sync-rules "${sync_from:-$router_id}" "${sync_to:-$update_id}" ;;
  router_backup_all) /opt/bin/keenvless router-backup-all ;;
  bootstrap) /opt/bin/keenvless bootstrap ;;
  select) /opt/bin/keenvless select "$server" ;;
  select_async) /opt/bin/keenvless select-async "$server" ;;
  select_status) /opt/bin/keenvless select-status "$select_id" ;;
  select_raw) /opt/bin/keenvless select-raw "$server" ;;
  enable|start) /opt/bin/keenvless enable ;;
  disable|stop) /opt/bin/keenvless disable ;;
  route_on) /opt/bin/keenvless route-on "${client:-$client_ip}" ;;
  route_off) /opt/bin/keenvless route-off "$client" ;;
  config) /opt/bin/keenvless config ;;
  set_config) /opt/bin/keenvless set-config "${sources:-$client_ip}" "${ports:-80,443}" "${block_udp443:-1}" "$proxy_sources" "$direct_sources" ;;
  set_dest_config) /opt/bin/keenvless set-dest-config "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  set_web_auth) /opt/bin/keenvless set-web-auth "${token_required:-0}" "$web_token" ;;
  set_yandex_oauth) /opt/bin/keenvless set-yandex-oauth "${yandex_oauth_enabled:-0}" "$yandex_client_id" "$yandex_client_secret" "$yandex_allowed_phones" "$yandex_session_ttl_sec" "$yandex_redirect_uri" ;;
  set_remote_web) /opt/bin/keenvless set-remote-web "${remote_web_enabled:-0}" "${remote_web_port:-8088}" "$remote_web_sources" ;;
  apply_config) /opt/bin/keenvless route-on "${sources:-$client_ip}" ;;
  *) printf '{"ok":false,"error":"unknown action"}\n' ;;
esac
