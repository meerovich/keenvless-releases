#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
. /opt/etc/keenvless/keenvless.conf
[ -r /opt/share/www/oauth-yandex-lib.sh ] && . /opt/share/www/oauth-yandex-lib.sh

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  post_body="$(head -c "${CONTENT_LENGTH:-0}" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    if [ -n "$request_params" ]; then
      request_params="$request_params&$post_body"
    else
      request_params="$post_body"
    fi
  fi
fi

decode() {
  printf '%s' "$1" | sed 's/+/ /g;s/%2E/./Ig;s/%2D/-/Ig;s/%5F/_/Ig;s/%2F/\//Ig;s/%2C/,/Ig;s/%3A/:/Ig;s/%20/ /Ig;s/%2A/*/Ig;s/%24/$/Ig;s/%5B/[/Ig;s/%5D/]/Ig;s/%5C/\\/Ig;s/%7C/|/Ig;s/%3F/?/Ig;s/%2B/+/Ig;s/%3D/=/Ig;s/%5E/^/Ig;s/%7B/{/Ig;s/%7D/}/Ig'
}

param() {
  printf '%s' "$request_params" | awk -v RS='&' -F= -v k="$1" '$1 == k {print substr($0, length(k) + 2); exit}'
}

has_p() {
  case "&$request_params" in
    *"&$1="*) return 0 ;;
  esac
  return 1
}

dv() {
  if has_p "$1"; then
    value="$(decode "$(param "$1")")"
    value_quoted="$(printf "%s" "$value" | sed "s/'/'\\\\''/g")"
    eval "$1='$value_quoted'"
  else
    eval "$1=''"
  fi
}

# Decode only parameters actually present in the request (was: 86 eager decodes on
# every request). Result is identical: absent keys decode to empty either way, but
# a typical param-free poll now spawns no per-parameter processes.
dv action
dv token
dv target
dv token_required
dv web_token
dv remote_web_enabled
dv remote_web_port
dv remote_web_sources
dv server
dv select_id
dv client
dv sources
dv proxy_sources
dv direct_sources
dv ports
dv block_udp443
dv proxy_domains
dv proxy_ips
dv direct_domains
dv direct_ips
dv destination
dv route_destinations
dv health_client
dv route_profile
dv route_scenario
dv client_mode
dv group_id
dv group_mode
dv group_name_b64
dv group_members
dv rule_apply_dest
dv preset_id
dv preset_name_b64
dv server_group
dv event_kind
dv favorites
dv import_b64
dv rules_b64
dv manual_id
dv manual_name_b64
dv manual_link_b64
dv backup
dv router_id
dv sync_from
dv sync_to
dv router_name_b64
dv router_url_b64
dv router_token_b64
dv router_local_name_b64
dv update_id
dv update_version
dv update_size
dv update_sha256
dv update_offset
dv update_chunk_sha256
dv update_chunk_b64
dv xray_url_b64
dv github_tag
dv github_repo
dv github_token
dv watchdog_enabled
dv watchdog_interval_min
dv watchdog_probe_after_fails
dv watchdog_switch_after_fails
dv watchdog_candidate_count
dv watchdog_switch_cooldown_min
dv watchdog_fallback_direct
dv watchdog_restore_original
dv watchdog_quarantine_min
dv watchdog_restore_ok_count
dv watchdog_flap_window_min
dv watchdog_max_switches_window
dv mobile_watchdog_enabled
dv mobile_watchdog_interval_min
dv mobile_watchdog_fail_min
dv mobile_watchdog_usb_off_sec
dv mobile_watchdog_iface
dv dns_monitor_enabled
dv dns_monitor_interval_min
dv dns_monitor_hosts
dv yandex_oauth_enabled
dv yandex_client_id
dv yandex_client_secret
dv yandex_allowed_phones
dv yandex_session_ttl_sec
dv yandex_redirect_uri
router_name=""
router_url=""
router_token=""
router_local_name=""
xray_url=""
[ -n "$router_name_b64" ] && router_name="$(printf '%s' "$router_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_url_b64" ] && router_url="$(printf '%s' "$router_url_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_token_b64" ] && router_token="$(printf '%s' "$router_token_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_local_name_b64" ] && router_local_name="$(printf '%s' "$router_local_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$xray_url_b64" ] && xray_url="$(printf '%s' "$xray_url_b64" | base64 -d 2>/dev/null || true)"
preset_name=""
[ -n "$preset_name_b64" ] && preset_name="$(printf '%s' "$preset_name_b64" | base64 -d 2>/dev/null || true)"
group_name=""
[ -n "$group_name_b64" ] && group_name="$(printf '%s' "$group_name_b64" | base64 -d 2>/dev/null || true)"

client_ip="${REMOTE_ADDR:-}"
if [ "$client_ip" = "127.0.0.1" ] || [ "$client_ip" = "::1" ]; then
  forwarded="${HTTP_X_FORWARDED_FOR:-${HTTP_X_REAL_IP:-}}"
  if [ -n "$forwarded" ]; then
    client_ip="$(printf '%s' "$forwarded" | sed 's/,.*//;s/[[:space:]]//g')"
  fi
fi
[ -n "$client_ip" ] || client_ip="${REMOTE_ADDR:-127.0.0.1}"

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

TOKEN_REQUIRED="${TOKEN_REQUIRED:-0}"
auth_method="none"
if [ "$TOKEN_REQUIRED" = "1" ]; then
  auth_ok=0
  if [ "$token" = "${TOKEN:-}" ]; then
    auth_ok=1
    auth_method="token"
  elif command -v kvx_session_valid >/dev/null 2>&1 && kvx_session_valid; then
    auth_ok=1
    auth_method="yandex"
  fi
  if [ "$auth_ok" != "1" ]; then
  printf '{"ok":false,"error":"unauthorized"}\n'
  exit 0
  fi
fi

if [ -n "$target" ] && [ "$target" != "local" ]; then
  case "$action" in
    router_targets|router_local_name|router_target_add|router_target_delete|router_target_test)
      ;;
    *)
      /opt/bin/keenvless router-proxy "$target" "$request_params"
      exit 0
      ;;
  esac
fi

# ---- hot-read JSON cache (RAM/tmpfs, short TTL) ----
# The home screen and expert panels poll the same read-only data repeatedly.
# Keep small, valid JSON snapshots in /tmp and invalidate every snapshot before
# an action that can alter profiles, routes, health or service state. All TTLs
# can be set to 0 in keenvless.conf to turn the corresponding cache off.
KV_CACHE_DIR="${KV_CACHE_DIR:-/tmp/keenvless-cache}"
KV_STATUS_CACHE_TTL="${KV_STATUS_CACHE_TTL:-3}"
KV_DASHBOARD_CACHE_TTL="${KV_DASHBOARD_CACHE_TTL:-$KV_STATUS_CACHE_TTL}"
KV_PROFILES_CACHE_TTL="${KV_PROFILES_CACHE_TTL:-10}"
KV_ALERTS_CACHE_TTL="${KV_ALERTS_CACHE_TTL:-10}"
KV_METRICS_CACHE_TTL="${KV_METRICS_CACHE_TTL:-10}"
KV_HEALTH_HISTORY_CACHE_TTL="${KV_HEALTH_HISTORY_CACHE_TTL:-10}"
KV_ROUTER_INFO_CACHE_TTL="${KV_ROUTER_INFO_CACHE_TTL:-30}"
# The simple UI can use a compact, non-secret snapshot.  It lives only on the
# tmpfs and is built in the background, so a slow status read never blocks the
# first paint of a page that already has a previous snapshot.
KV_OVERVIEW_CACHE_TTL="${KV_OVERVIEW_CACHE_TTL:-15}"
KV_OVERVIEW_LOCK_MAX_AGE="${KV_OVERVIEW_LOCK_MAX_AGE:-180}"

kv_cache_ttl() {
  case "$1" in ''|*[!0-9]*) printf '0' ;; *) printf '%s' "$1" ;; esac
}

KV_STATUS_CACHE_TTL="$(kv_cache_ttl "$KV_STATUS_CACHE_TTL")"
KV_DASHBOARD_CACHE_TTL="$(kv_cache_ttl "$KV_DASHBOARD_CACHE_TTL")"
KV_PROFILES_CACHE_TTL="$(kv_cache_ttl "$KV_PROFILES_CACHE_TTL")"
KV_ALERTS_CACHE_TTL="$(kv_cache_ttl "$KV_ALERTS_CACHE_TTL")"
KV_METRICS_CACHE_TTL="$(kv_cache_ttl "$KV_METRICS_CACHE_TTL")"
KV_HEALTH_HISTORY_CACHE_TTL="$(kv_cache_ttl "$KV_HEALTH_HISTORY_CACHE_TTL")"
KV_ROUTER_INFO_CACHE_TTL="$(kv_cache_ttl "$KV_ROUTER_INFO_CACHE_TTL")"
KV_OVERVIEW_CACHE_TTL="$(kv_cache_ttl "$KV_OVERVIEW_CACHE_TTL")"
KV_OVERVIEW_LOCK_MAX_AGE="$(kv_cache_ttl "$KV_OVERVIEW_LOCK_MAX_AGE")"
[ "$KV_OVERVIEW_LOCK_MAX_AGE" -gt 0 ] || KV_OVERVIEW_LOCK_MAX_AGE=180

KV_OVERVIEW_FILE="$KV_CACHE_DIR/overview.json"
KV_OVERVIEW_STAMP="$KV_CACHE_DIR/overview.json.at"
KV_OVERVIEW_LOCK="$KV_CACHE_DIR/overview.refresh.lock"
KV_OVERVIEW_GENERATION="$KV_CACHE_DIR/overview.generation"

kv_overview_valid() {
  [ -s "$KV_OVERVIEW_FILE" ] \
    && jq -e '(.ok == true) and (.status.ok == true) and (.profiles.ok == true)' "$KV_OVERVIEW_FILE" >/dev/null 2>&1
}

kv_overview_age() {
  if ! kv_overview_valid; then
    printf '%s\n' '-1'
    return 0
  fi
  kv_overview_at="$(cat "$KV_OVERVIEW_STAMP" 2>/dev/null || jq -r '.generated_at // 0' "$KV_OVERVIEW_FILE" 2>/dev/null || echo 0)"
  case "$kv_overview_at" in ''|*[!0-9]*) kv_overview_at=0 ;; esac
  kv_overview_now="$(date +%s)"
  kv_overview_age_value=$((kv_overview_now - kv_overview_at))
  [ "$kv_overview_age_value" -ge 0 ] || kv_overview_age_value=0
  printf '%s\n' "$kv_overview_age_value"
}

kv_overview_cleanup_stale_lock() {
  [ -d "$KV_OVERVIEW_LOCK" ] || return 0
  kv_overview_lock_at="$(cat "$KV_OVERVIEW_LOCK/at" 2>/dev/null || echo 0)"
  case "$kv_overview_lock_at" in ''|*[!0-9]*) kv_overview_lock_at=0 ;; esac
  kv_overview_now="$(date +%s)"
  kv_overview_lock_age=$((kv_overview_now - kv_overview_lock_at))
  if [ "$kv_overview_lock_at" -le 0 ] || [ "$kv_overview_lock_age" -gt "$KV_OVERVIEW_LOCK_MAX_AGE" ]; then
    rm -f "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
    rmdir "$KV_OVERVIEW_LOCK" 2>/dev/null || true
  fi
}

kv_overview_invalidate() {
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  printf '%s-%s\n' "$(date +%s)" "$$" > "$KV_OVERVIEW_GENERATION.tmp.$$" 2>/dev/null \
    && mv "$KV_OVERVIEW_GENERATION.tmp.$$" "$KV_OVERVIEW_GENERATION" 2>/dev/null || true
  rm -f "$KV_OVERVIEW_FILE" "$KV_OVERVIEW_STAMP" 2>/dev/null || true
}

kv_overview_refresh_worker() {
  kv_overview_generation="$(cat "$KV_OVERVIEW_GENERATION" 2>/dev/null || true)"
  kv_overview_dir="$KV_CACHE_DIR/.overview-refresh-$$"
  if ! mkdir "$kv_overview_dir" 2>/dev/null; then
    rm -f "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
    rmdir "$KV_OVERVIEW_LOCK" 2>/dev/null || true
    return 0
  fi

  /opt/bin/keenvless status > "$kv_overview_dir/status.json" 2>/dev/null || true
  /opt/bin/keenvless profiles > "$kv_overview_dir/profiles.json" 2>/dev/null || true

  if jq -e '.ok == true' "$kv_overview_dir/status.json" >/dev/null 2>&1 \
    && jq -e '.ok == true' "$kv_overview_dir/profiles.json" >/dev/null 2>&1; then
    jq -n \
      --slurpfile status "$kv_overview_dir/status.json" \
      --slurpfile profiles "$kv_overview_dir/profiles.json" '
        ($status[0] // {}) as $s |
        ($profiles[0] // {}) as $p |
        ($s.health_last // {}) as $health |
        ($health.current_server // {}) as $current |
        ($p.profiles // [] | map({
          id:(.id // "" | tostring),
          name:(.name // ""),
          source:(.source // ""),
          profile_kind:(.profile_kind // ""),
          protocol:(.protocol // ""),
          display_protocol:(.display_protocol // ""),
          health:(.health // "unknown"),
          note:(.note // ""),
          latency_ms:(.latency_ms // null),
          checked_at:(.checked_at // null),
          active:(.active // false),
          country_code:(.country_code // ""),
          favorite:(.favorite // false),
          user:(.user // ""),
          server:(.server // ""),
          port:(.port // ""),
          sni:(.sni // ""),
          obfs:(.obfs // ""),
          pin_present:(.pin_present // false)
        })) as $items |
        {
          ok:(($s.ok // false) == true and ($p.ok // false) == true),
          generated_at:(now|floor),
          status:{
            ok:(($s.ok // false) == true),
            version:($s.version // ""),
            api_version:($s.api_version // 0),
            min_ui_version:($s.min_ui_version // ""),
            running:($s.running // false),
            selected:($s.selected // ""),
            selected_health:($s.selected_health // ""),
            selected_latency_ms:($s.selected_latency_ms // null),
            selected_checked_at:($s.selected_checked_at // null),
            route_profile:($s.route_profile // ""),
            server_group:($s.server_group // ""),
            servers:($s.servers // 0),
            crond_running:($s.crond_running // false),
            watchdog_enabled:($s.watchdog_enabled // 0),
            health_last:{
              ok:(($health.ok // false) == true),
              overall:($health.overall // "unknown"),
              checked_at:($health.checked_at // 0),
              summary:{
                checks:($health.summary.checks // 0),
                fails:($health.summary.fails // 0),
                warns:($health.summary.warns // 0)
              },
              current_server:{
                ok:(($current.ok // false) == true),
                ip:($current.ip // ""),
                youtube:($current.youtube // ""),
                reason:($current.reason // "")
              }
            }
          },
          profiles:{
            ok:(($p.ok // false) == true),
            selected:($p.selected // ""),
            selected_profile:($items | map(select(.active == true)) | .[0] // null),
            duplicate_hysteria_users:(($p.duplicate_hysteria_users // []) | map({
              user:(.user // ""),
              count:(.count // 0),
              profiles:((.profiles // []) | map({id:(.id // ""),name:(.name // ""),active:(.active // false)}))
            })),
            summary:{
              total:($p.summary.total // 0),
              provider:($p.summary.provider // 0),
              manual:($p.summary.manual // 0),
              hysteria2:($p.summary.hysteria2 // 0),
              duplicate_hysteria_users:($p.summary.duplicate_hysteria_users // 0)
            },
            profiles:$items
          }
        }' > "$kv_overview_dir/overview.json" 2>/dev/null || true
  fi

  if [ "$(cat "$KV_OVERVIEW_GENERATION" 2>/dev/null || true)" = "$kv_overview_generation" ] \
    && [ -s "$kv_overview_dir/overview.json" ] \
    && jq -e '(.ok == true) and (.status.ok == true) and (.profiles.ok == true)' "$kv_overview_dir/overview.json" >/dev/null 2>&1; then
    mv "$kv_overview_dir/overview.json" "$KV_OVERVIEW_FILE" 2>/dev/null || true
    date +%s > "$KV_OVERVIEW_STAMP.tmp.$$" 2>/dev/null && mv "$KV_OVERVIEW_STAMP.tmp.$$" "$KV_OVERVIEW_STAMP" 2>/dev/null || true
  fi

  rm -f "$kv_overview_dir/status.json" "$kv_overview_dir/profiles.json" "$kv_overview_dir/overview.json" 2>/dev/null || true
  rmdir "$kv_overview_dir" 2>/dev/null || true
  rm -f "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
  rmdir "$KV_OVERVIEW_LOCK" 2>/dev/null || true
}

kv_overview_start_refresh() {
  [ "$KV_OVERVIEW_CACHE_TTL" -gt 0 ] || return 0
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || return 0
  kv_overview_cleanup_stale_lock
  [ -d "$KV_OVERVIEW_LOCK" ] && return 0
  if mkdir "$KV_OVERVIEW_LOCK" 2>/dev/null; then
    date +%s > "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
    ( kv_overview_refresh_worker ) >/dev/null 2>&1 &
  fi
}

kv_overview_snapshot() {
  if [ "$KV_OVERVIEW_CACHE_TTL" -le 0 ]; then
    printf '{"ok":false,"state":"disabled"}\n'
    return 0
  fi
  kv_overview_age_value="$(kv_overview_age)"
  case "$kv_overview_age_value" in ''|*[!0-9-]*) kv_overview_age_value=-1 ;; esac
  if [ "$kv_overview_age_value" -lt 0 ] || [ "$kv_overview_age_value" -ge "$KV_OVERVIEW_CACHE_TTL" ]; then
    kv_overview_start_refresh
  fi
  kv_overview_refreshing=false
  [ -d "$KV_OVERVIEW_LOCK" ] && kv_overview_refreshing=true
  if [ "$kv_overview_age_value" -ge 0 ] && kv_overview_valid; then
    kv_overview_fresh=false
    [ "$kv_overview_age_value" -lt "$KV_OVERVIEW_CACHE_TTL" ] && kv_overview_fresh=true
    jq --argjson age "$kv_overview_age_value" --argjson fresh "$kv_overview_fresh" --argjson refreshing "$kv_overview_refreshing" \
      '. + {source:"ram_snapshot",age_sec:$age,fresh:$fresh,stale:($fresh | not),refreshing:$refreshing}' "$KV_OVERVIEW_FILE"
  else
    jq -n --argjson refreshing "$kv_overview_refreshing" '{ok:false,state:"warming",refreshing:$refreshing}'
  fi
}

kv_cache_invalidate() {
  rm -f \
    "$KV_CACHE_DIR/status.json" "$KV_CACHE_DIR/status.json.at" \
    "$KV_CACHE_DIR/dashboard_summary.json" "$KV_CACHE_DIR/dashboard_summary.json.at" \
    "$KV_CACHE_DIR/profiles.json" "$KV_CACHE_DIR/profiles.json.at" \
    "$KV_CACHE_DIR/alerts.json" "$KV_CACHE_DIR/alerts.json.at" \
    "$KV_CACHE_DIR/metrics_history.json" "$KV_CACHE_DIR/metrics_history.json.at" \
    "$KV_CACHE_DIR/health_history.json" "$KV_CACHE_DIR/health_history.json.at" \
    "$KV_CACHE_DIR/router_info.json" "$KV_CACHE_DIR/router_info.json.at" \
    2>/dev/null || true
  kv_overview_invalidate
}

kv_cache_json() {
  kv_cache_key="$1"
  kv_cache_ttl_value="$2"
  kv_cache_command="$3"
  kv_cache_file="$KV_CACHE_DIR/$kv_cache_key.json"
  kv_cache_stamp="$KV_CACHE_DIR/$kv_cache_key.json.at"

  if [ "$kv_cache_ttl_value" -gt 0 ] && [ -f "$kv_cache_file" ]; then
    kv_now="$(date +%s)"
    kv_gen="$(cat "$kv_cache_stamp" 2>/dev/null || echo 0)"
    case "$kv_gen" in ''|*[!0-9]*) kv_gen=0 ;; esac
    kv_age=$((kv_now - kv_gen))
    if [ "$kv_age" -ge 0 ] && [ "$kv_age" -lt "$kv_cache_ttl_value" ] && jq -e . "$kv_cache_file" >/dev/null 2>&1; then
      cat "$kv_cache_file"
      return 0
    fi
  fi

  kv_out="$(/opt/bin/keenvless "$kv_cache_command")"
  printf '%s' "$kv_out"
  if [ "$kv_cache_ttl_value" -gt 0 ] && printf '%s' "$kv_out" | jq -e . >/dev/null 2>&1; then
    mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
    printf '%s' "$kv_out" > "$kv_cache_file.tmp.$$" 2>/dev/null && mv "$kv_cache_file.tmp.$$" "$kv_cache_file" 2>/dev/null || true
    date +%s > "$kv_cache_stamp.tmp.$$" 2>/dev/null && mv "$kv_cache_stamp.tmp.$$" "$kv_cache_stamp" 2>/dev/null || true
  fi
}

kv_home_snapshot() {
  kv_snapshot_dir="$KV_CACHE_DIR/.home-snapshot-$$"
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  if ! mkdir "$kv_snapshot_dir" 2>/dev/null; then
    printf '{"ok":false,"error":"snapshot temporary directory is unavailable"}\n'
    return 0
  fi

  ( kv_cache_json status "$KV_STATUS_CACHE_TTL" status > "$kv_snapshot_dir/status.json" ) &
  kv_status_pid=$!
  ( kv_cache_json profiles "$KV_PROFILES_CACHE_TTL" profiles > "$kv_snapshot_dir/profiles.json" ) &
  kv_profiles_pid=$!
  wait "$kv_status_pid" 2>/dev/null || true
  wait "$kv_profiles_pid" 2>/dev/null || true

  if ! jq -e . "$kv_snapshot_dir/status.json" >/dev/null 2>&1; then
    printf '{"ok":false,"error":"status failed"}\n' > "$kv_snapshot_dir/status.json"
  fi
  if ! jq -e . "$kv_snapshot_dir/profiles.json" >/dev/null 2>&1; then
    printf '{"ok":false,"error":"profiles failed"}\n' > "$kv_snapshot_dir/profiles.json"
  fi

  jq -n \
    --slurpfile status "$kv_snapshot_dir/status.json" \
    --slurpfile profiles "$kv_snapshot_dir/profiles.json" \
    '($status[0] // {ok:false,error:"status unavailable"}) as $s |
     ($profiles[0] // {ok:false,error:"profiles unavailable"}) as $p |
     {ok:(($s.ok // false) and ($p.ok // false)),status:$s,profiles:$p}'
  kv_snapshot_rc=$?
  rm -f "$kv_snapshot_dir/status.json" "$kv_snapshot_dir/profiles.json" 2>/dev/null || true
  rmdir "$kv_snapshot_dir" 2>/dev/null || true
  return "$kv_snapshot_rc"
}

case "$action" in
  update|scan|scan_current|scan_async|scan_status|scan_cancel|select|select_async|select_status|select_raw|set_config|set_dest_config|apply_profile|apply_scenario|enable|start|disable|stop|watchdog|mobile_watchdog|dns_monitor|health_report|route_on|route_off|route_batch|set_watchdog|set_mobile_watchdog|set_dns_monitor|set_server_group|set_favorites|device_group_save|device_group_delete|device_group_apply|rule_apply|route_preset_save|route_preset_apply|route_preset_delete|client_mode|manual_add|manual_rename|manual_duplicate|manual_delete|import_config|restore_backup|set_web_auth|set_yandex_oauth|set_remote_web|remote_web_apply|remote_web_off|update_begin|update_chunk|update_apply|update_cancel|update_cleanup|xray_candidate_install|update_github|install_auto|disable_auto|bootstrap|backup_config|rules_import|apply_config)
    kv_cache_invalidate
    ;;
esac

if [ "$action" = "home_snapshot" ]; then
  kv_home_snapshot
  exit 0
fi

if [ "$action" = "overview_snapshot" ]; then
  kv_overview_snapshot
  exit 0
fi

kv_cache_key=""
kv_cache_ttl_value=0
kv_cache_command=""
case "$action" in
  status|"") kv_cache_key="status"; kv_cache_ttl_value="$KV_STATUS_CACHE_TTL"; kv_cache_command="status" ;;
  dashboard_summary) kv_cache_key="dashboard_summary"; kv_cache_ttl_value="$KV_DASHBOARD_CACHE_TTL"; kv_cache_command="dashboard-summary" ;;
  profiles) kv_cache_key="profiles"; kv_cache_ttl_value="$KV_PROFILES_CACHE_TTL"; kv_cache_command="profiles" ;;
  alerts) kv_cache_key="alerts"; kv_cache_ttl_value="$KV_ALERTS_CACHE_TTL"; kv_cache_command="alerts" ;;
  metrics_history) kv_cache_key="metrics_history"; kv_cache_ttl_value="$KV_METRICS_CACHE_TTL"; kv_cache_command="metrics-history" ;;
  health_history) kv_cache_key="health_history"; kv_cache_ttl_value="$KV_HEALTH_HISTORY_CACHE_TTL"; kv_cache_command="health-history" ;;
  router_info) kv_cache_key="router_info"; kv_cache_ttl_value="$KV_ROUTER_INFO_CACHE_TTL"; kv_cache_command="router-info" ;;
esac
if [ -n "$kv_cache_key" ]; then
  kv_cache_json "$kv_cache_key" "$kv_cache_ttl_value" "$kv_cache_command"
  exit 0
fi

case "$action" in
  status|"") /opt/bin/keenvless status ;;
  version) /opt/bin/keenvless version ;;
  list) /opt/bin/keenvless list ;;
  update) /opt/bin/keenvless update ;;
  scan) /opt/bin/keenvless scan ;;
  scan_current) /opt/bin/keenvless scan "$server" ;;
  scan_async) /opt/bin/keenvless scan-async "$server" ;;
  scan_status) /opt/bin/keenvless scan-status ;;
  scan_cancel) /opt/bin/keenvless scan-cancel ;;
  watchdog) /opt/bin/keenvless watchdog ;;
  watchdog_status) /opt/bin/keenvless watchdog-status ;;
  watchdog_candidates) /opt/bin/keenvless watchdog-candidates ;;
  route_guard) /opt/bin/keenvless route-guard ;;
  set_watchdog) /opt/bin/keenvless set-watchdog "${watchdog_enabled:-0}" "${watchdog_interval_min:-5}" "${watchdog_probe_after_fails:-3}" "${watchdog_switch_after_fails:-6}" "${watchdog_candidate_count:-5}" "${watchdog_switch_cooldown_min:-15}" "${watchdog_fallback_direct:-1}" "${watchdog_restore_original:-1}" "${watchdog_quarantine_min:-30}" "${watchdog_restore_ok_count:-2}" "${watchdog_flap_window_min:-60}" "${watchdog_max_switches_window:-3}" ;;
  mobile_watchdog) /opt/bin/keenvless mobile-watchdog-now ;;
  mobile_watchdog_status) /opt/bin/keenvless mobile-watchdog-status ;;
  set_mobile_watchdog) /opt/bin/keenvless set-mobile-watchdog "${mobile_watchdog_enabled:-1}" "${mobile_watchdog_interval_min:-5}" "${mobile_watchdog_fail_min:-60}" "${mobile_watchdog_usb_off_sec:-10}" "${mobile_watchdog_iface:-auto}" ;;
  dns_monitor) /opt/bin/keenvless dns-monitor ;;
  dns_monitor_status) /opt/bin/keenvless dns-monitor-status ;;
  set_dns_monitor) /opt/bin/keenvless set-dns-monitor "${dns_monitor_enabled:-0}" "${dns_monitor_interval_min:-15}" "$dns_monitor_hosts" ;;
  external_ip) /opt/bin/keenvless external-ip ;;
  manual_list) /opt/bin/keenvless manual-list ;;
  manual_add)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-add "$manual_name" "$manual_link"
    ;;
  manual_rename)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-rename "$manual_id" "$manual_name"
    ;;
  manual_duplicate)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-duplicate "$manual_id" "$manual_name"
    ;;
  manual_test)
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-test "$manual_link"
    ;;
  provider_debug) /opt/bin/keenvless provider-debug "$server" ;;
  xray_env) /opt/bin/keenvless xray-env ;;
  profiles) /opt/bin/keenvless profiles ;;
  hysteria_diagnostics) /opt/bin/keenvless hysteria-diagnostics ;;
  dependency_doctor|doctor) /opt/bin/keenvless dependency-doctor ;;
  bootstrap_script) /opt/bin/keenvless bootstrap-script ;;
  rescue_status|rescue_wg_status) /opt/bin/keenvless rescue-status ;;
  rescue_wireguard|rescue_wg_plan|rescue_plan) /opt/bin/keenvless rescue-wireguard ;;
  manual_delete) /opt/bin/keenvless manual-delete "$manual_id" ;;
  install_auto) /opt/bin/keenvless install-auto ;;
  disable_auto) /opt/bin/keenvless disable-auto ;;
  clients) /opt/bin/keenvless clients ;;
  backup_config) /opt/bin/keenvless backup-config ;;
  backups) /opt/bin/keenvless backups ;;
  backup_preview) /opt/bin/keenvless backup-preview "$backup" ;;
  restore_backup) /opt/bin/keenvless restore-backup "$backup" ;;
  favorites) /opt/bin/keenvless favorites ;;
  set_favorites) /opt/bin/keenvless set-favorites "$favorites" ;;
  export_config) /opt/bin/keenvless export-config ;;
  import_config) /opt/bin/keenvless import-config-b64 "$import_b64" ;;
  route_profiles) /opt/bin/keenvless route-profiles ;;
  apply_profile) /opt/bin/keenvless apply-profile "${route_profile:-geo}" ;;
  route_scenarios) /opt/bin/keenvless route-scenarios ;;
  apply_scenario) /opt/bin/keenvless apply-scenario "${route_scenario:-geo_home}" ;;
  client_mode) /opt/bin/keenvless client-mode "${client:-$client_ip}" "${client_mode:-inherit}" ;;
  device_groups) /opt/bin/keenvless device-groups ;;
  device_group_save) /opt/bin/keenvless device-group-save "$group_id" "$group_name" "${group_mode:-inherit}" "$group_members" ;;
  device_group_delete) /opt/bin/keenvless device-group-delete "$group_id" ;;
  device_group_apply) /opt/bin/keenvless device-group-apply "$group_id" ;;
  rule_center) /opt/bin/keenvless rule-center "${client:-$client_ip}" ;;
  rule_preview) /opt/bin/keenvless rule-preview "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$route_destinations" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  rule_apply) /opt/bin/keenvless rule-apply "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$group_id" "${rule_apply_dest:-0}" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  route_presets) /opt/bin/keenvless route-presets ;;
  route_preset_save) /opt/bin/keenvless route-preset-save "$preset_name" "$preset_id" ;;
  route_preset_apply) /opt/bin/keenvless route-preset-apply "$preset_id" ;;
  route_preset_delete) /opt/bin/keenvless route-preset-delete "$preset_id" ;;
  server_groups) /opt/bin/keenvless server-groups ;;
  set_server_group) /opt/bin/keenvless set-server-group "${server_group:-auto}" ;;
  route_explain) /opt/bin/keenvless route-explain "${client:-$client_ip}" "$destination" ;;
  dns_check) /opt/bin/keenvless dns-check "$destination" ;;
  connections) /opt/bin/keenvless connections ;;
  events) /opt/bin/keenvless events "${event_kind:-all}" ;;
  update_history) /opt/bin/keenvless update-history ;;
  alerts) /opt/bin/keenvless alerts ;;
  dashboard_summary) /opt/bin/keenvless dashboard-summary ;;
  route_batch) /opt/bin/keenvless route-batch "${client:-$client_ip}" "$route_destinations" ;;
  traffic_plan) /opt/bin/keenvless traffic-plan "${client:-$client_ip}" "$route_destinations" ;;
  support_report) /opt/bin/keenvless support-report ;;
  rules_export) /opt/bin/keenvless rules-export ;;
  rules_import) /opt/bin/keenvless rules-import-b64 "$rules_b64" ;;
  logs) /opt/bin/keenvless logs ;;
  check_current) /opt/bin/keenvless check-current ;;
  whoami) printf '{"ok":true,"ip":"%s","remote_addr":"%s","auth":"%s","phone":"%s"}\n' "$client_ip" "$REMOTE_ADDR" "$auth_method" "${KVX_AUTH_PHONE:-}" ;;
  diagnostics) /opt/bin/keenvless diagnostics ;;
  health_report) /opt/bin/keenvless health-report "$health_client" ;;
  health_history) /opt/bin/keenvless health-history ;;
  metrics_history) /opt/bin/keenvless metrics-history ;;
  self_test) /opt/bin/keenvless self-test ;;
  router_info) /opt/bin/keenvless router-info ;;
  update_status) /opt/bin/keenvless update-status ;;
  update_begin) /opt/bin/keenvless update-begin "$update_version" "$update_size" "$update_sha256" ;;
  update_chunk) /opt/bin/keenvless update-chunk "$update_id" "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  update_apply) /opt/bin/keenvless update-apply "$update_id" ;;
  xray_candidate_begin) /opt/bin/keenvless xray-candidate-begin "$update_size" "$update_sha256" ;;
  xray_candidate_chunk) /opt/bin/keenvless xray-candidate-chunk "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  xray_candidate_status) /opt/bin/keenvless xray-candidate-status ;;
  xray_candidate_check) /opt/bin/keenvless xray-candidate-check ;;
  xray_candidate_fetch) /opt/bin/keenvless xray-candidate-fetch "$xray_url" "$update_sha256" ;;
  xray_candidate_provider_debug) /opt/bin/keenvless xray-candidate-provider-debug "$server" ;;
  xray_candidate_install) /opt/bin/keenvless xray-candidate-install "$update_sha256" ;;
  update_cancel) /opt/bin/keenvless update-cancel "$update_id" ;;
  update_cleanup) /opt/bin/keenvless update-cleanup "$update_id" ;;
  update_export) /opt/bin/keenvless update-export ;;
  github_check) /opt/bin/keenvless github-check "$github_repo" ;;
  update_github)
    id="github-$(date +%s)-$$"
    jq -n --arg id "$id" --arg tag "$github_tag" --arg repo "$github_repo" '{ok:true,state:"github_queued",id:$id,tag:$tag,repo:$repo}' > /opt/var/lib/keenvless/update-status.json 2>/dev/null || true
    ( /opt/bin/keenvless update-github "$github_tag" "$github_repo" "$github_token" >> /opt/var/log/keenvless-update.log 2>&1 ) &
    printf '{"ok":true,"state":"github_started","id":"%s"}\n' "$id"
    ;;
  github_probe) /opt/bin/keenvless github-probe "$github_tag" "$github_repo" ;;
  github_asset_probe) /opt/bin/keenvless github-asset-probe "$github_tag" "$github_repo" ;;
  router_targets) /opt/bin/keenvless router-targets ;;
  router_local_name) /opt/bin/keenvless router-local-name "$router_local_name" ;;
  router_target_add) /opt/bin/keenvless router-target-add "$router_name" "$router_url" "$router_token" ;;
  router_target_delete) /opt/bin/keenvless router-target-delete "$router_id" ;;
  router_target_test) /opt/bin/keenvless router-target-test "${router_id:-local}" ;;
  router_compare) /opt/bin/keenvless router-compare ;;
  router_sync_rules) /opt/bin/keenvless router-sync-rules "${sync_from:-$router_id}" "${sync_to:-$update_id}" ;;
  router_backup_all) /opt/bin/keenvless router-backup-all ;;
  bootstrap) /opt/bin/keenvless bootstrap ;;
  select) /opt/bin/keenvless select "$server" ;;
  select_async) /opt/bin/keenvless select-async "$server" ;;
  select_status) /opt/bin/keenvless select-status "$select_id" ;;
  select_raw) /opt/bin/keenvless select-raw "$server" ;;
  enable|start) /opt/bin/keenvless enable ;;
  disable|stop) /opt/bin/keenvless disable ;;
  route_on) /opt/bin/keenvless route-on "${client:-$client_ip}" ;;
  route_off) /opt/bin/keenvless route-off "$client" ;;
  config) /opt/bin/keenvless config ;;
  set_config) /opt/bin/keenvless set-config "${sources:-$client_ip}" "${ports:-80,443}" "${block_udp443:-1}" "$proxy_sources" "$direct_sources" ;;
  set_dest_config) /opt/bin/keenvless set-dest-config "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  set_web_auth) /opt/bin/keenvless set-web-auth "${token_required:-0}" "$web_token" ;;
  set_yandex_oauth) /opt/bin/keenvless set-yandex-oauth "${yandex_oauth_enabled:-0}" "$yandex_client_id" "$yandex_client_secret" "$yandex_allowed_phones" "$yandex_session_ttl_sec" "$yandex_redirect_uri" ;;
  set_remote_web) /opt/bin/keenvless set-remote-web "${remote_web_enabled:-0}" "${remote_web_port:-8088}" "$remote_web_sources" ;;
  apply_config) /opt/bin/keenvless route-on "${sources:-$client_ip}" ;;
  *) printf '{"ok":false,"error":"unknown action"}\n' ;;
esac
