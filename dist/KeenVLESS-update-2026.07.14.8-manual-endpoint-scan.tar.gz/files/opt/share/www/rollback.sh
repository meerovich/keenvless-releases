#!/bin/sh
set -eu

PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
CONF=/opt/etc/keenvless/keenvless.conf
ARCHIVE=/opt/share/www/.keenvless-rollback/previous-release.tar.gz
ARCHIVE_SHA=/opt/share/www/.keenvless-rollback/previous-release.tar.gz.sha256
EXPECTED_VERSION=2026.07.14.2-demand-snapshot
DATA_DIR=/opt/var/lib/keenvless

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  content_length="${CONTENT_LENGTH:-0}"
  case "$content_length" in ''|*[!0-9]*) content_length=0 ;; esac
  post_body="$(head -c "$content_length" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    [ -n "$request_params" ] && request_params="$request_params&$post_body" || request_params="$post_body"
  fi
fi

param() {
  printf '%s' "$request_params" | awk -v RS='&' -F= -v k="$1" '$1 == k {print substr($0, length(k) + 2); exit}'
}

json_error() {
  rollback_message="$1"
  printf '{"ok":false,"error":%s}\n' "$(printf '%s' "$rollback_message" | jq -Rs . 2>/dev/null || printf '"rollback error"')"
  exit 1
}

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

[ -r "$CONF" ] || json_error "configuration not found"
. "$CONF"
request_token="$(param token)"
[ -n "${TOKEN:-}" ] && [ "$request_token" = "$TOKEN" ] || json_error "unauthorized"

rollback_work="/tmp/keenvless-release-rollback-$$"
rollback_stage="/opt/share/.keenvless-rollback-www-$$"
rollback_old="/opt/share/.keenvless-before-rollback-$$"

cleanup() {
  rm -rf "$rollback_work" "$rollback_stage" 2>/dev/null || true
}
trap cleanup 0 1 2 15

prepare_archive() {
  [ -s "$ARCHIVE" ] || json_error "rollback archive not found"
  [ -s "$ARCHIVE_SHA" ] || json_error "rollback checksum not found"
  rollback_expected_sha="$(cat "$ARCHIVE_SHA" 2>/dev/null || true)"
  rollback_actual_sha="$(sha256sum "$ARCHIVE" 2>/dev/null | awk '{print $1}')"
  [ -n "$rollback_expected_sha" ] && [ "$rollback_actual_sha" = "$rollback_expected_sha" ] \
    || json_error "rollback archive checksum mismatch"
  rm -rf "$rollback_work"
  mkdir -p "$rollback_work" || json_error "cannot prepare rollback directory"
  tar -xzf "$ARCHIVE" -C "$rollback_work" >/dev/null 2>&1 || json_error "cannot unpack rollback archive"
  jq -e --arg version "$EXPECTED_VERSION" '.app == "KeenVLESS" and .package_version == 1 and .version == $version' \
    "$rollback_work/manifest.json" >/dev/null 2>&1 || json_error "unexpected rollback package"
  [ -s "$rollback_work/files/opt/bin/keenvless" ] || json_error "rollback core is missing"
  [ -s "$rollback_work/files/opt/share/www/api.sh" ] || json_error "rollback API is missing"
}

copy_atomic() {
  rollback_source="$1"
  rollback_target="$2"
  rollback_mode="$3"
  [ -s "$rollback_source" ] || return 1
  cp "$rollback_source" "$rollback_target.rollback-new" || return 1
  chmod "$rollback_mode" "$rollback_target.rollback-new" 2>/dev/null || true
  mv "$rollback_target.rollback-new" "$rollback_target" || return 1
}

install_previous_www() {
  rollback_www_source="$rollback_work/files/opt/share/www"
  [ -s "$rollback_www_source/index.html" ] && [ -s "$rollback_www_source/api.sh" ] || return 1
  rm -rf "$rollback_stage" "$rollback_old"
  mkdir -p "$rollback_stage" || return 1
  cp -R "$rollback_www_source/." "$rollback_stage/" || return 1
  cp "$0" "$rollback_stage/rollback.sh" 2>/dev/null || true
  [ -d /opt/share/www/.keenvless-rollback ] \
    && cp -R /opt/share/www/.keenvless-rollback "$rollback_stage/.keenvless-rollback" 2>/dev/null || true
  chmod 0755 "$rollback_stage/api.sh" "$rollback_stage/oauth-yandex-start.sh" "$rollback_stage/oauth-yandex-callback.sh" "$rollback_stage/rollback.sh" 2>/dev/null || true
  mv /opt/share/www "$rollback_old" || return 1
  if mv "$rollback_stage" /opt/share/www; then
    return 0
  fi
  mv "$rollback_old" /opt/share/www 2>/dev/null || true
  return 1
}

restore_previous_www() {
  [ -d "$rollback_old" ] || return 0
  rollback_failed="/opt/share/.keenvless-failed-rollback-$$"
  rm -rf "$rollback_failed"
  mv /opt/share/www "$rollback_failed" 2>/dev/null || true
  mv "$rollback_old" /opt/share/www 2>/dev/null || true
  rm -rf "$rollback_failed"
}

backup_current_application() {
  rollback_current="$rollback_work/current"
  mkdir -p "$rollback_current" || return 1
  cp /opt/bin/keenvless "$rollback_current/keenvless" \
    && cp /opt/etc/init.d/S99keenvless "$rollback_current/S99keenvless" \
    && cp /opt/etc/lighttpd/conf.d/99-keenvless.conf "$rollback_current/99-keenvless.conf"
}

restore_current_application() {
  restore_previous_www
  copy_atomic "$rollback_work/current/S99keenvless" /opt/etc/init.d/S99keenvless 0755 2>/dev/null || true
  copy_atomic "$rollback_work/current/99-keenvless.conf" /opt/etc/lighttpd/conf.d/99-keenvless.conf 0644 2>/dev/null || true
  copy_atomic "$rollback_work/current/keenvless" /opt/bin/keenvless 0755 2>/dev/null || true
}

validate_installed_application() {
  rollback_response="$rollback_work/validate-response.txt"
  rollback_body="$rollback_work/validate-body.json"
  /opt/bin/keenvless version 2>/dev/null \
    | jq -e --arg version "$EXPECTED_VERSION" '.ok == true and .version == $version' >/dev/null 2>&1 \
    || return 1
  /opt/bin/keenvless self-test 2>/dev/null | jq -e '.ok == true' >/dev/null 2>&1 || return 1
  REQUEST_METHOD=GET QUERY_STRING="action=status&token=$request_token" CONTENT_LENGTH=0 REMOTE_ADDR=127.0.0.1 \
    /bin/sh /opt/share/www/api.sh > "$rollback_response" 2>/dev/null || return 1
  tr -d '\r' < "$rollback_response" | awk 'body {print} /^$/ {body=1}' > "$rollback_body"
  jq -e --arg version "$EXPECTED_VERSION" '.ok == true and .version == $version' \
    "$rollback_body" >/dev/null 2>&1
}

action="$(param action)"
[ -n "$action" ] || action=verify
case "$action" in
  verify)
    prepare_archive
    jq -n --arg version "$EXPECTED_VERSION" --arg sha256 "$rollback_actual_sha" \
      '{ok:true,state:"ready",rollback_version:$version,sha256:$sha256,changes_vpn:false}'
    ;;
  rollback)
    [ "${REQUEST_METHOD:-GET}" = "POST" ] || json_error "rollback requires POST"
    [ "$(param confirm)" = "rollback" ] || json_error "rollback confirmation missing"
    prepare_archive
    backup_current_application || json_error "cannot preserve current application before rollback"
    install_previous_www || json_error "cannot install previous web files"
    if ! copy_atomic "$rollback_work/files/opt/etc/init.d/S99keenvless" /opt/etc/init.d/S99keenvless 0755 \
      || ! copy_atomic "$rollback_work/files/opt/etc/lighttpd/conf.d/99-keenvless.conf" /opt/etc/lighttpd/conf.d/99-keenvless.conf 0644 \
      || ! copy_atomic "$rollback_work/files/opt/bin/keenvless" /opt/bin/keenvless 0755; then
      restore_current_application
      json_error "cannot restore previous application files"
    fi
    if ! validate_installed_application; then
      restore_current_application
      json_error "restored application did not pass validation"
    fi
    rm -rf "$rollback_old"
    mkdir -p "$DATA_DIR"
    jq -n --arg version "$EXPECTED_VERSION" '{ok:true,state:"rolled_back",version:$version,rolled_back_at:(now|floor),changes_vpn:false}' \
      > "$DATA_DIR/release-rollback-last.json" 2>/dev/null || true
    jq -n --arg version "$EXPECTED_VERSION" '{ok:true,state:"rolled_back",version:$version,changes_vpn:false}'
    ;;
  *)
    json_error "unknown rollback action"
    ;;
esac
