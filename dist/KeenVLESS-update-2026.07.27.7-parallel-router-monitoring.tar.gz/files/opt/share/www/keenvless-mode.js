(() => {
  if (window.__keenvlessMode) return;
  window.__keenvlessMode = true;

  const APP_VERSION = "2026.07.27.7-parallel-router-monitoring";
  const MAIN_JS = "main-VJ2XDXZB.js";
  const ENHANCER_JS = "keenvless-enhancer.js";
  const params = new URL(location.href).searchParams;
  const token = params.get("token") || "";
  const expert = params.get("expert") === "1" || params.get("mode") === "expert";
  const SESSION_SNAPSHOT_KEY = `keenvless-simple-snapshot-${APP_VERSION}`;
  const SESSION_SNAPSHOT_MAX_AGE_MS = 15 * 60 * 1000;
  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (value) => String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const b64 = (value) => btoa(unescape(encodeURIComponent(value)));

  function addScript(src, attrs = {}) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      Object.entries(attrs).forEach(([key, value]) => { script[key] = value; });
      script.onload = resolve;
      script.onerror = () => reject(new Error(`script load failed: ${src}`));
      document.body.appendChild(script);
    });
  }

  function enterExpert() {
    const url = new URL(location.href);
    url.searchParams.set("expert", "1");
    url.hash = "#/servers";
    location.href = url.toString();
  }

  function enterSimple() {
    const url = new URL(location.href);
    url.searchParams.delete("expert");
    url.searchParams.delete("mode");
    if (!url.hash) url.hash = "#/health";
    location.href = url.toString();
  }

  async function loadExpertMode() {
    document.documentElement.classList.add("kvx-expert-mode");
    // The legacy Angular bundle compares its own build label with the backend
    // release and otherwise reloads once per browser session.  The wrapper is
    // already versioned and loads the bundle with the release cache key, so the
    // extra navigation is both unnecessary and expensive over KeenDNS.
    try { sessionStorage.setItem(`keenvless.reload.${APP_VERSION}`, "1"); } catch {}
    const preload = document.createElement("link");
    preload.rel = "modulepreload";
    preload.href = "chunk-ZOPAZJ2U.js";
    document.head.appendChild(preload);
    await Promise.all([
      addScript(`${MAIN_JS}?v=${APP_VERSION}`, { type: "module" }),
      addScript(`${ENHANCER_JS}?v=${APP_VERSION}`, { defer: true })
    ]);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = "Простой режим";
    btn.className = "kvx-simple-switch";
    btn.addEventListener("click", enterSimple);
    document.body.appendChild(btn);
  }

  if (expert) {
    const style = document.createElement("style");
    style.textContent = ".kvx-simple-switch{position:fixed;left:14px;bottom:14px;z-index:2100;border:1px solid var(--line-strong,#c3ced8);border-radius:999px;background:var(--panel,#fff);color:var(--text,#17212b);box-shadow:0 8px 24px #0003;min-height:42px;padding:0 14px;font:600 13px Inter,system-ui,sans-serif;cursor:pointer}";
    document.head.appendChild(style);
    loadExpertMode().catch((err) => {
      const root = $("app-root") || document.body;
      root.innerHTML = `<main class="ks-shell"><section class="ks-card danger"><h1>Не загрузил экспертный режим</h1><p>${esc(err.message)}</p><button id="ks-simple-fallback">Открыть простой режим</button></section></main>`;
      $("#ks-simple-fallback")?.addEventListener("click", enterSimple);
    });
    return;
  }

  const css = `
    app-root{display:block}
    .ks-shell{min-height:100vh;padding:18px;max-width:1100px;margin:0 auto;font:14px Inter,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:var(--text,#17212b)}
    .ks-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:14px}
    .ks-head h1{margin:0;font-size:26px;line-height:1.1}.ks-head p{margin:6px 0 0;color:var(--muted,#5f7080);line-height:1.4}
    .ks-actions{display:flex;flex-wrap:wrap;gap:8px}.ks-btn{border:1px solid var(--line-strong,#c3ced8);border-radius:10px;background:var(--panel,#fff);color:var(--text,#17212b);min-height:42px;padding:0 13px;font:600 13px Inter,system-ui,sans-serif;cursor:pointer}.ks-btn.primary{background:var(--brand,#0b5cad);border-color:var(--brand,#0b5cad);color:#fff}.ks-btn.danger{border-color:#a9343480;color:#a93434}.ks-btn:disabled{opacity:.55;cursor:progress}.ks-btn:focus-visible{outline:3px solid color-mix(in srgb,var(--brand,#0b5cad) 42%,transparent);outline-offset:2px}
    .ks-hero{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(260px,.8fr);gap:12px;margin-bottom:12px}.ks-card{border:1px solid var(--line,#d8e0e8);border-radius:16px;background:var(--panel,#fff);box-shadow:0 8px 26px #00000012;padding:16px}.ks-card.soft{background:var(--panel-soft,#f8fafc)}.ks-card h2,.ks-card h3{margin:0 0 8px}.ks-card p{margin:0;color:var(--muted,#5f7080);line-height:1.45}
    .ks-status{display:grid;gap:8px}.ks-status-main{display:flex;align-items:center;gap:10px;font-size:28px;font-weight:800}.ks-dot{width:16px;height:16px;border-radius:999px;background:var(--warn,#a66a00);box-shadow:0 0 0 6px #a66a0020}.ks-dot.ok{background:var(--ok,#1e6654);box-shadow-color:#1e665420}.ks-dot.fail{background:var(--danger,#a93434);box-shadow-color:#a9343420}
    .ks-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));gap:12px}.ks-kv{display:grid;grid-template-columns:110px minmax(0,1fr);gap:6px 10px}.ks-kv span{color:var(--muted,#5f7080)}.ks-kv b{overflow-wrap:anywhere}.ks-tag{display:inline-flex;align-items:center;min-height:26px;border:1px solid var(--line-strong,#c3ced8);border-radius:999px;padding:0 9px;background:var(--panel-soft,#f8fafc);color:var(--muted,#5f7080);font-size:12px}.ks-tag.ok{border-color:#1e665480;color:#1e6654}.ks-tag.warn{border-color:#a66a0080;color:#a66a00}.ks-tag.fail{border-color:#a9343480;color:#a93434}.ks-tag.hy2{border-color:#0b5cad80;color:#0b5cad}
    .ks-list{display:grid;gap:8px}.ks-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;border:1px solid var(--line,#d8e0e8);border-radius:12px;background:var(--panel-soft,#f8fafc);padding:10px}.ks-row.active{border-color:var(--brand,#0b5cad);box-shadow:inset 0 0 0 1px #0b5cad80}.ks-row strong,.ks-row span,.ks-row em{display:block;overflow-wrap:anywhere}.ks-row em{color:var(--muted,#5f7080);font-style:normal;font-size:12px}
    .ks-log{white-space:pre-wrap;max-height:180px;overflow:auto;border:1px solid var(--line,#d8e0e8);border-radius:12px;background:var(--panel-soft,#f8fafc);padding:10px;color:var(--muted,#5f7080)}.ks-hidden{display:none!important}
    .ks-login{max-width:620px;margin:12vh auto 0}.ks-login h1{margin:0 0 8px;font-size:28px}.ks-login p{margin:0 0 14px;color:var(--muted,#5f7080);line-height:1.5}.ks-login .ks-actions{margin-top:14px}
    @media(max-width:760px){.ks-shell{padding:12px}.ks-head,.ks-hero{grid-template-columns:1fr;display:grid}.ks-actions{width:100%}.ks-actions .ks-btn{flex:1 1 100%;width:100%;min-height:44px}.ks-row{grid-template-columns:1fr;align-items:stretch}.ks-row>.ks-btn{width:100%;min-height:46px}.ks-kv{grid-template-columns:86px minmax(0,1fr)}}
  `;

  let state = { busy: false, data: null, profileById: {}, lastMessage: "", refreshPromise: null, snapshotRefreshTimer: null };

  function xhrPost(body, timeoutMs) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "api.sh", true);
      xhr.timeout = timeoutMs;
      xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
      xhr.onload = () => resolve({ ok: true, status: xhr.status, text: xhr.responseText || "" });
      xhr.onerror = () => resolve({ ok: false, error: "xhr network error" });
      xhr.ontimeout = () => resolve({ ok: false, error: "xhr timeout" });
      xhr.send(body);
    });
  }

  async function api(paramsObj, timeoutMs = 120000) {
    const body = new URLSearchParams({ token, ...paramsObj });
    try {
      let text = "";
      let status = 0;
      if (typeof fetch === "function" && typeof AbortController === "function") {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
          const resp = await fetch("api.sh", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body, signal: ctrl.signal });
          status = resp.status;
          text = await resp.text();
        } finally {
          clearTimeout(timer);
        }
      } else {
        const xhr = await xhrPost(body.toString(), timeoutMs);
        if (!xhr.ok) return xhr;
        status = xhr.status;
        text = xhr.text;
      }
      try { return JSON.parse(text); } catch { return { ok: false, status, text: text.slice(0, 1000) }; }
    } catch (err) {
      return { ok: false, error: err?.message || String(err) };
    }
  }

  async function rollbackApi(paramsObj, timeoutMs = 120000) {
    const body = new URLSearchParams({ token, ...paramsObj });
    try {
      let text = "";
      let status = 0;
      if (typeof fetch === "function" && typeof AbortController === "function") {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
          const resp = await fetch("rollback.sh", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body, signal: ctrl.signal });
          status = resp.status;
          text = await resp.text();
        } finally {
          clearTimeout(timer);
        }
      } else {
        const xhr = await new Promise((resolve) => {
          const request = new XMLHttpRequest();
          request.open("POST", "rollback.sh", true);
          request.timeout = timeoutMs;
          request.setRequestHeader("content-type", "application/x-www-form-urlencoded");
          request.onload = () => resolve({ ok: true, status: request.status, text: request.responseText || "" });
          request.onerror = () => resolve({ ok: false, error: "xhr network error" });
          request.ontimeout = () => resolve({ ok: false, error: "xhr timeout" });
          request.send(body.toString());
        });
        if (!xhr.ok) return xhr;
        status = xhr.status;
        text = xhr.text;
      }
      try { return JSON.parse(text); } catch { return { ok: false, status, text: text.slice(0, 1000) }; }
    } catch (err) {
      return { ok: false, error: err?.message || String(err) };
    }
  }

  async function runLimited(tasks, limit = 2) {
    const result = {};
    let next = 0;
    const workers = Array.from({ length: Math.min(limit, tasks.length) }, async () => {
      while (next < tasks.length) {
        const task = tasks[next++];
        result[task.key] = await task.run().catch((err) => ({ ok: false, error: err?.message || String(err) }));
      }
    });
    await Promise.all(workers);
    return result;
  }

  async function loadHomeSnapshot(options = {}) {
    let overviewSnapshot = null;
    if (options.forceLive !== true) {
      overviewSnapshot = await api({ action: "overview_snapshot" }, 15000);
      if (overviewSnapshot?.snapshot?.status?.ok === true && overviewSnapshot?.snapshot?.profiles?.ok === true) {
        overviewSnapshot = {
          ...overviewSnapshot.snapshot,
          source: overviewSnapshot.source,
          age_sec: overviewSnapshot.age_sec,
          fresh: overviewSnapshot.fresh,
          stale: overviewSnapshot.stale,
          refreshing: overviewSnapshot.refreshing
        };
      }
      if (overviewSnapshot?.status?.ok === true && overviewSnapshot?.profiles?.ok === true) {
        return {
          status: overviewSnapshot.status,
          profiles: overviewSnapshot.profiles,
          homeSnapshot: overviewSnapshot,
          overviewSnapshot
        };
      }
      if (overviewSnapshot?.state === "warming" && state.data?.status?.ok === true && state.data?.profiles?.ok === true) {
        return {
          status: state.data.status,
          profiles: state.data.profiles,
          homeSnapshot: { ok: true, status: state.data.status, profiles: state.data.profiles },
          overviewSnapshot: { ...overviewSnapshot, source: "session_snapshot", stale: true, fresh: false }
        };
      }
    }
    const snapshot = await api({ action: "home_snapshot" }, 90000);
    if (snapshot?.status?.ok === true && snapshot?.profiles?.ok === true) {
      return { status: snapshot.status, profiles: snapshot.profiles, homeSnapshot: snapshot, overviewSnapshot };
    }
    const fallback = await runLimited([
      { key: "status", run: () => api({ action: "status" }, 90000) },
      { key: "profiles", run: () => api({ action: "profiles" }, 90000) }
    ], 2);
    return { ...fallback, homeSnapshot: snapshot, overviewSnapshot, snapshotFallback: true };
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function cachedHealth(data) {
    return data?.health || data?.status?.health_last || {};
  }

  function snapshotText(value, max = 320) {
    return String(value ?? "").slice(0, max);
  }

  function snapshotNumber(value) {
    if (value === "" || value === null || value === undefined) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function snapshotCount(value) {
    const number = snapshotNumber(value);
    return number === null || number < 0 ? 0 : Math.floor(number);
  }

  function snapshotHealth(health = {}) {
    const current = health?.current_server || {};
    return {
      ok: health?.ok === true,
      overall: snapshotText(health?.overall || "unknown", 32),
      checked_at: snapshotCount(health?.checked_at),
      summary: {
        checks: snapshotCount(health?.summary?.checks),
        fails: snapshotCount(health?.summary?.fails),
        warns: snapshotCount(health?.summary?.warns)
      },
      current_server: {
        ok: current?.ok === true,
        ip: snapshotText(current?.ip, 128),
        youtube: snapshotText(current?.youtube, 64),
        reason: snapshotText(current?.reason, 240)
      }
    };
  }

  function snapshotStatus(status = {}) {
    return {
      ok: status?.ok === true,
      version: snapshotText(status?.version, 96),
      api_version: snapshotCount(status?.api_version),
      min_ui_version: snapshotText(status?.min_ui_version, 96),
      running: status?.running === true,
      selected: snapshotText(status?.selected, 128),
      selected_health: snapshotText(status?.selected_health, 48),
      selected_latency_ms: snapshotNumber(status?.selected_latency_ms),
      selected_checked_at: snapshotNumber(status?.selected_checked_at),
      route_profile: snapshotText(status?.route_profile, 80),
      server_group: snapshotText(status?.server_group, 96),
      servers: snapshotCount(status?.servers),
      crond_running: status?.crond_running === true,
      watchdog_enabled: snapshotCount(status?.watchdog_enabled),
      system_monitor: {
        last_checked_at: snapshotCount(status?.system_monitor?.last_checked_at),
        last_uptime_s: snapshotCount(status?.system_monitor?.last_uptime_s),
        boot_estimated_at: snapshotCount(status?.system_monitor?.boot_estimated_at),
        last_reboot_detected_at: snapshotCount(status?.system_monitor?.last_reboot_detected_at),
        reset_reason: snapshotText(status?.system_monitor?.reset_reason, 240),
        crash_dump_present: status?.system_monitor?.crash_dump_present === true
      },
      reboot_summary: {
        total: snapshotCount(status?.reboot_summary?.total),
        last_24h: snapshotCount(status?.reboot_summary?.last_24h),
        last_7d: snapshotCount(status?.reboot_summary?.last_7d),
        last: status?.reboot_summary?.last ? {
          detected_at: snapshotCount(status.reboot_summary.last.detected_at),
          estimated_boot_at: snapshotCount(status.reboot_summary.last.estimated_boot_at),
          reset_reason: snapshotText(status.reboot_summary.last.reset_reason, 240)
        } : null
      },
      connectivity: {
        last_check_at: snapshotCount(status?.connectivity?.last_check_at),
        wan: {
          ok: status?.connectivity?.wan?.ok === true,
          failures: snapshotCount(status?.connectivity?.wan?.failures),
          last_ok_at: snapshotCount(status?.connectivity?.wan?.last_ok_at),
          iface: snapshotText(status?.connectivity?.wan?.iface, 64),
          external_ip: snapshotText(status?.connectivity?.wan?.external_ip, 128)
        },
        cloud: {
          supported: status?.connectivity?.cloud?.supported === true,
          ok: status?.connectivity?.cloud?.ok === true,
          failures: snapshotCount(status?.connectivity?.cloud?.failures),
          last_ok_at: snapshotCount(status?.connectivity?.cloud?.last_ok_at),
          agent_state: snapshotText(status?.connectivity?.cloud?.agent_state, 64),
          access: snapshotText(status?.connectivity?.cloud?.access, 64)
        },
        remote_syslog: {
          configured: status?.connectivity?.remote_syslog?.configured === true,
          servers: Array.isArray(status?.connectivity?.remote_syslog?.servers)
            ? status.connectivity.remote_syslog.servers.slice(0, 8).map((value) => snapshotText(value, 240))
            : []
        }
      },
      health_last: snapshotHealth(status?.health_last)
    };
  }

  function snapshotProfile(profile = {}) {
    return {
      id: snapshotText(profile?.id, 128),
      name: snapshotText(profile?.name || profile?.name_ru || profile?.name_en, 320),
      source: snapshotText(profile?.source, 32),
      profile_kind: snapshotText(profile?.profile_kind, 32),
      protocol: snapshotText(profile?.protocol, 32),
      display_protocol: snapshotText(profile?.display_protocol, 48),
      health: snapshotText(profile?.health || "unknown", 48),
      note: snapshotText(profile?.note, 320),
      latency_ms: snapshotNumber(profile?.latency_ms),
      checked_at: snapshotNumber(profile?.checked_at),
      active: profile?.active === true,
      country_code: snapshotText(profile?.country_code, 16),
      favorite: profile?.favorite === true,
      user: snapshotText(profile?.user, 160),
      server: snapshotText(profile?.server, 320),
      port: snapshotText(profile?.port, 16),
      sni: snapshotText(profile?.sni, 320),
      obfs: snapshotText(profile?.obfs, 64),
      pin_present: profile?.pin_present === true
    };
  }

  function snapshotProfiles(profiles = {}) {
    const rows = Array.isArray(profiles?.profiles) ? profiles.profiles.slice(0, 120).map(snapshotProfile).filter((item) => item.id) : [];
    const selected = snapshotText(profiles?.selected, 128);
    const duplicateUsers = Array.isArray(profiles?.duplicate_hysteria_users)
      ? profiles.duplicate_hysteria_users.slice(0, 20).map((item) => ({
        user: snapshotText(item?.user, 160),
        count: snapshotCount(item?.count),
        profiles: Array.isArray(item?.profiles) ? item.profiles.slice(0, 20).map((profile) => ({
          id: snapshotText(profile?.id, 128),
          name: snapshotText(profile?.name, 320),
          active: profile?.active === true
        })) : []
      })).filter((item) => item.user)
      : [];
    return {
      ok: profiles?.ok === true,
      selected,
      selected_profile: rows.find((item) => item.active) || rows.find((item) => item.id === selected) || null,
      duplicate_hysteria_users: duplicateUsers,
      summary: {
        total: snapshotCount(profiles?.summary?.total),
        provider: snapshotCount(profiles?.summary?.provider),
        manual: snapshotCount(profiles?.summary?.manual),
        hysteria2: snapshotCount(profiles?.summary?.hysteria2),
        duplicate_hysteria_users: snapshotCount(profiles?.summary?.duplicate_hysteria_users)
      },
      profiles: rows
    };
  }

  function sessionSnapshotData(data = {}) {
    const status = snapshotStatus(data?.status);
    const profiles = snapshotProfiles(data?.profiles);
    if (!status.ok || !profiles.ok) return null;
    return { version: { version: status.version }, status, profiles };
  }

  function saveSessionSnapshot(data) {
    if (!token) return;
    const safeData = sessionSnapshotData(data);
    if (!safeData) return;
    try {
      sessionStorage.setItem(SESSION_SNAPSHOT_KEY, JSON.stringify({
        app_version: APP_VERSION,
        saved_at: Date.now(),
        data: safeData
      }));
    } catch (_) {
      // Private-mode or quota failures must not affect the panel itself.
    }
  }

  function loadSessionSnapshot() {
    if (!token) return null;
    try {
      const saved = JSON.parse(sessionStorage.getItem(SESSION_SNAPSHOT_KEY) || "null");
      const age = Date.now() - Number(saved?.saved_at || 0);
      if (saved?.app_version !== APP_VERSION || !Number.isFinite(age) || age < 0 || age > SESSION_SNAPSHOT_MAX_AGE_MS) {
        sessionStorage.removeItem(SESSION_SNAPSHOT_KEY);
        return null;
      }
      const safeData = sessionSnapshotData(saved?.data);
      return safeData ? { ...safeData, sessionSnapshot: true } : null;
    } catch (_) {
      return null;
    }
  }

  function timeAgo(value) {
    const ts = Number(value || 0);
    if (!ts) return "нет данных";
    const diff = Math.max(0, Math.floor(Date.now() / 1000) - ts);
    if (diff < 60) return `${diff} сек. назад`;
    if (diff < 3600) return `${Math.floor(diff / 60)} мин. назад`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} ч. назад`;
    return `${Math.floor(diff / 86400)} дн. назад`;
  }

  function durationText(value) {
    const seconds = Math.max(0, Number(value || 0));
    if (!Number.isFinite(seconds) || seconds <= 0) return "нет данных";
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (days) return `${days} дн. ${hours} ч.`;
    if (hours) return `${hours} ч. ${minutes} мин.`;
    return `${minutes} мин.`;
  }

  function setBusy(busy) {
    state.busy = busy;
    document.querySelectorAll(".ks-btn").forEach((btn) => {
      const locked = btn.hasAttribute("data-locked");
      btn.disabled = locked || (busy && btn.dataset.ks !== "expert");
    });
  }

  function returnPathWithoutToken() {
    const url = new URL(location.href);
    url.searchParams.delete("token");
    return `${url.pathname}${url.search}${url.hash || "#/health"}`;
  }

  function renderLogin(message = "") {
    document.body.innerHTML = `
      <main class="ks-shell">
        <section class="ks-card ks-login">
          <h1>KeenVLESS</h1>
          <p>Для входа нужен старый token в адресе или запасная авторизация через Яндекс ID. После входа пульт откроется без token, по защищённой cookie-сессии.</p>
          ${message ? `<pre class="ks-log">${esc(message)}</pre>` : ""}
          <div class="ks-actions">
            <button class="ks-btn primary" data-ks="oauth">Войти через Яндекс</button>
            <button class="ks-btn" data-ks="reload">Проверить ещё раз</button>
          </div>
        </section>
      </main>
    `;
    bindActions();
  }

  function isUnauthorized(value) {
    return value?.ok === false && value?.error === "unauthorized";
  }

  function healthLabel(data) {
    const health = cachedHealth(data);
    if (health.ok && (health.overall === "ok" || !health.overall)) return { cls: "ok", text: "Всё работает" };
    if (health.overall === "fail" || health.ok === false) return { cls: "fail", text: "Есть проблема" };
    return { cls: "warn", text: "Проверить" };
  }

  function profileName(profile) {
    return profile?.name || profile?.name_ru || profile?.name_en || profile?.id || "—";
  }

  function profileHealthText(value) {
    return ({ ok: "доступен", bad: "недоступен", unknown: "не проверен", manual: "не проверен" })[value] || value || "не проверен";
  }

  function profileNoteText(value) {
    let text = String(value || "");
    [
      ["active full tunnel check", "полный туннель проверен"],
      ["active config ok", "активная конфигурация исправна"],
      ["TCP endpoint reachable; full tunnel not tested", "сервер отвечает по TCP; туннель не проверен"],
      ["UDP profile parsed; activate it for a reliable full tunnel test", "UDP-профиль распознан; включите его для полной проверки"],
      ["TCP endpoint unreachable", "сервер не отвечает по TCP"],
      ["xray outbound unavailable", "исходящее подключение XRay недоступно"]
    ].forEach(([from, to]) => { text = text.split(from).join(to); });
    return text;
  }

  function profilePriority(profile) {
    if (profile?.active) return 0;
    if (profile?.health === "ok") return 1;
    if (profile?.source === "manual" || profile?.protocol === "hysteria2") return 2;
    if (profile?.health === "manual" || profile?.health === "unknown" || !profile?.health) return 3;
    return 4;
  }

  function profileDetails(profile) {
    return [
      profile?.source === "provider" ? `id=${profile.id}` : "",
      profile?.source === "provider" ? "из списка" : "ручной",
      profile?.user && `пользователь ${profile.user}`,
      profile?.server,
      profile?.sni && `SNI ${profile.sni}`,
      profile?.pin_present ? "сертификат закреплён" : "",
      profile?.latency_ms !== null && profile?.latency_ms !== undefined && profile?.latency_ms !== "" && Number.isFinite(Number(profile.latency_ms)) ? `${profile.latency_ms} мс` : ""
    ].filter(Boolean).join(" · ");
  }

  function simpleProfiles(data) {
    const profiles = data?.profiles?.profiles || [];
    return profiles.slice()
      .sort((a, b) => profilePriority(a) - profilePriority(b)
        || Number(a.latency_ms ?? 999999) - Number(b.latency_ms ?? 999999)
        || profileName(a).localeCompare(profileName(b), "ru"))
      .slice(0, 60);
  }

  function rebuildProfileIndex() {
    state.profileById = {};
    simpleProfiles(state.data).forEach((profile) => { state.profileById[profile.id] = profile; });
  }

  function scheduleSnapshotRefresh() {
    if (state.snapshotRefreshTimer) return;
    state.snapshotRefreshTimer = setTimeout(() => {
      state.snapshotRefreshTimer = null;
      if (!state.busy) {
        refresh("Фоновые данные обновлены.", { snapshotFollowUp: false }).catch(() => {});
      }
    }, 2500);
  }

  function render(data = state.data, message = state.lastMessage) {
    const label = healthLabel(data);
    const status = data?.status || {};
    const health = cachedHealth(data);
    const healthCached = !data?.health && !!status.health_last;
    const profiles = data?.profiles || {};
    const selected = profiles.selected_profile || {};
    const rescue = data?.rescueStatus || {};
    const rescueStatus = rescue.status || {};
    const current = health.current_server || {};
    const hy = health.hysteria_diagnostics || {};
    const profileRows = simpleProfiles(data);
    const duplicateUsers = profiles.duplicate_hysteria_users || [];
    const failures = data?.failures || [];
    const overview = data?.overviewSnapshot || {};
    const monitor = status.system_monitor || {};
    const rebootSummary = status.reboot_summary || {};
    const connectivity = status.connectivity || {};
    const wan = connectivity.wan || {};
    const cloud = connectivity.cloud || {};
    const syslog = connectivity.remote_syslog || {};
    const connectivityKnown = Number(connectivity.last_check_at || 0) > 0;

    document.body.innerHTML = `
      <main class="ks-shell">
        <header class="ks-head">
          <div>
            <h1>KeenVLESS</h1>
            <p>Простой режим: только текущее состояние, профили и спасательный доступ. Всё сложное спрятано в экспертный режим.</p>
          </div>
          <div class="ks-actions">
            <button class="ks-btn" data-ks="reload">Обновить быстро</button>
            <button class="ks-btn" data-ks="refresh">Полная проверка</button>
            <button class="ks-btn" data-ks="best">Переключить на рабочий</button>
            <button class="ks-btn" data-ks="expert">Экспертный режим</button>
          </div>
        </header>

        <section class="ks-hero">
          <article class="ks-card ks-status">
            <div class="ks-status-main"><span class="ks-dot ${esc(label.cls)}"></span><span>${esc(label.text)}</span></div>
            <p>${esc(current.ok ? `Прокси отвечает: IP ${current.ip || "—"}, YouTube ${current.youtube || "—"}.` : (health.error || current.reason || "Быстрые данные загружены. Для живой проверки нажмите «Полная проверка»."))}${health.checked_at ? ` ${esc(healthCached ? "Сохранённая проверка" : "Проверка")}: ${esc(timeAgo(health.checked_at))}.` : ""}${overview.stale ? " Показан предыдущий снимок, обновляю его в фоне." : ""}</p>
            <div class="ks-kv">
              <span>Версия</span><b>${esc(data?.version?.version || status.version || "—")}</b>
              <span>Профиль</span><b>${esc(profileName(selected) || status.selected || "—")}</b>
              <span>Протокол</span><b><span class="ks-tag ${selected.protocol === "hysteria2" ? "hy2" : ""}">${esc(selected.display_protocol || selected.protocol || "—")}</span></b>
              <span>XRay</span><b>${status.running ? '<span class="ks-tag ok">запущен</span>' : '<span class="ks-tag fail">не запущен</span>'}</b>
            </div>
          </article>

          <article class="ks-card soft">
            <h2>Что важно</h2>
            <div class="ks-kv">
              <span>Проверки</span><b>всего ${esc(health.summary?.checks ?? "—")} · ошибок ${esc(health.summary?.fails ?? "—")} · предупреждений ${esc(health.summary?.warns ?? "—")} ${healthCached ? "· сохранённые данные" : ""}</b>
              <span>HY2</span><b>${esc((hy.checks || []).map((c) => `${c.id}:${c.state}`).join(" · ") || "—")}</b>
              <span>Дубликаты</span><b>${duplicateUsers.length ? esc(duplicateUsers.map((d) => `${d.user}×${d.count}`).join(", ")) : "нет"}</b>
            </div>
          </article>

          <article class="ks-card soft">
            <h2>Роутер и удалённый доступ</h2>
            <div class="ks-kv">
              <span>Работает без перезагрузки</span><b>${esc(durationText(monitor.last_uptime_s))}</b>
              <span>Перезагрузки</span><b>${esc(rebootSummary.last_24h ?? 0)} за сутки · ${esc(rebootSummary.last_7d ?? 0)} за 7 дней</b>
              <span>WAN</span><b><span class="ks-tag ${!connectivityKnown ? "warn" : (wan.ok ? "ok" : "fail")}">${!connectivityKnown ? "нет данных" : (wan.ok ? "доступен" : "нет ответа")}</span>${wan.external_ip ? ` ${esc(wan.external_ip)}` : ""}</b>
              <span>KeenDNS / облако</span><b><span class="ks-tag ${cloud.ok ? "ok" : "warn"}">${cloud.ok ? "активно" : (cloud.supported ? "требует проверки" : "нет данных")}</span> ${esc(cloud.agent_state || cloud.access || "")}</b>
              <span>Удалённый Syslog</span><b>${syslog.configured ? `<span class="ks-tag ok">настроен</span> ${esc((syslog.servers || []).join(", "))}` : '<span class="ks-tag warn">не настроен</span>'}</b>
              <span>Последняя проверка</span><b>${esc(timeAgo(connectivity.last_check_at || monitor.last_checked_at))}</b>
            </div>
          </article>
        </section>

        <section class="ks-grid">
          <article class="ks-card">
            <h3>VPN-профили</h3>
            <div class="ks-list">
              ${profileRows.map((p) => `
                <div class="ks-row ${p.active ? "active" : ""}" data-id="${esc(p.id)}">
                  <div>
                    <strong>${esc(profileName(p))}</strong>
                    <span><span class="ks-tag ${p.protocol === "hysteria2" ? "hy2" : ""}">${esc(p.display_protocol || p.protocol || "—")}</span> ${esc(profileDetails(p))}</span>
                    <em>${esc(profileHealthText(p.health))}${p.note ? ` · ${esc(profileNoteText(p.note))}` : ""} ${p.active ? "· выбран" : ""}</em>
                  </div>
                  <button class="ks-btn primary" data-ks="select" data-id="${esc(p.id)}" ${p.active ? 'data-locked="1" disabled' : ""}>Выбрать</button>
                </div>
              `).join("") || '<p>Профили не загружены.</p>'}
            </div>
          </article>

          <article class="ks-card">
            <h3>Резервный доступ</h3>
            <p>${rescueStatus.behind_nat ? "Роутер за NAT/CGNAT, поэтому спасательный доступ лучше строить исходящим WireGuard на VPS." : "Rescue WireGuard можно использовать как запасной вход."}</p>
            <div class="ks-kv" style="margin-top:10px">
              <span>WAN</span><b>${esc(rescueStatus.wan_ip || "—")} ${esc(rescueStatus.wan_class || "")}</b>
              <span>LAN</span><b>${esc(rescueStatus.home_lan || "—")}</b>
            </div>
            <div class="ks-actions" style="margin-top:12px">
              <button class="ks-btn" data-ks="rescue">Скачать резервный набор</button>
              <button class="ks-btn" data-ks="rescue-details">Показать детали</button>
              <button class="ks-btn danger" data-ks="rollback-previous">Вернуться к предыдущей версии</button>
            </div>
          </article>

          <article class="ks-card">
            <h3>Журнал</h3>
            <pre class="ks-log">${esc(message || (failures.length ? `Не ответили: ${failures.join(", ")}` : "Готово."))}</pre>
          </article>
        </section>
      </main>
    `;
    bindActions();
    setBusy(state.busy);
  }

  async function refresh(message = "Проверка завершена", options = {}) {
    if (state.refreshPromise) return state.refreshPromise;
    state.refreshPromise = (async () => {
      setBusy(true);
      const includeHealth = options.includeHealth === true;
      state.lastMessage = includeHealth ? "Запускаю полную проверку…" : "Загружаю быстрые данные…";
      if (!state.data) render({}, state.lastMessage);
      const extraTasks = [];
      if (options.includeVersion === true) extraTasks.push({ key: "version", run: () => api({ action: "version" }, 60000) });
      if (options.includeRescue === true) extraTasks.push({ key: "rescueStatus", run: () => api({ action: "rescue_status" }, 90000) });
      if (includeHealth) extraTasks.push({ key: "health", run: () => api({ action: "health_report" }, 180000) });
      const [home, extra] = await Promise.all([
        loadHomeSnapshot({ forceLive: options.forceLive === true || includeHealth }),
        extraTasks.length ? runLimited(extraTasks, 2) : Promise.resolve({})
      ]);
      const result = { ...home, ...extra };
      if (Object.values(result).some(isUnauthorized)) {
        state.data = { ...(state.data || {}), ...result, failures: Object.keys(result) };
        state.lastMessage = "API не принял token/cookie. Можно войти через Яндекс ID, если номер телефона есть в whitelist.";
        renderLogin(state.lastMessage);
        return state.data;
      }
      const failures = Object.entries(result)
        .filter(([key, value]) => !["homeSnapshot", "overviewSnapshot", "snapshotFallback"].includes(key) && value?.ok === false)
        .map(([key]) => key);
      state.data = { ...(state.data || {}), ...result, failures };
      rebuildProfileIndex();
      saveSessionSnapshot(state.data);
      state.lastMessage = failures.length ? `${message}\nНе ответили: ${failures.join(", ")}` : message;
      render(state.data, state.lastMessage);
      if (home?.overviewSnapshot?.stale === true && options.snapshotFollowUp !== false) scheduleSnapshotRefresh();
      return state.data;
    })().finally(() => {
      state.refreshPromise = null;
      setBusy(false);
    });
    return state.refreshPromise;
  }

  async function selectProfile(id) {
    const item = state.profileById[id] || {};
    if (!id || item.active) return;
    if (!confirm(`Переключить на ${profileName(item)}? Будет выполнена проверка и откат при ошибке.`)) return;
    setBusy(true);
    let finalResult = null;
    try {
      const start = await api({ action: "select_async", server: id }, 60000);
      if (!start?.ok || !start.id) {
        finalResult = start;
      } else {
        state.lastMessage = `Переключаю на ${profileName(item)}…\nЗадача ${start.id} запущена.`;
        render(state.data, state.lastMessage);
        setBusy(true);
        for (let attempt = 0; attempt < 120; attempt += 1) {
          await sleep(attempt < 3 ? 1500 : 3000);
          const status = await api({ action: "select_status", select_id: start.id }, 30000);
          finalResult = status;
          const result = status?.result || {};
          const stateText = status?.state || "unknown";
          const check = result.check_current || {};
          state.lastMessage = [
            `Переключаю на ${profileName(item)}…`,
            `Состояние: ${stateText}${status?.duration_sec ? `, ${status.duration_sec} сек.` : ""}`,
            check.ip ? `Проверка через прокси: ${check.ip}, YouTube ${check.youtube || "—"}` : "",
            result.error ? `Ошибка: ${result.error}` : ""
          ].filter(Boolean).join("\n");
          render(state.data, state.lastMessage);
          setBusy(true);
          if (status?.done || status?.state === "success" || status?.state === "failed") break;
        }
      }
    } catch (err) {
      finalResult = { ok: false, error: err?.message || String(err) };
    }
    const compact = finalResult?.result ? { ...finalResult, result: finalResult.result } : finalResult;
    await refresh(`select ${id}:\n${JSON.stringify(compact, null, 2)}`, { includeHealth: false, forceLive: true });
  }

  async function selectBest() {
    const rows = simpleProfiles(state.data);
    const candidate = rows.find((p) => !p.active && p.health === "ok") || rows.find((p) => !p.active && p.protocol === "hysteria2") || rows.find((p) => !p.active);
    if (!candidate) {
      state.lastMessage = "Запасного профиля в простом списке нет.";
      render(state.data, state.lastMessage);
      return;
    }
    await selectProfile(candidate.id);
  }

  async function rescueBundle(showOnly = false) {
    setBusy(true);
    const res = await api({ action: "rescue_wireguard" }, 120000);
    setBusy(false);
    if (!res.ok) {
      state.lastMessage = `Не смог получить rescue-набор:\n${JSON.stringify(res, null, 2)}`;
      render(state.data, state.lastMessage);
      return;
    }
    const artifacts = res.artifacts || {};
    const text = [
      "# VPS setup script",
      artifacts.vps_script || "",
      "",
      "# Keenetic router template",
      artifacts.router_template || "",
      "",
      "# Operator client template",
      artifacts.operator_template || "",
      "",
      "# README",
      artifacts.readme || ""
    ].join("\n");
    if (showOnly) {
      state.lastMessage = text.slice(0, 6000);
      render(state.data, state.lastMessage);
      return;
    }
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "keenvless-rescue-bundle.txt";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    state.lastMessage = "Rescue-набор скачан.";
    render(state.data, state.lastMessage);
  }

  async function rollbackPrevious() {
    setBusy(true);
    state.lastMessage = "Проверяю резервную копию предыдущей версии…";
    render(state.data, state.lastMessage);
    const ready = await rollbackApi({ action: "verify_previous" }, 90000);
    setBusy(false);
    if (!ready?.ok) {
      state.lastMessage = ready?.error === "unauthorized"
        ? "Откат не авторизован. Откройте пульт с token или войдите через Яндекс ID повторно."
        : `Предыдущая версия недоступна: ${ready?.error || "неизвестная ошибка"}`;
      render(state.data, state.lastMessage);
      return;
    }
    const fromVersion = ready.current_version || "текущей версии";
    const toVersion = ready.previous_version || "предыдущей версии";
    if (!confirm(`Вернуться с ${fromVersion} на ${toVersion}?\n\nТекущая версия будет сохранена для обратного хода. Настройки и выбранный VPN-профиль не изменяются.`)) return;
    setBusy(true);
    state.lastMessage = `Возвращаю ${toVersion}; текущую версию сохраняю…`;
    render(state.data, state.lastMessage);
    const result = await rollbackApi({ action: "rollback_previous", confirm: "rollback_previous" }, 180000);
    setBusy(false);
    if (!result?.ok || result?.state !== "rolled_back_previous") {
      state.lastMessage = `Откат не выполнен: ${result?.error || "неизвестная ошибка"}. Текущая версия сохранена.`;
      render(state.data, state.lastMessage);
      return;
    }
    state.lastMessage = `Установлена ${result.version}. VPN-конфигурация не менялась. Перезагружаю пульт…`;
    render(state.data, state.lastMessage);
    setTimeout(() => location.reload(), 1200);
  }

  function bindActions() {
    document.querySelectorAll("[data-ks]").forEach((node) => {
      node.addEventListener("click", async (event) => {
        event.preventDefault();
        const action = node.getAttribute("data-ks");
        if (action === "oauth") {
          location.href = `oauth-yandex-start.sh?return=${encodeURIComponent(returnPathWithoutToken())}`;
          return;
        }
        if (action === "expert") return enterExpert();
        if (action === "reload") return refresh("Быстрые данные обновлены", { includeHealth: false, forceLive: true });
        if (action === "refresh") return refresh("Полная проверка обновлена", { includeHealth: true, forceLive: true });
        if (action === "best") return selectBest();
        if (action === "select") return selectProfile(node.getAttribute("data-id"));
        if (action === "rescue") return rescueBundle(false);
        if (action === "rescue-details") return rescueBundle(true);
        if (action === "rollback-previous") return rollbackPrevious();
      });
    });
  }

  function mount() {
    const style = document.createElement("style");
    style.textContent = css;
    document.head.appendChild(style);
    const root = $("app-root") || document.body;
    root.innerHTML = "";
    const saved = loadSessionSnapshot();
    if (saved) {
      state.data = saved;
      rebuildProfileIndex();
      render(state.data, "Показаны сохранённые данные этого сеанса; обновляю в фоне…");
    } else {
      render({}, "Загружаю простой режим…");
    }
    refresh("Быстрые данные загружены. Полная диагностика запускается отдельной кнопкой.", { includeHealth: false }).catch((err) => {
      state.lastMessage = `Ошибка загрузки: ${err?.message || String(err)}`;
      render(state.data || {}, state.lastMessage);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }
})();
