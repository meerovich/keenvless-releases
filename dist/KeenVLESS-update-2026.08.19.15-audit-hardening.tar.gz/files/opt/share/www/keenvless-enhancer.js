(() => {
  if (window.__keenvlessEnhancer) return;
  window.__keenvlessEnhancer = true;

  const token = window.__keenvlessToken || (() => { try { return sessionStorage.getItem("keenvless.webToken") || ""; } catch (_) { return ""; } })();
  const SELECT_JOB_KEY = "keenvless.activeSelectJob";
  const RETRYABLE_READ_ACTIONS = new Set([
    "version", "status", "profiles", "manual_list", "expert_snapshot",
    "overview_snapshot", "home_snapshot", "select_status", "scan_status",
    "router_info", "alerts", "metrics_history", "health_history", "rescue_status"
  ]);
  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (value) => String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const b64 = (value) => btoa(unescape(encodeURIComponent(value)));
  const short = (value, max = 80) => {
    const text = String(value ?? "");
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
  };

  function xhrPost(body, timeoutMs) {
    return new Promise((resolve) => {
      if (typeof XMLHttpRequest !== "function") {
        resolve({ ok: false, error: "fetch/XMLHttpRequest is not available" });
        return;
      }
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "api.sh", true);
      xhr.timeout = timeoutMs;
      xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
      xhr.setRequestHeader("x-keenvless-request", "1");
      xhr.onload = () => resolve({ ok: true, status: xhr.status, text: xhr.responseText || "" });
      xhr.onerror = () => resolve({ ok: false, transport_error: true, error: "xhr network error" });
      xhr.ontimeout = () => resolve({ ok: false, transport_error: true, error: "xhr timeout" });
      xhr.send(body);
    });
  }

  async function apiOnce(params, timeoutMs) {
    try {
      const body = new URLSearchParams({ token, ...params });
      let text = "";
      let status = 0;
      if (typeof fetch === "function" && typeof AbortController === "function") {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
          const resp = await fetch("api.sh", {
            method: "POST",
            headers: { "content-type": "application/x-www-form-urlencoded", "x-keenvless-request": "1" },
            body,
            signal: ctrl.signal
          });
          status = resp.status;
          text = await resp.text();
        } finally {
          clearTimeout(timer);
        }
      } else {
        const xhr = await xhrPost(body.toString(), timeoutMs);
        if (!xhr.ok) return xhr;
        status = xhr.status;
        text = xhr.text;
      }
      try {
        return JSON.parse(text);
      } catch {
        return { ok: false, transport_error: true, status, text: text.slice(0, 1000), error: "invalid or empty API response" };
      }
    } catch (err) {
      return { ok: false, transport_error: true, error: err?.message || String(err) };
    }
  }

  async function api(params, timeoutMs = 120000) {
    const retryable = RETRYABLE_READ_ACTIONS.has(String(params?.action || "status"));
    let result = await apiOnce(params, timeoutMs);
    if (retryable && result?.transport_error === true) {
      await new Promise((resolve) => setTimeout(resolve, 350));
      result = await apiOnce(params, timeoutMs);
    }
    return result;
  }

  const css = `
    .kvx-fab{position:fixed;right:14px;bottom:14px;z-index:2000;border:1px solid var(--line-strong,#c3ced8);border-radius:999px;background:var(--panel,#fff);color:var(--text,#17212b);box-shadow:0 8px 24px #0003;min-height:42px;padding:0 14px;font:600 13px Inter,system-ui,sans-serif;cursor:pointer}
    .kvx-fab.ok{border-color:#1e665480}.kvx-fab.warn{border-color:#a66a0080}.kvx-fab.fail{border-color:#a9343480}
    .kvx-backdrop{position:fixed;inset:0;z-index:2001;background:#0005;display:none}.kvx-backdrop.open{display:block}
    .kvx-panel{position:fixed;right:10px;bottom:62px;z-index:2002;width:min(920px,calc(100vw - 20px));max-height:calc(100vh - 84px);overflow:auto;border:1px solid var(--line-strong,#c3ced8);border-radius:14px;background:var(--panel,#fff);color:var(--text,#17212b);box-shadow:0 14px 44px #0005;padding:14px;font:13px Inter,system-ui,sans-serif;display:none}
    .kvx-panel.open{display:block}.kvx-head{display:flex;justify-content:space-between;gap:10px;align-items:start;margin-bottom:10px}.kvx-head h3{margin:0;font-size:17px}.kvx-head p{margin:4px 0 0;color:var(--muted,#5f7080)}
    .kvx-actions,.kvx-row-actions{display:flex;flex-wrap:wrap;gap:6px}.kvx-btn{border:1px solid var(--line-strong,#c3ced8);border-radius:8px;background:var(--panel-soft,#f8fafc);color:var(--text,#17212b);min-height:32px;padding:0 10px;cursor:pointer}.kvx-btn.primary{background:var(--brand,#0b5cad);border-color:var(--brand,#0b5cad);color:#fff}.kvx-btn.danger{border-color:#a9343480;color:#a93434}.kvx-btn:disabled{opacity:.55;cursor:progress}
    .kvx-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));gap:8px;margin:10px 0}.kvx-card{border:1px solid var(--line,#d8e0e8);border-radius:10px;background:var(--panel-soft,#f8fafc);padding:10px;display:grid;gap:5px}.kvx-card b{font-size:13px}.kvx-card span,.kvx-card em{color:var(--muted,#5f7080);font-style:normal;overflow-wrap:anywhere}
    .kvx-tag{display:inline-flex;align-items:center;min-height:24px;border-radius:999px;border:1px solid var(--line-strong,#c3ced8);padding:0 8px;color:var(--muted,#5f7080);background:var(--panel,#fff);font-size:12px}.kvx-tag.ok{border-color:#1e665480;color:#1e6654}.kvx-tag.warn{border-color:#a66a0080;color:#a66a00}.kvx-tag.fail{border-color:#a9343480;color:#a93434}.kvx-tag.hy2{border-color:#0b5cad80;color:#0b5cad}
    .kvx-table{display:grid;gap:6px}.kvx-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;border:1px solid var(--line,#d8e0e8);border-radius:9px;background:var(--panel-soft,#f8fafc);padding:8px}.kvx-row.active{border-color:var(--brand,#0b5cad);box-shadow:inset 0 0 0 1px #0b5cad80}.kvx-row.fail{border-color:#a9343480}.kvx-row.warn{border-color:#a66a0080}.kvx-row-main{display:grid;gap:3px;min-width:0}.kvx-row-main strong,.kvx-row-main span{overflow-wrap:anywhere}.kvx-muted{color:var(--muted,#5f7080)}.kvx-form{display:grid;gap:8px;margin-top:10px}.kvx-form input,.kvx-form textarea,.kvx-script{width:100%;border:1px solid var(--line-strong,#c3ced8);border-radius:8px;background:var(--panel,#fff);color:var(--text,#17212b);padding:8px;font:inherit}.kvx-form textarea{min-height:88px;resize:vertical}.kvx-script{box-sizing:border-box;min-height:180px;white-space:pre;font:12px ui-monospace,SFMono-Regular,Consolas,monospace}.kvx-script.small{min-height:120px}.kvx-textgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(280px,100%),1fr));gap:8px;margin-top:8px}.kvx-textgrid label{display:grid;gap:5px;color:var(--muted,#5f7080)}.kvx-log{margin-top:10px;border:1px solid var(--line,#d8e0e8);border-radius:9px;background:var(--panel-soft,#f8fafc);padding:8px;white-space:pre-wrap;max-height:160px;overflow:auto;color:var(--muted,#5f7080)}
    @media(max-width:720px){.kvx-panel{left:8px;right:8px;bottom:58px;width:auto;max-height:calc(100vh - 70px)}.kvx-head{display:grid}.kvx-actions,.kvx-row-actions{width:100%}.kvx-actions .kvx-btn,.kvx-row-actions .kvx-btn{flex:1 1 100%;width:100%;min-height:42px}.kvx-row{grid-template-columns:1fr;align-items:stretch}}
  `;

  // A deliberately isolated presentation layer. It is appended only after the
  // Angular root exists, so these rules override the legacy component styles
  // without changing the compiled Angular bundle or any VPN behaviour.
  const uiPolishCss = `
    html.kvx-expert-mode{--kvx-control-height:42px;--kvx-touch-height:44px;--kvx-card-pad:16px;--kvx-inner-pad:14px;--kvx-section-gap:14px}
    html.kvx-expert-mode app-root main{padding-bottom:88px}
    html.kvx-expert-mode app-root .panel{padding:var(--kvx-card-pad);margin-top:14px;border-radius:12px}
    html.kvx-expert-mode app-root .panel .panel,
    html.kvx-expert-mode app-root .panel .target-box,
    html.kvx-expert-mode app-root .panel .summary,
    html.kvx-expert-mode app-root .panel .list-editor,
    html.kvx-expert-mode app-root .panel .scenario-card,
    html.kvx-expert-mode app-root .panel .device-card,
    html.kvx-expert-mode app-root .panel .router-overview article,
    html.kvx-expert-mode app-root .panel .router-grid article,
    html.kvx-expert-mode app-root .panel .metric-grid article{padding:var(--kvx-inner-pad)}
    html.kvx-expert-mode app-root .control-box,
    html.kvx-expert-mode app-root .result-card,
    html.kvx-expert-mode app-root .health-card,
    html.kvx-expert-mode app-root .check-row,
    html.kvx-expert-mode app-root .repair-grid article,
    html.kvx-expert-mode app-root .quick-start article,
    html.kvx-expert-mode app-root .chart-card,
    html.kvx-expert-mode app-root .event-list,
    html.kvx-expert-mode app-root .update-box{padding:var(--kvx-inner-pad);border-radius:10px}
    html.kvx-expert-mode app-root .section-head{gap:16px;margin-bottom:16px}
    html.kvx-expert-mode app-root .section-subhead{gap:16px;margin:20px 0 14px;padding-top:16px}
    html.kvx-expert-mode app-root .hint,
    html.kvx-expert-mode app-root .subhead{max-width:78ch;line-height:1.5}
    html.kvx-expert-mode app-root button{min-height:var(--kvx-control-height);border-radius:9px;padding:0 14px;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease,transform .08s ease}
    html.kvx-expert-mode app-root button:active:not(:disabled){transform:translateY(1px)}
    html.kvx-expert-mode app-root button.small{min-height:36px;padding:0 10px}
    html.kvx-expert-mode app-root .icon-button{min-width:40px;width:40px;min-height:40px;padding:0}
    html.kvx-expert-mode app-root input,
    html.kvx-expert-mode app-root select,
    html.kvx-expert-mode app-root .p-select{min-height:var(--kvx-control-height);border-radius:9px}
    html.kvx-expert-mode app-root textarea{border-radius:9px}
    html.kvx-expert-mode app-root .target-controls button{min-height:var(--kvx-control-height)}
    html.kvx-expert-mode app-root .target-bar{grid-template-columns:minmax(170px,1fr) minmax(380px,470px) minmax(160px,.8fr);padding:10px;gap:10px 12px}
    html.kvx-expert-mode app-root .target-status{padding:8px 11px}
    html.kvx-expert-mode app-root .actions.compact{align-items:stretch}
    html.kvx-expert-mode app-root .section-head>.actions.compact{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));min-width:min(100%,340px)}
    html.kvx-expert-mode app-root .section-head>.actions.compact button,
    html.kvx-expert-mode app-root .control-box>.actions.compact button,
    html.kvx-expert-mode app-root .router-grid article>.actions.compact button{width:100%}
    html.kvx-expert-mode app-root .control-box>.actions.compact{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}
    html.kvx-expert-mode app-root .control-box>.actions.compact>button:last-child:nth-child(odd){grid-column:1 / -1}
    html.kvx-expert-mode app-root .router-grid article>.actions.compact{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));width:100%}
    html.kvx-expert-mode app-root .panel>:where(.control-box,.control-layout,.diagnostic-grid,.rules-grid,.metric-grid,.summary,.state-hero,.repair-grid,.route-flow,.candidate-list,.router-overview,.router-grid,.quick-start,.chart-grid,.list-editor,.list-editor-grid,.scenario-grid,.device-grid,.alert-strip,.alert-grid,.segmented,.table-wrap,.health-grid,.event-list,.update-box,.log-grid,.empty-state,.tab-loading)+:where(.control-box,.control-layout,.diagnostic-grid,.rules-grid,.metric-grid,.summary,.state-hero,.repair-grid,.route-flow,.candidate-list,.router-overview,.router-grid,.quick-start,.chart-grid,.list-editor,.list-editor-grid,.scenario-grid,.device-grid,.alert-strip,.alert-grid,.segmented,.table-wrap,.health-grid,.event-list,.update-box,.log-grid,.empty-state,.tab-loading){margin-top:var(--kvx-section-gap)}
    html.kvx-expert-mode app-root .p-tablist-content{scroll-snap-type:x proximity;scrollbar-width:thin;scrollbar-color:var(--line-strong) transparent}
    html.kvx-expert-mode app-root .p-tab{min-height:48px;scroll-snap-align:center}
    html.kvx-expert-mode app-root .kvx-filter-toolbar{grid-template-columns:repeat(2,minmax(0,1fr));grid-template-rows:auto var(--kvx-control-height) auto var(--kvx-control-height);align-items:end}
    html.kvx-expert-mode app-root .kvx-filter-caption{color:var(--muted);font-size:12px;line-height:1.25}
    html.kvx-expert-mode app-root .kvx-filter-caption.search{grid-column:1 / -1;grid-row:1}
    html.kvx-expert-mode app-root .kvx-filter-caption.availability{grid-column:1;grid-row:3}
    html.kvx-expert-mode app-root .kvx-filter-caption.favourite{grid-column:2;grid-row:3}
    html.kvx-expert-mode app-root .kvx-filter-search{grid-column:1 / -1;grid-row:2}
    html.kvx-expert-mode app-root .kvx-filter-availability{grid-column:1;grid-row:4}
    html.kvx-expert-mode app-root .kvx-filter-favourite{grid-column:2;grid-row:4}
    html.kvx-expert-mode app-root .kvx-danger-action{border-color:color-mix(in srgb,var(--danger) 55%,var(--line));background:color-mix(in srgb,var(--danger) 7%,var(--panel));color:var(--danger)}
    html.kvx-expert-mode app-root .kvx-danger-action:hover:not(:disabled){background:color-mix(in srgb,var(--danger) 12%,var(--panel))}
    html.kvx-expert-mode app-root button:focus-visible,
    html.kvx-expert-mode app-root input:focus-visible,
    html.kvx-expert-mode app-root select:focus-visible,
    html.kvx-expert-mode app-root textarea:focus-visible,
    html.kvx-expert-mode app-root [role=combobox]:focus-visible,
    html.kvx-expert-mode app-root [role=tab]:focus-visible,
    .kvx-btn:focus-visible,.kvx-fab:focus-visible,.kvx-simple-switch:focus-visible{outline:3px solid color-mix(in srgb,var(--brand,#0b5cad) 42%,transparent);outline-offset:2px}
    .kvx-btn{min-height:38px;border-radius:9px}
    .kvx-fab,.kvx-simple-switch{min-height:44px}
    @media(max-width:820px){
      html.kvx-expert-mode{--kvx-control-height:44px;--kvx-card-pad:12px;--kvx-inner-pad:12px;--kvx-section-gap:12px}
      html.kvx-expert-mode app-root main{--target-bar-sticky-offset:130px;padding-left:8px;padding-right:8px;padding-bottom:96px}
      html.kvx-expert-mode app-root .target-bar{width:calc(100% - 12px);grid-template-columns:minmax(0,1fr) auto;padding:8px;gap:7px 8px}
      html.kvx-expert-mode app-root .target-controls{gap:7px}
      html.kvx-expert-mode app-root .target-controls button{min-height:var(--kvx-touch-height);padding:0 10px}
      html.kvx-expert-mode app-root button{min-height:var(--kvx-touch-height);padding:0 12px}
      html.kvx-expert-mode app-root button.small{min-height:var(--kvx-touch-height);padding:0 8px}
      html.kvx-expert-mode app-root .icon-button,
      html.kvx-expert-mode app-root .servers-table .icon-button{min-width:var(--kvx-touch-height);width:var(--kvx-touch-height);min-height:var(--kvx-touch-height)}
      html.kvx-expert-mode app-root .panel{margin-top:10px;border-radius:10px}
      html.kvx-expert-mode app-root .metric-grid{gap:10px}
      html.kvx-expert-mode app-root .policy-strip{grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}
      html.kvx-expert-mode app-root .policy-strip button{font-size:12px;line-height:1.15;white-space:normal}
      html.kvx-expert-mode app-root .responsive-table .row-actions button,
      html.kvx-expert-mode app-root .check-row button{min-height:var(--kvx-touch-height)}
      html.kvx-expert-mode app-root .kvx-filter-toolbar{grid-template-columns:1fr;grid-template-rows:auto var(--kvx-control-height) auto var(--kvx-control-height) auto var(--kvx-control-height);gap:6px}
      html.kvx-expert-mode app-root .kvx-filter-caption.search{grid-column:1;grid-row:1}
      html.kvx-expert-mode app-root .kvx-filter-search{grid-column:1;grid-row:2}
      html.kvx-expert-mode app-root .kvx-filter-caption.availability{grid-column:1;grid-row:3}
      html.kvx-expert-mode app-root .kvx-filter-availability{grid-column:1;grid-row:4}
      html.kvx-expert-mode app-root .kvx-filter-caption.favourite{grid-column:1;grid-row:5}
      html.kvx-expert-mode app-root .kvx-filter-favourite{grid-column:1;grid-row:6}
      html.kvx-expert-mode app-root .p-tablist{isolation:isolate}
      html.kvx-expert-mode app-root .p-tablist:after{content:"";position:absolute;top:0;right:0;bottom:0;z-index:3;width:22px;pointer-events:none;background:linear-gradient(90deg,transparent,var(--bg))}
      html.kvx-expert-mode app-root .p-tab{min-height:50px}
      .kvx-actions .kvx-btn,.kvx-row-actions .kvx-btn{min-height:var(--kvx-touch-height)}
      .kvx-fab,.kvx-simple-switch{bottom:max(12px,env(safe-area-inset-bottom));min-height:var(--kvx-touch-height)}
    }
    @media(max-width:420px){
      html.kvx-expert-mode app-root main{padding-left:6px;padding-right:6px}
      html.kvx-expert-mode app-root .panel,
      html.kvx-expert-mode app-root .panel .panel,
      html.kvx-expert-mode app-root .panel .target-box,
      html.kvx-expert-mode app-root .panel .summary,
      html.kvx-expert-mode app-root .panel .list-editor,
      html.kvx-expert-mode app-root .panel .scenario-card,
      html.kvx-expert-mode app-root .panel .device-card,
      html.kvx-expert-mode app-root .panel .router-overview article,
      html.kvx-expert-mode app-root .panel .router-grid article,
      html.kvx-expert-mode app-root .panel .metric-grid article{padding:12px}
    }
  `;

  let panel;
  let fab;
  let state = { busy: false, data: null, profileById: {}, refreshPromise: null, pendingRefresh: null, lastRefreshAt: 0, resumingSelect: false };

  function mergeRefreshOptions(current = {}, next = {}) {
    const merged = { ...current, ...next };
    for (const key of ["health", "doctor", "bootstrap", "rescue", "deep"]) {
      merged[key] = current[key] === true || next[key] === true;
    }
    merged.limit = Math.min(Number(current.limit || 2), Number(next.limit || 2));
    return merged;
  }
  let uiPolishObserver;
  let uiPolishFrame = 0;
  let lastCenteredTab = "";

  function saveSelectJob(job) {
    try { localStorage.setItem(SELECT_JOB_KEY, JSON.stringify(job)); } catch {}
  }

  function loadSelectJob() {
    try { return JSON.parse(localStorage.getItem(SELECT_JOB_KEY) || "null"); } catch { return null; }
  }

  function clearSelectJob() {
    try { localStorage.removeItem(SELECT_JOB_KEY); } catch {}
  }

  function newSelectRequestId() {
    const random = Math.random().toString(36).slice(2, 12);
    return `web-${Date.now().toString(36)}-${random}`;
  }

  async function startSelectOperation(id, name, requestedAt, existingRequestId = "") {
    const requestId = existingRequestId || newSelectRequestId();
    const pending = { id: "", requestId, server: String(id), name, startedAt: requestedAt };
    saveSelectJob(pending);
    let last = null;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      last = await api({ action: "select_async", server: id, request_id: requestId }, 60000);
      if (last?.ok && last.id) {
        saveSelectJob({ ...pending, id: last.id, startedAt: Number(last.started_at || requestedAt) });
        return last;
      }
      const recovered = await api({ action: "select_status", request_id: requestId }, 30000);
      if (recovered?.ok && recovered.id) {
        saveSelectJob({ ...pending, id: recovered.id, startedAt: Number(recovered.started_at || requestedAt) });
        return recovered;
      }
      render(state.data || {}, `Роутер пока не подтвердил запуск переключения (${attempt + 1}/5). Безопасно повторяю ту же команду…`);
      setBusy(true);
      await sleep(1200 + attempt * 800);
    }
    return last || { ok: false, error: "router did not confirm select request", request_id: requestId };
  }

  function setAttributeIfChanged(node, name, value) {
    if (node && node.getAttribute(name) !== value) node.setAttribute(name, value);
  }

  function directHeading(box) {
    return Array.from(box?.children || []).find((node) => node.tagName === "B")?.textContent?.trim() || "";
  }

  function addServerFilterCaptions() {
    document.querySelectorAll(".control-box").forEach((box) => {
      if (directHeading(box) !== "Фильтр") return;
      const toolbar = Array.from(box.children).find((node) => node.classList?.contains("toolbar"));
      const input = toolbar?.querySelector("input");
      const selects = Array.from(toolbar?.querySelectorAll("p-select") || []);
      if (!toolbar || !input || selects.length < 2) return;

      toolbar.classList.add("kvx-filter-toolbar");
      input.classList.add("kvx-filter-search");
      selects[0].classList.add("kvx-filter-availability");
      selects[1].classList.add("kvx-filter-favourite");
      setAttributeIfChanged(input, "aria-label", "Поиск сервера");
      setAttributeIfChanged(selects[0].querySelector("[role=combobox]"), "aria-label", "Доступность серверов");
      setAttributeIfChanged(selects[1].querySelector("[role=combobox]"), "aria-label", "Избранные серверы");

      if (!toolbar.querySelector(".kvx-filter-caption")) {
        [["search", "Поиск"], ["availability", "Доступность"], ["favourite", "Избранное"]].forEach(([field, label]) => {
          const caption = document.createElement("span");
          caption.className = `kvx-filter-caption ${field}`;
          caption.textContent = label;
          toolbar.appendChild(caption);
        });
      }
    });
  }

  function polishExpertLabels() {
    document.querySelectorAll(".xray-toggle").forEach((button) => {
      const pending = button.classList.contains("pending");
      const active = button.classList.contains("active");
      const label = pending ? "Переключаю XRay…" : active ? "Выключить XRay" : "Включить XRay";
      if (button.textContent.trim() !== label) button.textContent = label;
      setAttributeIfChanged(button, "aria-label", label);
      setAttributeIfChanged(button, "title", pending ? label : `${label}. Текущее состояние: ${active ? "включён" : "выключен"}.`);
    });

    document.querySelectorAll("button").forEach((button) => {
      const text = button.textContent.trim();
      if (text === "Выбрать сервер" || button.classList.contains("kvx-open-profiles")) {
        button.classList.add("kvx-open-profiles");
        const label = "Открыть VPN / Профили";
        if (button.textContent.trim() !== label) button.textContent = label;
        setAttributeIfChanged(button, "aria-label", label);
        setAttributeIfChanged(button, "title", "Открыть безопасный выбор VPN-профиля");
      }
      if (text === "☆" || text === "★") {
        const selected = text === "★" || button.classList.contains("active");
        const label = selected ? "Убрать сервер из избранного" : "Добавить сервер в избранное";
        setAttributeIfChanged(button, "aria-label", label);
        setAttributeIfChanged(button, "title", label);
      }
      if (text === "Удалить" && !button.classList.contains("danger")) button.classList.add("kvx-danger-action");
      if (button.closest(".policy-strip")) {
        const labels = { "по общему": "Общее правило", "через XRay": "Через XRay", "напрямую": "Напрямую" };
        const next = labels[text];
        if (next && text !== next) button.textContent = next;
      }
    });

    document.querySelectorAll(".p-select-dropdown").forEach((button) => {
      setAttributeIfChanged(button, "aria-label", "Открыть список");
    });

    document.querySelectorAll('[role="tab"]').forEach((tab) => {
      if (tab.textContent.trim() === "Сервис") tab.textContent = "Обслуживание";
    });
    const tabList = document.querySelector(".p-tablist-content");
    setAttributeIfChanged(tabList, "aria-label", "Разделы пульта. Список прокручивается по горизонтали.");
    setAttributeIfChanged(tabList, "title", "Прокрутите в сторону, чтобы увидеть остальные разделы");
  }

  function centerActiveTab() {
    if (window.innerWidth > 820) return;
    const active = document.querySelector('[role="tab"][aria-selected="true"]');
    const scroller = active?.closest(".p-tablist-content");
    if (!active || !scroller) return;
    const key = `${active.id || active.textContent.trim()}:${scroller.clientWidth}`;
    if (key === lastCenteredTab) return;
    lastCenteredTab = key;
    const left = Math.max(0, active.offsetLeft - (scroller.clientWidth - active.offsetWidth) / 2);
    scroller.scrollTo({ left, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  }

  function applyUiPolish() {
    addServerFilterCaptions();
    polishExpertLabels();
    centerActiveTab();
  }

  function scheduleUiPolish() {
    if (uiPolishFrame) return;
    uiPolishFrame = requestAnimationFrame(() => {
      uiPolishFrame = 0;
      applyUiPolish();
    });
  }

  function installUiPolish() {
    if (document.getElementById("keenvless-ui-polish")) return;
    const style = document.createElement("style");
    style.id = "keenvless-ui-polish";
    style.textContent = uiPolishCss;
    document.head.appendChild(style);
    applyUiPolish();
    uiPolishObserver = new MutationObserver(scheduleUiPolish);
    uiPolishObserver.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["class", "aria-selected"] });
    window.addEventListener("resize", () => { lastCenteredTab = ""; scheduleUiPolish(); }, { passive: true });
  }

  function startUiPolish() {
    if (document.querySelector("app-root main")) return installUiPolish();
    const readyObserver = new MutationObserver(() => {
      if (!document.querySelector("app-root main")) return;
      readyObserver.disconnect();
      installUiPolish();
    });
    readyObserver.observe(document.body, { subtree: true, childList: true });
    setTimeout(() => readyObserver.disconnect(), 30000);
  }

  function setBusy(busy) {
    state.busy = busy;
    document.querySelectorAll(".kvx-btn").forEach((btn) => {
      if (busy) {
        if (!Object.hasOwn(btn.dataset, "kvxBusyDisabled")) {
          btn.dataset.kvxBusyDisabled = btn.disabled ? "1" : "0";
        }
        btn.disabled = true;
      } else if (Object.hasOwn(btn.dataset, "kvxBusyDisabled")) {
        btn.disabled = btn.dataset.kvxBusyDisabled === "1";
        delete btn.dataset.kvxBusyDisabled;
      }
    });
    if (fab) fab.textContent = busy ? "VPN…" : "VPN / Профили";
  }

  function closeProfilePanel() {
    panel?.classList.remove("open");
    document.querySelector(".kvx-backdrop")?.classList.remove("open");
  }

  async function openProfilePanel() {
    if (!panel) return;
    panel.classList.add("open");
    document.querySelector(".kvx-backdrop")?.classList.add("open");
    const stale = Date.now() - (state.lastRefreshAt || 0) > 120000;
    if (!state.data || stale) await refresh();
    else render(state.data, `version=${state.data.version?.version || "?"}`);
    resumePendingSelect();
  }

  function renderLoading(message = "Загружаю данные пульта…") {
    if (!panel) return;
    panel.innerHTML = `
      <div class="kvx-head">
        <div>
          <h3>VPN / Профили</h3>
          <p>Безопасное управление профилями поверх текущей панели.</p>
        </div>
        <div class="kvx-actions">
          <button class="kvx-btn" data-kvx="close">Закрыть</button>
        </div>
      </div>
      <div class="kvx-card">
        <b>Загрузка</b>
        <span>${esc(message)}</span>
        <em>Запросы идут ограниченной очередью, чтобы не перегружать KeenDNS/CGI.</em>
      </div>
    `;
  }

  async function runLimited(tasks, limit = 2) {
    const results = {};
    let next = 0;
    const workers = Array.from({ length: Math.min(limit, tasks.length) }, async () => {
      while (next < tasks.length) {
        const task = tasks[next++];
        try {
          results[task.key] = await task.run();
        } catch (err) {
          results[task.key] = { ok: false, error: err?.message || String(err) };
        }
      }
    });
    await Promise.all(workers);
    return results;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function checkTag(stateName) {
    const name = stateName || "warn";
    return `<span class="kvx-tag ${esc(name)}">${esc(name)}</span>`;
  }

  function doctorRows(doctor) {
    const checks = Array.isArray(doctor?.checks) ? doctor.checks : [];
    const checked = checks.length > 0 || Number(doctor?.summary?.checks || 0) > 0;
    const visible = checks
      .filter((c) => c.state === "fail" || c.state === "warn")
      .slice(0, 12);
    if (!visible.length) {
      return checked
        ? '<div class="kvx-muted">Критичных замечаний Doctor не видит.</div>'
        : '<div class="kvx-muted">Проверка Doctor ещё не запускалась.</div>';
    }
    return visible.map((c) => `
      <div class="kvx-row ${esc(c.state)}">
        <div class="kvx-row-main">
          <strong>${checkTag(c.state)} ${esc(c.label || c.id)}</strong>
          <span>${esc(c.detail || "")}</span>
          <em>${esc(c.fix || "")}</em>
        </div>
      </div>
    `).join("");
  }

  function profileName(profile) {
    return profile?.name || profile?.name_ru || profile?.name_en || profile?.id || "—";
  }

  function profilePriority(profile) {
    if (profile?.active) return 0;
    if (profile?.health === "ok" && profile?.full_tunnel === true) return 1;
    if (profile?.source === "manual" || profile?.protocol === "hysteria2") return 2;
    if (profile?.health === "ok") return 3;
    if (profile?.health === "manual" || profile?.health === "unknown" || !profile?.health) return 4;
    return profile?.full_tunnel === true ? 6 : 5;
  }

  function profileDetails(profile) {
    return [
      profile?.source === "provider" ? `id=${profile.id}` : "",
      profile?.source === "provider" ? "provider" : "manual",
      profile?.user && `user=${profile.user}`,
      profile?.server,
      profile?.sni && `sni=${profile.sni}`,
      profile?.obfs && `obfs=${profile.obfs}`,
      profile?.pin_present ? "pin" : "",
      profile?.latency_ms !== null && profile?.latency_ms !== undefined && profile?.latency_ms !== "" && Number.isFinite(Number(profile.latency_ms)) ? `${profile.latency_ms} ms` : "",
      profile?.checked_at ? `проверка ${timeAgo(profile.checked_at)}` : ""
    ].filter(Boolean).join(" · ");
  }

  function sortedProfiles(profiles) {
    return (profiles || []).slice()
      .sort((a, b) => profilePriority(a) - profilePriority(b)
        || Number(a.latency_ms ?? 999999) - Number(b.latency_ms ?? 999999)
        || profileName(a).localeCompare(profileName(b), "ru"))
      .slice(0, 80);
  }

  function durationText(value) {
    const seconds = Math.max(0, Number(value || 0));
    if (!Number.isFinite(seconds) || seconds <= 0) return "нет данных";
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (days) return `${days} дн. ${hours} ч.`;
    if (hours) return `${hours} ч. ${minutes} мин.`;
    return `${minutes} мин.`;
  }

  function timeAgo(value) {
    const ts = Number(value || 0);
    if (!ts) return "нет данных";
    const diff = Math.max(0, Math.floor(Date.now() / 1000) - ts);
    if (diff < 60) return `${diff} сек. назад`;
    if (diff < 3600) return `${Math.floor(diff / 60)} мин. назад`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} ч. назад`;
    return `${Math.floor(diff / 86400)} дн. назад`;
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.left = "-9999px";
    document.body.appendChild(area);
    area.focus();
    area.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { ok = false; }
    area.remove();
    return ok;
  }

  function downloadText(filename, text) {
    const blob = new Blob([text], { type: "text/x-shellscript;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function render(data, message = "") {
    const selected = data.profiles?.selected_profile || {};
    const health = data.health || {};
    const doctor = data.doctor || {};
    const bootstrap = data.bootstrap || {};
    const rescue = data.rescue || {};
    const rescueState = rescue.status?.status || rescue.status || {};
    const rescueTopology = rescue.status?.topology || {};
    const rescueArtifacts = rescue.artifacts || {};
    const checks = data.hy?.checks || [];
    const profiles = sortedProfiles(data.profiles?.profiles || []);
    const duplicateUsers = data.profiles?.duplicate_hysteria_users || [];
    const doctorSummary = doctor.summary || {};
    const doctorChecked = Array.isArray(doctor.checks) && doctor.checks.length > 0 || Number(doctorSummary.checks || 0) > 0;
    const doctorClass = !doctorChecked ? "warn" : doctor.ok === false ? "fail" : doctorSummary.warn ? "warn" : "ok";
    const rescueChecked = rescue.ok === true || rescue.ok === false || Boolean(rescue.error);
    const rescueClass = !rescueChecked ? "warn" : rescue.ok ? (rescueState.behind_nat ? "warn" : "ok") : "fail";
    const healthChecked = Boolean(health.checked_at || health.summary?.checks);
    const healthClass = !healthChecked ? "warn" : health.ok && doctorClass !== "fail" ? "ok" : "fail";
    const bootstrapScript = bootstrap.script || "";
    const systemMonitor = data.status?.system_monitor || {};
    const rebootSummary = data.status?.reboot_summary || {};
    const connectivity = data.status?.connectivity || {};
    const wan = connectivity.wan || {};
    const cloud = connectivity.cloud || {};
    const remoteSyslog = connectivity.remote_syslog || {};
    fab.className = `kvx-fab ${healthClass}`;

    panel.innerHTML = `
      <div class="kvx-head">
        <div>
          <h3>VPN / Профили</h3>
          <p>Безопасное переключение provider VLESS и manual HY2/VLESS поверх текущей панели.</p>
        </div>
        <div class="kvx-actions">
          <button class="kvx-btn" data-kvx="refresh">Обновить</button>
          <button class="kvx-btn" data-kvx="health">Health</button>
          <button class="kvx-btn" data-kvx="close">Закрыть</button>
        </div>
      </div>
      <div class="kvx-grid">
        <article class="kvx-card">
          <b>Активный профиль</b>
          <span>${esc(selected.name || data.status?.selected || "—")}</span>
          <div><span class="kvx-tag ${selected.protocol === "hysteria2" ? "hy2" : ""}">${esc(selected.display_protocol || selected.protocol || "—")}</span> ${selected.active ? '<span class="kvx-tag ok">активен</span>' : ""}</div>
          <em>${esc([selected.user && `user=${selected.user}`, selected.server, selected.sni && `sni=${selected.sni}`, selected.obfs && `obfs=${selected.obfs}`, selected.pin_present ? "pin" : ""].filter(Boolean).join(" · ") || "metadata нет")}</em>
        </article>
        <article class="kvx-card">
          <b>Health</b>
          <span>${checkTag(health.overall || (health.ok ? "ok" : "warn"))} проверок=${esc(health.summary?.checks ?? "—")} ошибок=${esc(health.summary?.fails ?? "—")} замечаний=${esc(health.summary?.warns ?? "—")}</span>
          <em>check_current: ${esc(data.current?.ok ? "ok" : "—")} ${esc(data.current?.ip || "")} ${esc(data.current?.youtube || "")}</em>
        </article>
        <article class="kvx-card">
          <b>HY2 диагностика</b>
          <span>${checks.map((c) => `${esc(c.id)}:${esc(c.state)}`).join(" · ") || "—"}</span>
          <em>${duplicateUsers.length ? `Дубликаты HY2 users: ${duplicateUsers.map((d) => `${d.user}×${d.count}`).join(", ")}` : "Дубликатов HY2 users нет"}</em>
        </article>
        <article class="kvx-card">
          <b>Окружение / Doctor</b>
          <span>${checkTag(doctorClass)} ${doctorChecked ? `проверок=${esc(doctorSummary.checks ?? "—")} ошибок=${esc(doctorSummary.fail ?? "—")} замечаний=${esc(doctorSummary.warn ?? "—")}` : "не проверено"}</span>
          <em>/opt свободно: ${esc(doctor.storage?.opt_free_kb ?? "—")}K · bootstrap=${esc(bootstrap.version || "—")}</em>
        </article>
        <article class="kvx-card">
          <b>Rescue VPN</b>
          <span>${checkTag(rescueClass)} ${rescueChecked ? `WAN=${esc(rescueState.wan_ip || "—")} ${esc(rescueState.wan_class || "")}` : "не проверено"}</span>
          <em>${esc(rescueTopology.vps || "—")}:${esc(rescueTopology.port || "—")} · LAN ${esc(rescueTopology.home_lan || rescueState.home_lan || "—")}</em>
        </article>
        <article class="kvx-card">
          <b>Роутер / удалённый доступ</b>
          <span>${checkTag(wan.ok ? "ok" : "warn")} uptime=${esc(durationText(systemMonitor.last_uptime_s))} · WAN=${esc(wan.ok ? "ok" : "check")} · cloud=${esc(cloud.ok ? "ok" : "check")}</span>
          <em>Перезагрузки: ${esc(rebootSummary.last_24h ?? 0)} / 24ч, ${esc(rebootSummary.last_7d ?? 0)} / 7д · syslog=${esc(remoteSyslog.configured ? (remoteSyslog.servers || []).join(", ") : "не настроен")}</em>
        </article>
      </div>
      <h4>Окружение / Bootstrap</h4>
      <div class="kvx-actions">
        <button class="kvx-btn" data-kvx="doctor">Doctor</button>
        <button class="kvx-btn" data-kvx="bootstrap-copy" ${bootstrapScript ? "" : "disabled"}>Скопировать bootstrap</button>
        <button class="kvx-btn" data-kvx="bootstrap-download" ${bootstrapScript ? "" : "disabled"}>Скачать bootstrap.sh</button>
      </div>
      <div class="kvx-table" style="margin-top:8px">${doctorRows(doctor)}</div>
      <textarea class="kvx-script" readonly>${esc(bootstrapScript)}</textarea>
      <h4>Rescue VPN / WireGuard</h4>
      <div class="kvx-actions">
        <button class="kvx-btn" data-kvx="rescue-refresh">Обновить rescue</button>
        <button class="kvx-btn primary" data-kvx="rescue-copy-vps_script" ${rescueArtifacts.vps_script ? "" : "disabled"}>Скопировать VPS script</button>
        <button class="kvx-btn" data-kvx="rescue-download-vps_script" ${rescueArtifacts.vps_script ? "" : "disabled"}>Скачать VPS script</button>
        <button class="kvx-btn" data-kvx="rescue-copy-router_template" ${rescueArtifacts.router_template ? "" : "disabled"}>Router template</button>
        <button class="kvx-btn" data-kvx="rescue-download-router_template" ${rescueArtifacts.router_template ? "" : "disabled"}>Скачать router</button>
        <button class="kvx-btn" data-kvx="rescue-copy-operator_template" ${rescueArtifacts.operator_template ? "" : "disabled"}>Operator template</button>
        <button class="kvx-btn" data-kvx="rescue-download-operator_template" ${rescueArtifacts.operator_template ? "" : "disabled"}>Скачать operator</button>
        <button class="kvx-btn" data-kvx="rescue-download-readme" ${rescueArtifacts.readme ? "" : "disabled"}>README</button>
      </div>
      <div class="kvx-grid">
        <article class="kvx-card">
          <b>Что делает</b>
          <span>Read-only генератор: пульт ничего не применяет сам.</span>
          <em>${esc(rescue.status?.recommendation?.reason || "Сначала генерируем артефакты, apply — отдельной безопасной фазой.")}</em>
        </article>
        <article class="kvx-card">
          <b>Топология</b>
          <span>VPS ${esc(rescueTopology.vps || "—")}:${esc(rescueTopology.port || "—")} · сеть ${esc(rescueTopology.network || "—")}</span>
          <em>Keenetic ${esc(rescueTopology.router_addr || "—")} · operator ${esc(rescueTopology.operator_addr || "—")}</em>
        </article>
      </div>
      <div class="kvx-textgrid">
        <label>VPS setup script<textarea class="kvx-script small" readonly>${esc(rescueArtifacts.vps_script || "")}</textarea></label>
        <label>Keenetic router template<textarea class="kvx-script small" readonly>${esc(rescueArtifacts.router_template || "")}</textarea></label>
        <label>Operator client template<textarea class="kvx-script small" readonly>${esc(rescueArtifacts.operator_template || "")}</textarea></label>
      </div>
      <h4>VPN-профили</h4>
      <div class="kvx-table">
        ${profiles.map((p) => `
          <div class="kvx-row ${p.active ? "active" : ""}" data-id="${esc(p.id)}">
            <div class="kvx-row-main">
              <strong>${esc(profileName(p))}</strong>
              <span><span class="kvx-tag ${p.protocol === "hysteria2" ? "hy2" : ""}">${esc(p.display_protocol || p.protocol)}</span> ${esc(profileDetails(p))}</span>
              <em>${esc(p.health || "manual")}${p.note ? ` · ${esc(short(p.note, 120))}` : ""} ${p.checked_at ? `· checked ${p.checked_at}` : ""}</em>
            </div>
            <div class="kvx-row-actions">
              <button class="kvx-btn" data-kvx="scan-profile" data-id="${esc(p.id)}">Проверить доступность</button>
              <button class="kvx-btn primary" data-kvx="select" data-id="${esc(p.id)}" ${p.active ? "disabled" : ""}>Выбрать</button>
              ${p.source === "manual" ? `
                <button class="kvx-btn" data-kvx="rename" data-id="${esc(p.id)}">Имя</button>
                <button class="kvx-btn" data-kvx="duplicate" data-id="${esc(p.id)}">Копия</button>
                <button class="kvx-btn danger" data-kvx="delete" data-id="${esc(p.id)}" ${p.active ? 'disabled title="Нельзя удалить активный профиль"' : ""}>Удалить</button>
              ` : ""}
            </div>
          </div>
        `).join("") || '<div class="kvx-muted">Профили пока не загружены.</div>'}
      </div>
      <div class="kvx-form">
        <h4>Добавить HY2/VLESS ссылку</h4>
        <input class="kvx-name" placeholder="Название, например HEL-user3 HY2">
        <textarea class="kvx-link" placeholder="hysteria2://... или vless://..."></textarea>
        <div class="kvx-actions">
          <button class="kvx-btn" data-kvx="test-new">Проверить ссылку</button>
          <button class="kvx-btn primary" data-kvx="add-new">Добавить</button>
        </div>
      </div>
      <pre class="kvx-log">${esc(message)}</pre>
    `;
    setBusy(false);
  }

  async function refresh(message = "", options = {}) {
    if (state.refreshPromise) {
      state.pendingRefresh = {
        message: message || state.pendingRefresh?.message || "",
        options: mergeRefreshOptions(state.pendingRefresh?.options, options)
      };
      await state.refreshPromise;
      const pending = state.pendingRefresh;
      if (!pending) return state.data;
      state.pendingRefresh = null;
      return refresh(pending.message, pending.options);
    }
    state.refreshPromise = (async () => {
      setBusy(true);
      if (!state.data) renderLoading(message || "Первичная загрузка…");
      const includeHealth = options.health === true || options.deep === true;
      const includeDoctor = options.doctor === true || options.deep === true;
      const includeBootstrap = options.bootstrap === true || includeDoctor || options.deep === true;
      const includeRescue = options.rescue === true || options.deep === true;
      const tasks = [
        { key: "expertSnapshot", run: () => api({ action: "expert_snapshot" }, 90000) }
      ];
      if (includeBootstrap) tasks.push({ key: "bootstrap", run: () => api({ action: "bootstrap_script" }, 60000) });
      if (includeDoctor) tasks.push({ key: "doctor", run: () => api({ action: "dependency_doctor" }, 120000) });
      if (includeRescue) tasks.push({ key: "rescue", run: () => api({ action: "rescue_wireguard" }, 90000) });
      if (includeHealth) tasks.push({ key: "health", run: () => api({ action: "health_report" }, 180000) });
      const data = await runLimited(tasks, options.limit || 2);
      const aggregate = data.expertSnapshot;
      if (aggregate?.status && aggregate?.profiles && Array.isArray(aggregate?.manualList)) {
        data.status = aggregate.status;
        data.profiles = aggregate.profiles;
        data.manualList = aggregate.manualList;
      } else {
        const fallback = await runLimited([
          { key: "status", run: () => api({ action: "status" }, 60000) },
          { key: "profiles", run: () => api({ action: "profiles" }, 90000) },
          { key: "manualList", run: () => api({ action: "manual_list" }, 60000) }
        ], options.limit || 2);
        Object.assign(data, fallback);
      }
      const previous = state.data || {};
      const health = data.health || data.status?.health_last || previous.health || {};
      const hy = data.health?.hysteria_diagnostics || previous.hy || { ok: false, skipped: true, reason: "run Health for live HY2 diagnostics" };
      const current = health.current_server || previous.current || { ok: false, skipped: true, reason: "run Health for live check_current" };
      const manualList = Array.isArray(data.manualList) ? data.manualList : [];
      const manualMap = {};
      manualList.forEach((item) => { manualMap[item.id] = item; });
      const profileList = Array.isArray(data.profiles?.profiles) ? data.profiles.profiles : [];
      state.profileById = {};
      profileList.forEach((item) => { state.profileById[item.id] = { ...item, ...(manualMap[item.id] || {}) }; });
      manualList.forEach((item) => { if (!state.profileById[item.id]) state.profileById[item.id] = item; });
      state.data = {
        ...previous,
        version: data.version || previous.version || { version: data.status?.version || "" },
        status: data.status || previous.status || {},
        profiles: data.profiles || previous.profiles || {},
        hy,
        health,
        current,
        manualList: manualList.length ? manualList : (previous.manualList || []),
        doctor: data.doctor || previous.doctor || {},
        bootstrap: data.bootstrap || previous.bootstrap || {},
        rescue: data.rescue || previous.rescue || {}
      };
      state.lastRefreshAt = Date.now();
      const failures = Object.entries(data).filter(([, value]) => value && value.ok === false).map(([key]) => key);
      const suffix = failures.length ? `\nЧасть запросов не ответила: ${failures.join(", ")}` : "";
      render(state.data, (message || `version=${state.data.version.version || "?"}`) + suffix);
      return state.data;
    })().catch((err) => {
      const data = state.data || {};
      render(data, `Ошибка refresh: ${err?.message || String(err)}`);
      return data;
    }).finally(() => {
      state.refreshPromise = null;
      setBusy(false);
    });
    return state.refreshPromise;
  }

  async function runSelectAsync(id, item) {
    setBusy(true);
    let finalResult = null;
    const requestedAt = Math.floor(Date.now() / 1000);
    try {
      const start = await startSelectOperation(id, profileName(item), requestedAt);
      if (!start?.ok || !start.id) {
        finalResult = start;
      } else {
        saveSelectJob({ id: start.id, requestId: start.request_id || "", server: String(id), name: profileName(item), startedAt: Number(start.started_at || requestedAt) });
        render(state.data || {}, `Переключаю на ${profileName(item)}…\nЗадача ${start.id} запущена.`);
        setBusy(true);
        for (let attempt = 0; attempt < 120; attempt += 1) {
          await sleep(attempt < 3 ? 1500 : 3000);
          const status = await api({ action: "select_status", select_id: start.id, request_id: start.request_id || "" }, 30000);
          if (!status?.ok) {
            finalResult = status;
            render(state.data || {}, `Переключение продолжается на роутере. Облако временно не ответило (${attempt + 1}); повторяю проверку…`);
            setBusy(true);
            continue;
          }
          finalResult = status;
          const result = status?.result || {};
          const check = result.check_current || {};
          render(state.data || {}, [
            `Переключаю на ${profileName(item)}…`,
            `Состояние: ${status?.state || "unknown"}${status?.duration_sec ? `, ${status.duration_sec} сек.` : ""}`,
            check.ip ? `Проверка через прокси: ${check.ip}, YouTube ${check.youtube || "—"}` : "",
            result.error ? `Ошибка: ${result.error}` : ""
          ].filter(Boolean).join("\n"));
          setBusy(true);
          if (status?.done || status?.state === "success" || status?.state === "failed") {
            clearSelectJob();
            break;
          }
        }
      }
    } catch (err) {
      finalResult = { ok: false, error: err?.message || String(err) };
    }
    return refresh(`select ${id}:\n${JSON.stringify(finalResult, null, 2)}`);
  }

  async function safeSelectFromExpert(id) {
    const serverId = String(id || "");
    if (!serverId) return { ok: false, error: "server id is missing" };
    await openProfilePanel();
    const item = state.profileById[serverId] || { id: serverId, name_ru: `Сервер ${serverId}` };
    if (item.active) return refresh(`${profileName(item)} уже выбран.`);
    if (!confirm(`Переключить на ${profileName(item)}? Будет выполнена проверка и откат при ошибке.`)) {
      return { ok: false, cancelled: true };
    }
    return runSelectAsync(serverId, item);
  }

  window.__keenvlessSafeSelect = safeSelectFromExpert;

  async function resumePendingSelect() {
    const pending = loadSelectJob();
    if ((!pending?.id && !pending?.requestId) || state.resumingSelect) return;
    state.resumingSelect = true;
    setBusy(true);
    let finalResult = null;
    let missingCount = 0;
    try {
      for (let attempt = 0; attempt < 120; attempt += 1) {
        let status;
        if (pending.id) {
          status = await api({ action: "select_status", select_id: pending.id, request_id: pending.requestId || "" }, 30000);
        } else {
          status = await api({ action: "select_status", request_id: pending.requestId }, 30000);
          if (status?.id) {
            pending.id = status.id;
            pending.startedAt = Number(status.started_at || pending.startedAt || 0);
            saveSelectJob(pending);
            missingCount = 0;
          } else if (status?.ok && (status?.state === "none" || !status?.state)) {
            missingCount += 1;
            if (missingCount >= 3) {
              clearSelectJob();
              finalResult = { ok: false, state: "not_found", error: "saved selection job was not found; no command was repeated" };
              render(state.data || {}, "Сохранённая задача переключения не найдена. Новая команда не запускалась.");
              break;
            }
          }
        }
        if (!status?.ok) {
          render(state.data || {}, `Восстанавливаю наблюдение за переключением ${pending.name || pending.server}. Облако пока не отвечает…`);
          await sleep(3000);
          continue;
        }
        finalResult = status;
        render(state.data || {}, `Переключение ${pending.name || pending.server}: ${status.state || "running"}${status.duration_sec ? `, ${status.duration_sec} сек.` : ""}`);
        if (status.done || status.state === "success" || status.state === "failed") {
          clearSelectJob();
          break;
        }
        await sleep(3000);
      }
    } finally {
      state.resumingSelect = false;
      setBusy(false);
    }
    return refresh(`Возобновлённая задача переключения:\n${JSON.stringify(finalResult, null, 2)}`);
  }

  async function handleAction(action, target) {
    const id = target.getAttribute("data-id");
    const item = id ? state.profileById[id] : null;
    if (action === "close") {
      closeProfilePanel();
      return;
    }
    if (action === "refresh") return refresh("Быстрые данные обновлены");
    if (action === "health") return refresh("Health обновлён", { health: true });
    if (action === "doctor") return refresh("Dependency doctor обновлён", { doctor: true, bootstrap: true });
    if (action === "rescue-refresh") return refresh("Rescue VPN обновлён", { rescue: true });
    if (action.startsWith("rescue-copy-") || action.startsWith("rescue-download-")) {
      const download = action.startsWith("rescue-download-");
      const key = action.replace(download ? "rescue-download-" : "rescue-copy-", "");
      const text = state.data?.rescue?.artifacts?.[key] || "";
      const filename = state.data?.rescue?.filenames?.[key] || `${key}.txt`;
      if (!text) return render(state.data || {}, "Rescue artifact пуст.");
      if (download) {
        downloadText(filename, text);
        return render(state.data || {}, `Скачан ${filename}`);
      }
      const ok = await copyText(text);
      return render(state.data || {}, ok ? `Скопирован ${filename}` : "Не смог скопировать автоматически; выдели textarea вручную.");
    }
    if (action === "bootstrap-copy") {
      const script = state.data?.bootstrap?.script || $(".kvx-script", panel)?.value || "";
      if (!script) return render(state.data || {}, "Bootstrap script пуст.");
      const ok = await copyText(script);
      return render(state.data || {}, ok ? "Bootstrap script скопирован." : "Не смог скопировать автоматически; выдели textarea вручную.");
    }
    if (action === "bootstrap-download") {
      const script = state.data?.bootstrap?.script || $(".kvx-script", panel)?.value || "";
      if (!script) return render(state.data || {}, "Bootstrap script пуст.");
      downloadText(`keenvless-bootstrap-${state.data?.bootstrap?.version || "latest"}.sh`, script);
      return render(state.data || {}, "Bootstrap script скачан.");
    }
    if (action === "scan-profile" && id) {
      setBusy(true);
      const res = await api({ action: "scan_current", server: id }, 120000);
      return refresh(`scan ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "select" && id) {
      if (!confirm(`Переключить на ${profileName(item)}? Select делает реальную проверку и откат при ошибке.`)) return;
      return runSelectAsync(id, item);
    }
    if (action === "rename" && id) {
      const name = prompt("Новое название профиля", item?.name_ru || item?.name_en || "");
      if (!name) return;
      setBusy(true);
      const res = await api({ action: "manual_rename", manual_id: id, manual_name_b64: b64(name) }, 60000);
      return refresh(`rename ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "duplicate" && id) {
      const name = prompt("Название копии", `${item?.name_ru || item?.name_en || "Manual"} copy`);
      if (name === null) return;
      setBusy(true);
      const res = await api({ action: "manual_duplicate", manual_id: id, manual_name_b64: b64(name) }, 60000);
      return refresh(`duplicate ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "delete" && id) {
      if (item?.active) return refresh("Активный профиль не удаляю: сначала выбери другой и дождись успешной проверки.");
      if (!confirm(`Удалить профиль ${item?.name_ru || item?.name_en || id}?`)) return;
      setBusy(true);
      const res = await api({ action: "manual_delete", manual_id: id }, 60000);
      return refresh(`delete ${id}:\n${JSON.stringify(res, null, 2)}`);
    }
    if (action === "test-new" || action === "add-new") {
      const name = $(".kvx-name", panel)?.value?.trim() || "";
      const link = $(".kvx-link", panel)?.value?.trim() || "";
      if (!link) return render(state.data || {}, "Сначала вставь ссылку.");
      setBusy(true);
      const test = await api({ action: "manual_test", manual_link_b64: b64(link) }, 90000);
      if (!test.ok || action === "test-new") return refresh(`manual_test new:\n${JSON.stringify(test, null, 2)}`);
      const add = await api({ action: "manual_add", manual_name_b64: b64(name), manual_link_b64: b64(link) }, 60000);
      return refresh(`manual_add:\n${JSON.stringify(add, null, 2)}`);
    }
  }

  function mount() {
    const style = document.createElement("style");
    style.textContent = css;
    document.head.appendChild(style);

    const backdrop = document.createElement("div");
    backdrop.className = "kvx-backdrop";
    document.body.appendChild(backdrop);

    panel = document.createElement("section");
    panel.className = "kvx-panel";
    document.body.appendChild(panel);

    fab = document.createElement("button");
    fab.className = "kvx-fab";
    fab.type = "button";
    fab.textContent = "VPN / Профили";
    document.body.appendChild(fab);

    fab.addEventListener("click", async () => {
      if (panel.classList.contains("open")) closeProfilePanel();
      else await openProfilePanel();
    });
    document.addEventListener("click", (event) => {
      const button = event.target.closest?.("button.kvx-open-profiles");
      if (!button || !button.closest("app-root")) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      openProfilePanel();
    }, true);
    backdrop.addEventListener("click", () => handleAction("close", backdrop));
    panel.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-kvx]");
      if (!btn) return;
      event.preventDefault();
      handleAction(btn.getAttribute("data-kvx"), btn);
    });
    startUiPolish();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount, { once: true });
  } else {
    mount();
  }
})();
