#!/bin/sh
PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
. /opt/etc/keenvless/keenvless.conf
[ -r /opt/share/www/oauth-yandex-lib.sh ] && . /opt/share/www/oauth-yandex-lib.sh

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  post_body="$(head -c "${CONTENT_LENGTH:-0}" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    if [ -n "$request_params" ]; then
      request_params="$request_params&$post_body"
    else
      request_params="$post_body"
    fi
  fi
fi

decode() {
  printf '%s' "$1" | sed 's/+/ /g;s/%2E/./Ig;s/%2D/-/Ig;s/%5F/_/Ig;s/%2F/\//Ig;s/%2C/,/Ig;s/%3A/:/Ig;s/%20/ /Ig;s/%2A/*/Ig;s/%24/$/Ig;s/%5B/[/Ig;s/%5D/]/Ig;s/%5C/\\/Ig;s/%7C/|/Ig;s/%3F/?/Ig;s/%2B/+/Ig;s/%3D/=/Ig;s/%5E/^/Ig;s/%7B/{/Ig;s/%7D/}/Ig'
}

param() {
  printf '%s' "$request_params" | awk -v RS='&' -F= -v k="$1" '$1 == k {print substr($0, length(k) + 2); exit}'
}

has_p() {
  case "&$request_params" in
    *"&$1="*) return 0 ;;
  esac
  return 1
}

dv() {
  if has_p "$1"; then
    value="$(decode "$(param "$1")")"
    value_quoted="$(printf "%s" "$value" | sed "s/'/'\\\\''/g")"
    eval "$1='$value_quoted'"
  else
    eval "$1=''"
  fi
}

# Decode only parameters actually present in the request (was: 86 eager decodes on
# every request). Result is identical: absent keys decode to empty either way, but
# a typical param-free poll now spawns no per-parameter processes.
dv action
dv token
dv target
dv token_required
dv web_token
dv remote_web_enabled
dv remote_web_port
dv remote_web_sources
dv server
dv select_id
dv request_id
dv client
dv sources
dv proxy_sources
dv direct_sources
dv ports
dv block_udp443
dv proxy_domains
dv proxy_ips
dv direct_domains
dv direct_ips
dv destination
dv route_destinations
dv health_client
dv route_profile
dv route_scenario
dv client_mode
dv group_id
dv group_mode
dv group_name_b64
dv group_members
dv rule_apply_dest
dv preset_id
dv preset_name_b64
dv server_group
dv event_kind
dv favorites
dv import_b64
dv rules_b64
dv manual_id
dv manual_name_b64
dv manual_link_b64
dv backup
dv router_id
dv sync_from
dv sync_to
dv router_name_b64
dv router_url_b64
dv router_token_b64
dv router_resolve_ip
dv router_local_name_b64
dv update_id
dv update_version
dv update_size
dv update_sha256
dv update_offset
dv update_chunk_sha256
dv update_chunk_b64
dv xray_url_b64
dv github_tag
dv github_repo
dv github_token
dv watchdog_enabled
dv watchdog_interval_min
dv watchdog_probe_after_fails
dv watchdog_switch_after_fails
dv watchdog_candidate_count
dv watchdog_switch_cooldown_min
dv watchdog_fallback_direct
dv watchdog_restore_original
dv watchdog_quarantine_min
dv watchdog_restore_ok_count
dv watchdog_flap_window_min
dv watchdog_max_switches_window
dv mobile_watchdog_enabled
dv mobile_watchdog_interval_min
dv mobile_watchdog_fail_min
dv mobile_watchdog_usb_off_sec
dv mobile_watchdog_iface
dv dns_monitor_enabled
dv dns_monitor_interval_min
dv dns_monitor_hosts
dv yandex_oauth_enabled
dv yandex_client_id
dv yandex_client_secret
dv yandex_allowed_phones
dv yandex_session_ttl_sec
dv yandex_redirect_uri
router_name=""
router_url=""
router_token=""
router_local_name=""
xray_url=""
[ -n "$router_name_b64" ] && router_name="$(printf '%s' "$router_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_url_b64" ] && router_url="$(printf '%s' "$router_url_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_token_b64" ] && router_token="$(printf '%s' "$router_token_b64" | base64 -d 2>/dev/null || true)"
[ -n "$router_local_name_b64" ] && router_local_name="$(printf '%s' "$router_local_name_b64" | base64 -d 2>/dev/null || true)"
[ -n "$xray_url_b64" ] && xray_url="$(printf '%s' "$xray_url_b64" | base64 -d 2>/dev/null || true)"
preset_name=""
[ -n "$preset_name_b64" ] && preset_name="$(printf '%s' "$preset_name_b64" | base64 -d 2>/dev/null || true)"
group_name=""
[ -n "$group_name_b64" ] && group_name="$(printf '%s' "$group_name_b64" | base64 -d 2>/dev/null || true)"

client_ip="${REMOTE_ADDR:-}"
if [ "$client_ip" = "127.0.0.1" ] || [ "$client_ip" = "::1" ]; then
  forwarded="${HTTP_X_FORWARDED_FOR:-${HTTP_X_REAL_IP:-}}"
  if [ -n "$forwarded" ]; then
    client_ip="$(printf '%s' "$forwarded" | sed 's/,.*//;s/[[:space:]]//g')"
  fi
fi
[ -n "$client_ip" ] || client_ip="${REMOTE_ADDR:-127.0.0.1}"

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

TOKEN_REQUIRED="${TOKEN_REQUIRED:-0}"
auth_method="none"
if [ "$TOKEN_REQUIRED" = "1" ]; then
  auth_ok=0
  if [ "$token" = "${TOKEN:-}" ]; then
    auth_ok=1
    auth_method="token"
  elif command -v kvx_session_valid >/dev/null 2>&1 && kvx_session_valid; then
    auth_ok=1
    auth_method="yandex"
  fi
  if [ "$auth_ok" != "1" ]; then
  printf '{"ok":false,"error":"unauthorized"}\n'
  exit 0
  fi
fi

if [ -n "$target" ] && [ "$target" != "local" ]; then
  case "$action" in
    router_targets|router_local_name|router_target_add|router_target_delete|router_target_test)
      ;;
    *)
      /opt/bin/keenvless router-proxy "$target" "$request_params"
      exit 0
      ;;
  esac
fi

# ---- hot-read JSON cache (RAM/tmpfs, short TTL) ----
# The home screen and expert panels poll the same read-only data repeatedly.
# Keep small, valid JSON snapshots in /tmp and invalidate them around actions
# that can alter profiles, routes, health or service state. Polling/status and
# update-upload requests must not make unrelated reads cold. All TTLs can be
# set to 0 in keenvless.conf to turn the corresponding cache off.
KV_CACHE_DIR="${KV_CACHE_DIR:-/tmp/keenvless-cache}"
KV_STATUS_CACHE_TTL="${KV_STATUS_CACHE_TTL:-30}"
KV_DASHBOARD_CACHE_TTL="${KV_DASHBOARD_CACHE_TTL:-60}"
KV_PROFILES_CACHE_TTL="${KV_PROFILES_CACHE_TTL:-30}"
KV_MANUAL_LIST_CACHE_TTL="${KV_MANUAL_LIST_CACHE_TTL:-30}"
KV_EXPERT_SNAPSHOT_CACHE_TTL="${KV_EXPERT_SNAPSHOT_CACHE_TTL:-30}"
KV_EXPERT_OVERVIEW_CACHE_TTL="${KV_EXPERT_OVERVIEW_CACHE_TTL:-30}"
KV_EXPERT_OVERVIEW_MAX_STALE="${KV_EXPERT_OVERVIEW_MAX_STALE:-86400}"
KV_ALERTS_CACHE_TTL="${KV_ALERTS_CACHE_TTL:-60}"
KV_METRICS_CACHE_TTL="${KV_METRICS_CACHE_TTL:-60}"
KV_HEALTH_HISTORY_CACHE_TTL="${KV_HEALTH_HISTORY_CACHE_TTL:-10}"
KV_ROUTER_INFO_CACHE_TTL="${KV_ROUTER_INFO_CACHE_TTL:-60}"
KV_ROUTER_TARGETS_CACHE_TTL="${KV_ROUTER_TARGETS_CACHE_TTL:-60}"
KV_EXTERNAL_IP_CACHE_TTL="${KV_EXTERNAL_IP_CACHE_TTL:-60}"
KV_TRAFFIC_PLAN_CACHE_TTL="${KV_TRAFFIC_PLAN_CACHE_TTL:-60}"
KV_HEAVY_CACHE_MAX_STALE="${KV_HEAVY_CACHE_MAX_STALE:-300}"
KV_HEAVY_CACHE_LOCK_MAX_AGE="${KV_HEAVY_CACHE_LOCK_MAX_AGE:-120}"
KV_HEAVY_CACHE_WAIT_SEC="${KV_HEAVY_CACHE_WAIT_SEC:-20}"
# The simple UI can use a compact, non-secret snapshot.  It lives only on the
# tmpfs and is built in the background, so a slow status read never blocks the
# first paint of a page that already has a previous snapshot.
KV_OVERVIEW_CACHE_TTL="${KV_OVERVIEW_CACHE_TTL:-15}"
KV_OVERVIEW_LOCK_MAX_AGE="${KV_OVERVIEW_LOCK_MAX_AGE:-180}"

kv_cache_ttl() {
  case "$1" in ''|*[!0-9]*) printf '0' ;; *) printf '%s' "$1" ;; esac
}

KV_STATUS_CACHE_TTL="$(kv_cache_ttl "$KV_STATUS_CACHE_TTL")"
KV_DASHBOARD_CACHE_TTL="$(kv_cache_ttl "$KV_DASHBOARD_CACHE_TTL")"
KV_PROFILES_CACHE_TTL="$(kv_cache_ttl "$KV_PROFILES_CACHE_TTL")"
KV_MANUAL_LIST_CACHE_TTL="$(kv_cache_ttl "$KV_MANUAL_LIST_CACHE_TTL")"
KV_EXPERT_SNAPSHOT_CACHE_TTL="$(kv_cache_ttl "$KV_EXPERT_SNAPSHOT_CACHE_TTL")"
KV_EXPERT_OVERVIEW_CACHE_TTL="$(kv_cache_ttl "$KV_EXPERT_OVERVIEW_CACHE_TTL")"
KV_EXPERT_OVERVIEW_MAX_STALE="$(kv_cache_ttl "$KV_EXPERT_OVERVIEW_MAX_STALE")"
KV_ALERTS_CACHE_TTL="$(kv_cache_ttl "$KV_ALERTS_CACHE_TTL")"
KV_METRICS_CACHE_TTL="$(kv_cache_ttl "$KV_METRICS_CACHE_TTL")"
KV_HEALTH_HISTORY_CACHE_TTL="$(kv_cache_ttl "$KV_HEALTH_HISTORY_CACHE_TTL")"
KV_ROUTER_INFO_CACHE_TTL="$(kv_cache_ttl "$KV_ROUTER_INFO_CACHE_TTL")"
KV_ROUTER_TARGETS_CACHE_TTL="$(kv_cache_ttl "$KV_ROUTER_TARGETS_CACHE_TTL")"
KV_EXTERNAL_IP_CACHE_TTL="$(kv_cache_ttl "$KV_EXTERNAL_IP_CACHE_TTL")"
KV_TRAFFIC_PLAN_CACHE_TTL="$(kv_cache_ttl "$KV_TRAFFIC_PLAN_CACHE_TTL")"
KV_HEAVY_CACHE_MAX_STALE="$(kv_cache_ttl "$KV_HEAVY_CACHE_MAX_STALE")"
KV_HEAVY_CACHE_LOCK_MAX_AGE="$(kv_cache_ttl "$KV_HEAVY_CACHE_LOCK_MAX_AGE")"
KV_HEAVY_CACHE_WAIT_SEC="$(kv_cache_ttl "$KV_HEAVY_CACHE_WAIT_SEC")"
KV_OVERVIEW_CACHE_TTL="$(kv_cache_ttl "$KV_OVERVIEW_CACHE_TTL")"
KV_OVERVIEW_LOCK_MAX_AGE="$(kv_cache_ttl "$KV_OVERVIEW_LOCK_MAX_AGE")"
[ "$KV_HEAVY_CACHE_LOCK_MAX_AGE" -gt 0 ] || KV_HEAVY_CACHE_LOCK_MAX_AGE=120
[ "$KV_HEAVY_CACHE_WAIT_SEC" -gt 0 ] || KV_HEAVY_CACHE_WAIT_SEC=20
[ "$KV_OVERVIEW_LOCK_MAX_AGE" -gt 0 ] || KV_OVERVIEW_LOCK_MAX_AGE=180

KV_OVERVIEW_FILE="$KV_CACHE_DIR/overview.json"
KV_OVERVIEW_STAMP="$KV_CACHE_DIR/overview.json.at"
KV_OVERVIEW_LOCK="$KV_CACHE_DIR/overview.refresh.lock"
KV_OVERVIEW_GENERATION="$KV_CACHE_DIR/overview.generation"
KV_CACHE_GENERATION="$KV_CACHE_DIR/cache.generation"
KV_PERF_CACHE=none
KV_PERF_START=0
KV_PERF_END=0
read -r KV_PERF_START _kv_perf_rest < /proc/uptime 2>/dev/null || KV_PERF_START=0
case "$KV_PERF_START" in ''|*[!0-9.]*) KV_PERF_START=0 ;; esac
_kv_perf_seconds="${KV_PERF_START%%.*}"
case "$_kv_perf_seconds" in ''|*[!0-9]*) _kv_perf_seconds=0 ;; esac
_kv_perf_bucket=$((_kv_perf_seconds / 300))
KV_PERF_LOG="$KV_CACHE_DIR/performance-$_kv_perf_bucket.tsv"
if [ -d "$KV_CACHE_DIR" ] || mkdir -p "$KV_CACHE_DIR" 2>/dev/null; then
  if [ ! -e "$KV_PERF_LOG" ]; then
    for _kv_perf_old in "$KV_CACHE_DIR"/performance-*.tsv; do
      [ -e "$_kv_perf_old" ] || continue
      [ "$_kv_perf_old" = "$KV_PERF_LOG" ] || rm -f "$_kv_perf_old" 2>/dev/null || true
    done
    : > "$KV_PERF_LOG" 2>/dev/null || true
  fi
fi

kv_perf_finish() {
  _kv_perf_rc=$?
  read -r KV_PERF_END _kv_perf_rest < /proc/uptime 2>/dev/null || KV_PERF_END="$KV_PERF_START"
  _kv_perf_action="${action:-status}"
  case "$_kv_perf_action" in ''|*[!A-Za-z0-9_-]*) _kv_perf_action=unknown ;; esac
  if [ -n "$KV_PERF_LOG" ] && [ -d "$KV_CACHE_DIR" ]; then
    printf '%s\t%s\t%s\t%s\n' "$KV_PERF_START" "$KV_PERF_END" "$_kv_perf_action" "$KV_PERF_CACHE" \
      >> "$KV_PERF_LOG" 2>/dev/null || true
  fi
  return "$_kv_perf_rc"
}
trap 'kv_perf_finish' 0

kv_overview_valid() {
  [ -s "$KV_OVERVIEW_FILE" ] && [ -s "$KV_OVERVIEW_STAMP" ]
}

kv_overview_age() {
  if ! kv_overview_valid; then
    printf '%s\n' '-1'
    return 0
  fi
  kv_overview_at="$(cat "$KV_OVERVIEW_STAMP" 2>/dev/null || echo 0)"
  case "$kv_overview_at" in ''|*[!0-9]*) kv_overview_at=0 ;; esac
  kv_overview_now="$(date +%s)"
  kv_overview_age_value=$((kv_overview_now - kv_overview_at))
  [ "$kv_overview_age_value" -ge 0 ] || kv_overview_age_value=0
  printf '%s\n' "$kv_overview_age_value"
}

kv_overview_cleanup_stale_lock() {
  [ -d "$KV_OVERVIEW_LOCK" ] || return 0
  kv_overview_lock_at="$(cat "$KV_OVERVIEW_LOCK/at" 2>/dev/null || echo 0)"
  case "$kv_overview_lock_at" in ''|*[!0-9]*) kv_overview_lock_at=0 ;; esac
  kv_overview_now="$(date +%s)"
  kv_overview_lock_age=$((kv_overview_now - kv_overview_lock_at))
  if [ "$kv_overview_lock_at" -le 0 ] || [ "$kv_overview_lock_age" -gt "$KV_OVERVIEW_LOCK_MAX_AGE" ]; then
    rm -f "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
    rmdir "$KV_OVERVIEW_LOCK" 2>/dev/null || true
  fi
}

kv_overview_invalidate() {
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  printf '%s-%s\n' "$(date +%s)" "$$" > "$KV_OVERVIEW_GENERATION.tmp.$$" 2>/dev/null \
    && mv "$KV_OVERVIEW_GENERATION.tmp.$$" "$KV_OVERVIEW_GENERATION" 2>/dev/null || true
  # Keep the last validated snapshot available while its replacement is built.
  # Marking it exactly one TTL old makes the next read serve it as stale and
  # start a generation-protected refresh instead of falling back to slow live
  # status+profiles calls.
  if [ -s "$KV_OVERVIEW_FILE" ]; then
    kv_overview_stale_at=$(( $(date +%s) - KV_OVERVIEW_CACHE_TTL ))
    [ "$kv_overview_stale_at" -ge 0 ] || kv_overview_stale_at=0
    printf '%s\n' "$kv_overview_stale_at" > "$KV_OVERVIEW_STAMP.tmp.$$" 2>/dev/null \
      && mv "$KV_OVERVIEW_STAMP.tmp.$$" "$KV_OVERVIEW_STAMP" 2>/dev/null || true
  else
    rm -f "$KV_OVERVIEW_STAMP" 2>/dev/null || true
  fi
}

kv_overview_refresh_worker() {
  kv_overview_generation="$(cat "$KV_OVERVIEW_GENERATION" 2>/dev/null || true)"
  kv_overview_dir="$KV_CACHE_DIR/.overview-refresh-$$"
  if ! mkdir "$kv_overview_dir" 2>/dev/null; then
    rm -f "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
    rmdir "$KV_OVERVIEW_LOCK" 2>/dev/null || true
    return 0
  fi

  ( kv_cache_json status "$KV_STATUS_CACHE_TTL" status > "$kv_overview_dir/status.json" ) &
  kv_overview_status_pid=$!
  ( kv_cache_json profiles "$KV_PROFILES_CACHE_TTL" profiles > "$kv_overview_dir/profiles.json" ) &
  kv_overview_profiles_pid=$!
  wait "$kv_overview_status_pid" 2>/dev/null || true
  wait "$kv_overview_profiles_pid" 2>/dev/null || true

  jq -c -n \
    --slurpfile status "$kv_overview_dir/status.json" \
    --slurpfile profiles "$kv_overview_dir/profiles.json" '
        ($status[0] // {}) as $s |
        ($profiles[0] // {}) as $p |
        select(($s.ok // false) == true and ($p.ok // false) == true) |
        ($s.health_last // {}) as $health |
        ($health.current_server // {}) as $current |
        ($p.profiles // [] | map({
          id:(.id // "" | tostring),
          name:(.name // ""),
          source:(.source // ""),
          profile_kind:(.profile_kind // ""),
          protocol:(.protocol // ""),
          display_protocol:(.display_protocol // ""),
          health:(.health // "unknown"),
          note:(.note // ""),
          latency_ms:(.latency_ms // null),
          checked_at:(.checked_at // null),
          active:(.active // false),
          country_code:(.country_code // ""),
          favorite:(.favorite // false),
          user:(.user // ""),
          server:(.server // ""),
          port:(.port // ""),
          sni:(.sni // ""),
          obfs:(.obfs // ""),
          pin_present:(.pin_present // false)
        })) as $items |
        {
          ok:true,
          generated_at:(now|floor),
          status:{
            ok:(($s.ok // false) == true),
            version:($s.version // ""),
            api_version:($s.api_version // 0),
            min_ui_version:($s.min_ui_version // ""),
            running:($s.running // false),
            selected:($s.selected // ""),
            selected_health:($s.selected_health // ""),
            selected_latency_ms:($s.selected_latency_ms // null),
            selected_checked_at:($s.selected_checked_at // null),
            route_profile:($s.route_profile // ""),
            server_group:($s.server_group // ""),
            servers:($s.servers // 0),
            crond_running:($s.crond_running // false),
            watchdog_enabled:($s.watchdog_enabled // 0),
            system_monitor:($s.system_monitor // {}),
            reboot_summary:($s.reboot_summary // {}),
            connectivity:($s.connectivity // {}),
            health_last:{
              ok:(($health.ok // false) == true),
              overall:($health.overall // "unknown"),
              checked_at:($health.checked_at // 0),
              summary:{
                checks:($health.summary.checks // 0),
                fails:($health.summary.fails // 0),
                warns:($health.summary.warns // 0)
              },
              current_server:{
                ok:(($current.ok // false) == true),
                ip:($current.ip // ""),
                youtube:($current.youtube // ""),
                reason:($current.reason // "")
              }
            }
          },
          profiles:{
            ok:(($p.ok // false) == true),
            selected:($p.selected // ""),
            selected_profile:($items | map(select(.active == true)) | .[0] // null),
            duplicate_hysteria_users:(($p.duplicate_hysteria_users // []) | map({
              user:(.user // ""),
              count:(.count // 0),
              profiles:((.profiles // []) | map({id:(.id // ""),name:(.name // ""),active:(.active // false)}))
            })),
            summary:{
              total:($p.summary.total // 0),
              provider:($p.summary.provider // 0),
              manual:($p.summary.manual // 0),
              hysteria2:($p.summary.hysteria2 // 0),
              duplicate_hysteria_users:($p.summary.duplicate_hysteria_users // 0)
            },
            profiles:$items
          }
        }' > "$kv_overview_dir/overview.json" 2>/dev/null || rm -f "$kv_overview_dir/overview.json"

  if [ "$(cat "$KV_OVERVIEW_GENERATION" 2>/dev/null || true)" = "$kv_overview_generation" ] \
    && [ -s "$kv_overview_dir/overview.json" ]; then
    mv "$kv_overview_dir/overview.json" "$KV_OVERVIEW_FILE" 2>/dev/null || true
    date +%s > "$KV_OVERVIEW_STAMP.tmp.$$" 2>/dev/null && mv "$KV_OVERVIEW_STAMP.tmp.$$" "$KV_OVERVIEW_STAMP" 2>/dev/null || true
  fi

  rm -f "$kv_overview_dir/status.json" "$kv_overview_dir/profiles.json" "$kv_overview_dir/overview.json" 2>/dev/null || true
  rmdir "$kv_overview_dir" 2>/dev/null || true
  rm -f "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
  rmdir "$KV_OVERVIEW_LOCK" 2>/dev/null || true
}

kv_overview_start_refresh() {
  [ "$KV_OVERVIEW_CACHE_TTL" -gt 0 ] || return 0
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || return 0
  kv_overview_cleanup_stale_lock
  [ -d "$KV_OVERVIEW_LOCK" ] && return 0
  if mkdir "$KV_OVERVIEW_LOCK" 2>/dev/null; then
    date +%s > "$KV_OVERVIEW_LOCK/at" 2>/dev/null || true
    ( kv_overview_refresh_worker ) >/dev/null 2>&1 &
  fi
}

kv_overview_snapshot() {
  if [ "$KV_OVERVIEW_CACHE_TTL" -le 0 ]; then
    printf '{"ok":false,"state":"disabled"}\n'
    return 0
  fi
  kv_overview_age_value="$(kv_overview_age)"
  case "$kv_overview_age_value" in ''|*[!0-9-]*) kv_overview_age_value=-1 ;; esac
  if [ "$kv_overview_age_value" -lt 0 ] || [ "$kv_overview_age_value" -ge "$KV_OVERVIEW_CACHE_TTL" ]; then
    kv_overview_start_refresh
  fi
  kv_overview_refreshing=false
  [ -d "$KV_OVERVIEW_LOCK" ] && kv_overview_refreshing=true
  if [ "$kv_overview_age_value" -ge 0 ] && kv_overview_valid; then
    kv_overview_fresh=false
    [ "$kv_overview_age_value" -lt "$KV_OVERVIEW_CACHE_TTL" ] && kv_overview_fresh=true
    kv_overview_stale=true
    [ "$kv_overview_fresh" = true ] && kv_overview_stale=false
    [ "$kv_overview_fresh" = true ] && KV_PERF_CACHE=hit_fresh || KV_PERF_CACHE=hit_stale
    printf '{"ok":true,"source":"ram_snapshot","age_sec":%s,"fresh":%s,"stale":%s,"refreshing":%s,"snapshot":' \
      "$kv_overview_age_value" "$kv_overview_fresh" "$kv_overview_stale" "$kv_overview_refreshing"
    cat "$KV_OVERVIEW_FILE"
    printf '}\n'
  else
    KV_PERF_CACHE=warming
    printf '{"ok":false,"state":"warming","refreshing":%s}\n' "$kv_overview_refreshing"
  fi
}

kv_performance_metrics_json() {
  if [ ! -s "$KV_PERF_LOG" ]; then
    printf '{"ok":true,"sample_count":0,"window_sec":300,"actions":[]}\n'
    return 0
  fi
  awk -F '\t' '
    NF >= 4 && $3 ~ /^[A-Za-z0-9_-]+$/ {
      duration = ($2 - $1) * 1000
      if (duration < 0 || duration > 600000) next
      action = $3
      count[action]++
      sum[action] += duration
      if (count[action] == 1 || duration < min[action]) min[action] = duration
      if (duration > max[action]) max[action] = duration
      if ($4 ~ /^hit/) hits[action]++
      if ($4 == "miss") misses[action]++
      total++
    }
    END {
      printf "{\"ok\":true,\"sample_count\":%d,\"window_sec\":300,\"actions\":[", total
      separator = ""
      for (action in count) {
        printf "%s{\"action\":\"%s\",\"count\":%d,\"min_ms\":%.1f,\"avg_ms\":%.1f,\"max_ms\":%.1f,\"cache_hits\":%d,\"cache_misses\":%d}", \
          separator, action, count[action], min[action], sum[action] / count[action], max[action], hits[action] + 0, misses[action] + 0
        separator = ","
      }
      print "]}"
    }
  ' "$KV_PERF_LOG"
}

kv_cache_invalidate() {
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  printf '%s-%s\n' "$(date +%s)" "$$" > "$KV_CACHE_GENERATION.tmp.$$" 2>/dev/null \
    && mv "$KV_CACHE_GENERATION.tmp.$$" "$KV_CACHE_GENERATION" 2>/dev/null || true
  rm -f \
    "$KV_CACHE_DIR/status.json" "$KV_CACHE_DIR/status.json.at" \
    "$KV_CACHE_DIR/dashboard_summary.json" "$KV_CACHE_DIR/dashboard_summary.json.at" "$KV_CACHE_DIR/dashboard_summary.json.generation" \
    "$KV_CACHE_DIR/profiles.json" "$KV_CACHE_DIR/profiles.json.at" \
    "$KV_CACHE_DIR/manual_list.json" "$KV_CACHE_DIR/manual_list.json.at" \
    "$KV_CACHE_DIR/expert_snapshot.json" "$KV_CACHE_DIR/expert_snapshot.json.at" \
    "$KV_CACHE_DIR/alerts.json" "$KV_CACHE_DIR/alerts.json.at" \
    "$KV_CACHE_DIR/metrics_history.json" "$KV_CACHE_DIR/metrics_history.json.at" \
    "$KV_CACHE_DIR/health_history.json" "$KV_CACHE_DIR/health_history.json.at" \
    "$KV_CACHE_DIR/router_info.json" "$KV_CACHE_DIR/router_info.json.at" \
    "$KV_CACHE_DIR/router_targets.json" "$KV_CACHE_DIR/router_targets.json.at" \
    "$KV_CACHE_DIR/external_ip.json" "$KV_CACHE_DIR/external_ip.json.at" \
    2>/dev/null || true
  for kv_dynamic_cache in "$KV_CACHE_DIR"/traffic_plan_*.json "$KV_CACHE_DIR"/traffic_plan_*.json.at "$KV_CACHE_DIR"/traffic_plan_*.json.generation; do
    [ -e "$kv_dynamic_cache" ] || continue
    rm -f "$kv_dynamic_cache" 2>/dev/null || true
  done
  for kv_dynamic_cache in "$KV_CACHE_DIR"/expert_overview_*.json "$KV_CACHE_DIR"/expert_overview_*.json.at "$KV_CACHE_DIR"/expert_overview_*.json.generation; do
    [ -e "$kv_dynamic_cache" ] || continue
    rm -f "$kv_dynamic_cache" 2>/dev/null || true
  done
  kv_overview_invalidate
  if [ "${NATIVE_READ_ENABLED:-0}" = "1" ]; then
    NO_PROXY=127.0.0.1,localhost no_proxy=127.0.0.1,localhost \
      HTTP_PROXY= HTTPS_PROXY= ALL_PROXY= http_proxy= https_proxy= all_proxy= \
      curl -4 -fsS -X POST --connect-timeout 1 -m 5 http://127.0.0.1:18089/v1/invalidate >/dev/null 2>&1 || true
  fi
}

kv_native_read() {
  kv_native_action="$1"
  [ "${NATIVE_READ_ENABLED:-0}" = "1" ] || return 1
  case "$kv_native_action" in
    status|profiles|manual_list|alerts|metrics_history|health_history|router_info|external_ip|dashboard_summary|router_targets) ;;
    *) return 1 ;;
  esac
  kv_native_output="$(NO_PROXY=127.0.0.1,localhost no_proxy=127.0.0.1,localhost \
    HTTP_PROXY= HTTPS_PROXY= ALL_PROXY= http_proxy= https_proxy= all_proxy= \
    curl -4 -fsS --connect-timeout 1 -m 5 \
    "http://127.0.0.1:18089/v1/read?action=$kv_native_action" 2>/dev/null || true)"
  printf '%s' "$kv_native_output" | jq -e . >/dev/null 2>&1 || return 1
  KV_PERF_CACHE=native
  printf '%s\n' "$kv_native_output"
  return 0
}

kv_cache_invalidate_once() {
  kv_completion_kind="$1"
  kv_completion_key="$2"
  case "$kv_completion_kind" in scan|select) ;; *) return 0 ;; esac
  [ -n "$kv_completion_key" ] || return 0
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || return 0
  kv_completion_marker="$KV_CACHE_DIR/$kv_completion_kind.completed"
  kv_completion_previous="$(cat "$kv_completion_marker" 2>/dev/null || true)"
  [ "$kv_completion_previous" != "$kv_completion_key" ] || return 0
  kv_cache_invalidate
  printf '%s\n' "$kv_completion_key" > "$kv_completion_marker.tmp.$$" 2>/dev/null \
    && mv "$kv_completion_marker.tmp.$$" "$kv_completion_marker" 2>/dev/null || true
}

kv_cache_json() {
  kv_cache_key="$1"
  kv_cache_ttl_value="$2"
  kv_cache_command="$3"
  shift 3
  kv_cache_file="$KV_CACHE_DIR/$kv_cache_key.json"
  kv_cache_stamp="$KV_CACHE_DIR/$kv_cache_key.json.at"

  if [ "$kv_cache_ttl_value" -gt 0 ] && [ -s "$kv_cache_file" ]; then
    kv_now="$(date +%s)"
    kv_gen="$(cat "$kv_cache_stamp" 2>/dev/null || echo 0)"
    case "$kv_gen" in ''|*[!0-9]*) kv_gen=0 ;; esac
    kv_age=$((kv_now - kv_gen))
    if [ "$kv_age" -ge 0 ] && [ "$kv_age" -lt "$kv_cache_ttl_value" ]; then
      KV_PERF_CACHE=hit
      cat "$kv_cache_file"
      return 0
    fi
  fi

  KV_PERF_CACHE=miss
  kv_out="$(/opt/bin/keenvless "$kv_cache_command" "$@")"
  printf '%s' "$kv_out"
  if [ "$kv_cache_ttl_value" -gt 0 ] && printf '%s' "$kv_out" | jq -e . >/dev/null 2>&1; then
    mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
    printf '%s' "$kv_out" > "$kv_cache_file.tmp.$$" 2>/dev/null && mv "$kv_cache_file.tmp.$$" "$kv_cache_file" 2>/dev/null || true
    date +%s > "$kv_cache_stamp.tmp.$$" 2>/dev/null && mv "$kv_cache_stamp.tmp.$$" "$kv_cache_stamp" 2>/dev/null || true
  fi
}

kv_cache_file_age() {
  kv_age_file="$1"
  kv_age_stamp="$2"
  KV_CACHE_FILE_AGE=-1
  [ -s "$kv_age_file" ] && [ -s "$kv_age_stamp" ] || return 0
  kv_age_at="$(cat "$kv_age_stamp" 2>/dev/null || echo 0)"
  case "$kv_age_at" in ''|*[!0-9]*) return 0 ;; esac
  kv_age_now="$(date +%s)"
  KV_CACHE_FILE_AGE=$((kv_age_now - kv_age_at))
  [ "$KV_CACHE_FILE_AGE" -ge 0 ] || KV_CACHE_FILE_AGE=0
}

kv_heavy_lock_cleanup() {
  kv_heavy_cleanup_key="$1"
  kv_heavy_cleanup_dir="$KV_CACHE_DIR/$kv_heavy_cleanup_key.refresh.lock"
  [ -d "$kv_heavy_cleanup_dir" ] || return 0
  kv_heavy_cleanup_at="$(cat "$kv_heavy_cleanup_dir/at" 2>/dev/null || true)"
  case "$kv_heavy_cleanup_at" in
    ''|*[!0-9]*) kv_heavy_cleanup_at="$(stat -c %Y "$kv_heavy_cleanup_dir" 2>/dev/null || echo 0)" ;;
  esac
  case "$kv_heavy_cleanup_at" in ''|*[!0-9]*|0) return 0 ;; esac
  kv_heavy_cleanup_age=$(( $(date +%s) - kv_heavy_cleanup_at ))
  if [ "$kv_heavy_cleanup_age" -gt "$KV_HEAVY_CACHE_LOCK_MAX_AGE" ]; then
    rm -f "$kv_heavy_cleanup_dir/owner" "$kv_heavy_cleanup_dir/at" 2>/dev/null || true
    rmdir "$kv_heavy_cleanup_dir" 2>/dev/null || true
  fi
}

kv_heavy_lock_acquire() {
  kv_heavy_acquire_key="$1"
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || return 1
  kv_heavy_lock_cleanup "$kv_heavy_acquire_key"
  KV_HEAVY_LOCK_DIR="$KV_CACHE_DIR/$kv_heavy_acquire_key.refresh.lock"
  KV_HEAVY_LOCK_TOKEN="$$-$(date +%s)"
  if mkdir "$KV_HEAVY_LOCK_DIR" 2>/dev/null; then
    printf '%s\n' "$KV_HEAVY_LOCK_TOKEN" > "$KV_HEAVY_LOCK_DIR/owner" 2>/dev/null || true
    date +%s > "$KV_HEAVY_LOCK_DIR/at" 2>/dev/null || true
    return 0
  fi
  return 1
}

kv_heavy_lock_release() {
  kv_heavy_release_key="$1"
  kv_heavy_release_token="$2"
  kv_heavy_release_dir="$KV_CACHE_DIR/$kv_heavy_release_key.refresh.lock"
  [ "$(cat "$kv_heavy_release_dir/owner" 2>/dev/null || true)" = "$kv_heavy_release_token" ] || return 0
  rm -f "$kv_heavy_release_dir/owner" "$kv_heavy_release_dir/at" 2>/dev/null || true
  rmdir "$kv_heavy_release_dir" 2>/dev/null || true
}

kv_heavy_run_command() {
  kv_heavy_run_name="$1"
  shift
  case "$kv_heavy_run_name" in
    __expert-overview) kv_expert_overview_build "$@" ;;
    *) /opt/bin/keenvless "$kv_heavy_run_name" "$@" ;;
  esac
}

kv_heavy_refresh_locked() {
  kv_heavy_refresh_key="$1"
  kv_heavy_refresh_command="$2"
  kv_heavy_refresh_generation="$3"
  kv_heavy_refresh_token="$4"
  shift 4
  kv_heavy_refresh_file="$KV_CACHE_DIR/$kv_heavy_refresh_key.json"
  kv_heavy_refresh_stamp="$KV_CACHE_DIR/$kv_heavy_refresh_key.json.at"
  kv_heavy_refresh_file_generation="$KV_CACHE_DIR/$kv_heavy_refresh_key.json.generation"
  kv_heavy_refresh_lock="$KV_CACHE_DIR/$kv_heavy_refresh_key.refresh.lock"
  kv_heavy_refresh_out="$KV_CACHE_DIR/.$kv_heavy_refresh_key.refresh.$kv_heavy_refresh_token.json"
  rm -f "$kv_heavy_refresh_out" 2>/dev/null || true

  if kv_heavy_run_command "$kv_heavy_refresh_command" "$@" > "$kv_heavy_refresh_out" 2>/dev/null; then
    :
  fi
  if [ -s "$kv_heavy_refresh_out" ] && jq -e '.ok == true' "$kv_heavy_refresh_out" >/dev/null 2>&1; then
    if [ "$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)" = "$kv_heavy_refresh_generation" ] \
      && [ "$(cat "$kv_heavy_refresh_lock/owner" 2>/dev/null || true)" = "$kv_heavy_refresh_token" ]; then
      if cp "$kv_heavy_refresh_out" "$kv_heavy_refresh_file.tmp.$kv_heavy_refresh_token" 2>/dev/null \
        && mv "$kv_heavy_refresh_file.tmp.$kv_heavy_refresh_token" "$kv_heavy_refresh_file" 2>/dev/null; then
        date +%s > "$kv_heavy_refresh_stamp.tmp.$kv_heavy_refresh_token" 2>/dev/null \
          && mv "$kv_heavy_refresh_stamp.tmp.$kv_heavy_refresh_token" "$kv_heavy_refresh_stamp" 2>/dev/null || true
        printf '%s\n' "${kv_heavy_refresh_generation:-0}" > "$kv_heavy_refresh_file_generation.tmp.$kv_heavy_refresh_token" 2>/dev/null \
          && mv "$kv_heavy_refresh_file_generation.tmp.$kv_heavy_refresh_token" "$kv_heavy_refresh_file_generation" 2>/dev/null || true
      fi
    fi
  fi

  if [ -s "$kv_heavy_refresh_out" ]; then
    cat "$kv_heavy_refresh_out"
  else
    printf '{"ok":false,"error":"heavy read returned no data"}\n'
  fi
  rm -f "$kv_heavy_refresh_out" "$kv_heavy_refresh_file.tmp.$kv_heavy_refresh_token" \
    "$kv_heavy_refresh_stamp.tmp.$kv_heavy_refresh_token" "$kv_heavy_refresh_file_generation.tmp.$kv_heavy_refresh_token" 2>/dev/null || true
  kv_heavy_lock_release "$kv_heavy_refresh_key" "$kv_heavy_refresh_token"
  return 0
}

kv_heavy_start_refresh() {
  kv_heavy_start_key="$1"
  kv_heavy_start_command="$2"
  shift 2
  if kv_heavy_lock_acquire "$kv_heavy_start_key"; then
    kv_heavy_start_token="$KV_HEAVY_LOCK_TOKEN"
    kv_heavy_start_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
    ( kv_heavy_refresh_locked "$kv_heavy_start_key" "$kv_heavy_start_command" \
        "$kv_heavy_start_generation" "$kv_heavy_start_token" "$@" ) >/dev/null 2>&1 &
  fi
  return 0
}

kv_cache_json_swr_with_max_stale() {
  kv_swr_key="$1"
  kv_swr_ttl="$2"
  kv_swr_max_stale="$3"
  kv_swr_command="$4"
  shift 4
  if [ "$kv_swr_ttl" -le 0 ]; then
    KV_PERF_CACHE=miss
    kv_heavy_run_command "$kv_swr_command" "$@"
    return 0
  fi

  kv_swr_file="$KV_CACHE_DIR/$kv_swr_key.json"
  kv_swr_stamp="$KV_CACHE_DIR/$kv_swr_key.json.at"
  kv_swr_file_generation="$KV_CACHE_DIR/$kv_swr_key.json.generation"
  kv_swr_current_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
  kv_swr_cached_generation="$(cat "$kv_swr_file_generation" 2>/dev/null || true)"
  if [ "$kv_swr_cached_generation" = "$kv_swr_current_generation" ]; then
    kv_cache_file_age "$kv_swr_file" "$kv_swr_stamp"
  else
    KV_CACHE_FILE_AGE=-1
  fi
  kv_swr_age="$KV_CACHE_FILE_AGE"
  if [ "$kv_swr_age" -ge 0 ] && [ "$kv_swr_age" -lt "$kv_swr_ttl" ]; then
    KV_PERF_CACHE=hit
    cat "$kv_swr_file"
    return 0
  fi
  if [ "$kv_swr_age" -ge 0 ] && [ "$kv_swr_age" -le "$kv_swr_max_stale" ]; then
    kv_heavy_start_refresh "$kv_swr_key" "$kv_swr_command" "$@"
    KV_PERF_CACHE=hit_stale
    cat "$kv_swr_file"
    return 0
  fi

  if kv_heavy_lock_acquire "$kv_swr_key"; then
    kv_swr_token="$KV_HEAVY_LOCK_TOKEN"
    kv_swr_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
    KV_PERF_CACHE=miss
    kv_heavy_refresh_locked "$kv_swr_key" "$kv_swr_command" "$kv_swr_generation" "$kv_swr_token" "$@"
    return 0
  fi

  kv_swr_waited=0
  while [ "$kv_swr_waited" -lt "$KV_HEAVY_CACHE_WAIT_SEC" ]; do
    sleep 1
    kv_swr_waited=$((kv_swr_waited + 1))
    kv_swr_current_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
    kv_swr_cached_generation="$(cat "$kv_swr_file_generation" 2>/dev/null || true)"
    if [ "$kv_swr_cached_generation" = "$kv_swr_current_generation" ]; then
      kv_cache_file_age "$kv_swr_file" "$kv_swr_stamp"
    else
      KV_CACHE_FILE_AGE=-1
    fi
    if [ "$KV_CACHE_FILE_AGE" -ge 0 ] && [ "$KV_CACHE_FILE_AGE" -le "$kv_swr_max_stale" ]; then
      KV_PERF_CACHE=hit_wait
      cat "$kv_swr_file"
      return 0
    fi
    [ -d "$KV_CACHE_DIR/$kv_swr_key.refresh.lock" ] || break
  done

  if kv_heavy_lock_acquire "$kv_swr_key"; then
    kv_swr_token="$KV_HEAVY_LOCK_TOKEN"
    kv_swr_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
    KV_PERF_CACHE=miss
    kv_heavy_refresh_locked "$kv_swr_key" "$kv_swr_command" "$kv_swr_generation" "$kv_swr_token" "$@"
    return 0
  fi

  # A wedged refresh must never wedge the panel.  Run one uncached read after
  # the bounded wait, but do not publish it without owning the lock.
  KV_PERF_CACHE=miss_bypass
  kv_heavy_run_command "$kv_swr_command" "$@"
}

kv_cache_json_swr() {
  kv_swr_wrapper_key="$1"
  kv_swr_wrapper_ttl="$2"
  kv_swr_wrapper_command="$3"
  shift 3
  kv_cache_json_swr_with_max_stale "$kv_swr_wrapper_key" "$kv_swr_wrapper_ttl" \
    "$KV_HEAVY_CACHE_MAX_STALE" "$kv_swr_wrapper_command" "$@"
}

kv_traffic_plan_cached() {
  kv_traffic_client_value="${1:-$client_ip}"
  kv_traffic_destinations_value="${2:-}"
  kv_traffic_key="$(printf '%s\n%s' "$kv_traffic_client_value" "$kv_traffic_destinations_value" | cksum 2>/dev/null | awk '{print $1}')"
  case "$kv_traffic_key" in ''|*[!0-9]*) kv_traffic_key=default ;; esac
  kv_cache_json_swr "traffic_plan_$kv_traffic_key" "$KV_TRAFFIC_PLAN_CACHE_TTL" traffic-plan \
    "$kv_traffic_client_value" "$kv_traffic_destinations_value"
}

# Overview must never wait up to two network timeouts just to paint the page.
# Serve a generation-valid external-IP cache immediately. On a true miss start
# the existing single-flight refresh and let the aggregate use the last
# health-check IP as a temporary, explicitly marked value.
kv_external_ip_cached_fast() {
  if kv_native_read external_ip; then
    return 0
  fi
  kv_external_fast_file="$KV_CACHE_DIR/external_ip.json"
  kv_external_fast_stamp="$KV_CACHE_DIR/external_ip.json.at"
  kv_external_fast_file_generation="$KV_CACHE_DIR/external_ip.json.generation"
  kv_external_fast_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
  kv_external_fast_cached_generation="$(cat "$kv_external_fast_file_generation" 2>/dev/null || true)"
  if [ "$kv_external_fast_generation" = "$kv_external_fast_cached_generation" ]; then
    kv_cache_file_age "$kv_external_fast_file" "$kv_external_fast_stamp"
  else
    KV_CACHE_FILE_AGE=-1
  fi
  if [ "$KV_CACHE_FILE_AGE" -ge 0 ] && [ "$KV_CACHE_FILE_AGE" -le "$KV_HEAVY_CACHE_MAX_STALE" ]; then
    if [ "$KV_CACHE_FILE_AGE" -ge "$KV_EXTERNAL_IP_CACHE_TTL" ]; then
      kv_heavy_start_refresh external_ip external-ip
      KV_PERF_CACHE=hit_stale
    else
      KV_PERF_CACHE=hit
    fi
    cat "$kv_external_fast_file"
    return 0
  fi
  kv_heavy_start_refresh external_ip external-ip
  KV_PERF_CACHE=warming
  printf '{"ok":true,"warming":true,"source":"health_fallback","proxy_running":false,"direct":null,"proxy":null}\n'
}

kv_home_snapshot() {
  kv_snapshot_dir="$KV_CACHE_DIR/.home-snapshot-$$"
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  if ! mkdir "$kv_snapshot_dir" 2>/dev/null; then
    printf '{"ok":false,"error":"snapshot temporary directory is unavailable"}\n'
    return 0
  fi

  ( kv_cache_json status "$KV_STATUS_CACHE_TTL" status > "$kv_snapshot_dir/status.json" ) &
  kv_status_pid=$!
  ( kv_cache_json profiles "$KV_PROFILES_CACHE_TTL" profiles > "$kv_snapshot_dir/profiles.json" ) &
  kv_profiles_pid=$!
  wait "$kv_status_pid" 2>/dev/null || true
  wait "$kv_profiles_pid" 2>/dev/null || true

  if jq -c -n \
    --slurpfile status "$kv_snapshot_dir/status.json" \
    --slurpfile profiles "$kv_snapshot_dir/profiles.json" \
    '($status[0] // {ok:false,error:"status unavailable"}) as $s |
     ($profiles[0] // {ok:false,error:"profiles unavailable"}) as $p |
     {ok:(($s.ok // false) and ($p.ok // false)),status:$s,profiles:$p}' \
     > "$kv_snapshot_dir/result.json" 2>/dev/null; then
    cat "$kv_snapshot_dir/result.json"
  else
    printf '{"ok":false,"error":"status or profiles returned invalid JSON"}\n'
  fi
  rm -f "$kv_snapshot_dir/status.json" "$kv_snapshot_dir/profiles.json" "$kv_snapshot_dir/result.json" 2>/dev/null || true
  rmdir "$kv_snapshot_dir" 2>/dev/null || true
  return 0
}

# Initial Angular startup used three cloud CGI requests: router_targets, then
# whoami and status.  Return the same payloads in one request.  The two real
# readers stay bounded and run in parallel; whoami is already known by the CGI.
kv_app_bootstrap() {
  kv_bootstrap_dir="$KV_CACHE_DIR/.app-bootstrap-$$"
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  if ! mkdir "$kv_bootstrap_dir" 2>/dev/null; then
    printf '{"ok":false,"error":"bootstrap temporary directory is unavailable"}\n'
    return 0
  fi

  ( kv_native_read status || kv_cache_json status "$KV_STATUS_CACHE_TTL" status ) \
    > "$kv_bootstrap_dir/status.json" &
  kv_bootstrap_status_pid=$!
  ( kv_native_read router_targets || kv_cache_json router_targets "$KV_ROUTER_TARGETS_CACHE_TTL" router-targets ) \
    > "$kv_bootstrap_dir/routers.json" &
  kv_bootstrap_routers_pid=$!
  wait "$kv_bootstrap_status_pid" 2>/dev/null || true
  wait "$kv_bootstrap_routers_pid" 2>/dev/null || true

  if jq -c -n --arg ip "$client_ip" \
    --slurpfile status "$kv_bootstrap_dir/status.json" \
    --slurpfile routers "$kv_bootstrap_dir/routers.json" '
      ($status[0] // {ok:false,error:"status unavailable"}) as $s |
      ($routers[0] // {ok:false,error:"router targets unavailable"}) as $r |
      {
        ok:(($s.ok // false) and ($r.ok // false)),
        whoami:{ok:true,ip:$ip},
        status:$s,
        routerTargets:$r
      }
    ' > "$kv_bootstrap_dir/result.json" 2>/dev/null; then
    cat "$kv_bootstrap_dir/result.json"
  else
    printf '{"ok":false,"error":"bootstrap readers returned invalid JSON"}\n'
  fi
  rm -f "$kv_bootstrap_dir/status.json" "$kv_bootstrap_dir/routers.json" \
    "$kv_bootstrap_dir/result.json" 2>/dev/null || true
  rmdir "$kv_bootstrap_dir" 2>/dev/null || true
}

kv_expert_snapshot() {
  kv_expert_cache_file="$KV_CACHE_DIR/expert_snapshot.json"
  kv_expert_cache_stamp="$KV_CACHE_DIR/expert_snapshot.json.at"
  if [ "$KV_EXPERT_SNAPSHOT_CACHE_TTL" -gt 0 ] && [ -s "$kv_expert_cache_file" ]; then
    kv_expert_now="$(date +%s)"
    kv_expert_at="$(cat "$kv_expert_cache_stamp" 2>/dev/null || echo 0)"
    case "$kv_expert_at" in ''|*[!0-9]*) kv_expert_at=0 ;; esac
    kv_expert_age=$((kv_expert_now - kv_expert_at))
    if [ "$kv_expert_age" -ge 0 ] && [ "$kv_expert_age" -lt "$KV_EXPERT_SNAPSHOT_CACHE_TTL" ]; then
      KV_PERF_CACHE=hit
      cat "$kv_expert_cache_file"
      return 0
    fi
  fi
  KV_PERF_CACHE=miss
  kv_expert_dir="$KV_CACHE_DIR/.expert-snapshot-$$"
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  if ! mkdir "$kv_expert_dir" 2>/dev/null; then
    printf '{"ok":false,"error":"expert snapshot temporary directory is unavailable"}\n'
    return 0
  fi

  ( kv_cache_json status "$KV_STATUS_CACHE_TTL" status > "$kv_expert_dir/status.json" ) &
  kv_expert_status_pid=$!
  ( kv_cache_json profiles "$KV_PROFILES_CACHE_TTL" profiles > "$kv_expert_dir/profiles.json" ) &
  kv_expert_profiles_pid=$!
  ( kv_cache_json manual_list "$KV_MANUAL_LIST_CACHE_TTL" manual-list > "$kv_expert_dir/manual-list.json" ) &
  kv_expert_manual_pid=$!
  wait "$kv_expert_status_pid" 2>/dev/null || true
  wait "$kv_expert_profiles_pid" 2>/dev/null || true
  wait "$kv_expert_manual_pid" 2>/dev/null || true

  if jq -c -n \
    --slurpfile status "$kv_expert_dir/status.json" \
    --slurpfile profiles "$kv_expert_dir/profiles.json" \
    --slurpfile manual "$kv_expert_dir/manual-list.json" \
    '($status[0] // {ok:false,error:"status unavailable"}) as $s |
     ($profiles[0] // {ok:false,error:"profiles unavailable"}) as $p |
     ($manual[0] // []) as $m |
     {ok:(($s.ok // false) and ($p.ok // false) and ($m|type == "array")),status:$s,profiles:$p,manualList:$m}' \
     > "$kv_expert_dir/result.json" 2>/dev/null; then
    if [ "$KV_EXPERT_SNAPSHOT_CACHE_TTL" -gt 0 ]; then
      cp "$kv_expert_dir/result.json" "$kv_expert_cache_file.tmp.$$" 2>/dev/null \
        && mv "$kv_expert_cache_file.tmp.$$" "$kv_expert_cache_file" 2>/dev/null || true
      date +%s > "$kv_expert_cache_stamp.tmp.$$" 2>/dev/null \
        && mv "$kv_expert_cache_stamp.tmp.$$" "$kv_expert_cache_stamp" 2>/dev/null || true
    fi
    cat "$kv_expert_dir/result.json"
  else
    printf '{"ok":false,"error":"status, profiles or manual list returned invalid JSON"}\n'
  fi
  rm -f "$kv_expert_dir/status.json" "$kv_expert_dir/profiles.json" "$kv_expert_dir/manual-list.json" "$kv_expert_dir/result.json" 2>/dev/null || true
  rmdir "$kv_expert_dir" 2>/dev/null || true
  return 0
}

# The expert Overview used to open eight independent CGI requests.  KeenDNS
# serializes/queues those requests on small routers, so browser-side parallelism
# made the real page slower.  This endpoint keeps at most two local readers in
# flight and returns one compact aggregate.  Existing per-action caches and the
# native read service remain the source of data and therefore the fallback path
# stays identical to the individual endpoints.
kv_expert_overview_read() {
  kv_expert_overview_action="$1"
  shift
  case "$kv_expert_overview_action" in
    status)
      kv_native_read status || kv_cache_json status "$KV_STATUS_CACHE_TTL" status
      ;;
    router_info)
      kv_native_read router_info || kv_cache_json router_info "$KV_ROUTER_INFO_CACHE_TTL" router-info
      ;;
    metrics_history)
      kv_native_read metrics_history || kv_cache_json metrics_history "$KV_METRICS_CACHE_TTL" metrics-history
      ;;
    alerts)
      kv_native_read alerts || kv_cache_json alerts "$KV_ALERTS_CACHE_TTL" alerts
      ;;
    external_ip)
      kv_external_ip_cached_fast
      ;;
    traffic_plan)
      kv_traffic_plan_cached "${1:-$client_ip}" "${2:-}"
      ;;
    scan_status)
      /opt/bin/keenvless scan-status
      ;;
    *)
      printf '{"ok":false,"error":"unsupported overview reader"}\n'
      ;;
  esac
}

kv_expert_overview_build() {
  kv_expert_overview_client="${1:-$client_ip}"
  kv_expert_overview_destinations="${2:-}"
  kv_expert_overview_dir="$KV_CACHE_DIR/.expert-overview-$$"
  mkdir -p "$KV_CACHE_DIR" 2>/dev/null || true
  if ! mkdir "$kv_expert_overview_dir" 2>/dev/null; then
    printf '{"ok":false,"error":"expert overview temporary directory is unavailable"}\n'
    return 0
  fi

  # Bounded pairs avoid both CGI queueing and a shell/jq memory spike. The
  # browser has already made status hot, while router/metrics/alerts are native
  # cache actions. Assemble dashboard_summary from those values instead of
  # recomputing all of them in the core command.
  ( kv_expert_overview_read status > "$kv_expert_overview_dir/status.json" ) &
  kv_expert_overview_status_pid=$!
  ( kv_expert_overview_read router_info > "$kv_expert_overview_dir/router.json" ) &
  kv_expert_overview_router_pid=$!
  wait "$kv_expert_overview_status_pid" 2>/dev/null || true
  wait "$kv_expert_overview_router_pid" 2>/dev/null || true

  ( kv_expert_overview_read metrics_history > "$kv_expert_overview_dir/metrics.json" ) &
  kv_expert_overview_metrics_pid=$!
  ( kv_expert_overview_read alerts > "$kv_expert_overview_dir/alerts.json" ) &
  kv_expert_overview_alerts_pid=$!
  wait "$kv_expert_overview_metrics_pid" 2>/dev/null || true
  wait "$kv_expert_overview_alerts_pid" 2>/dev/null || true

  ( kv_expert_overview_read traffic_plan "$kv_expert_overview_client" "$kv_expert_overview_destinations" > "$kv_expert_overview_dir/traffic.json" ) &
  kv_expert_overview_traffic_pid=$!
  ( kv_expert_overview_read external_ip > "$kv_expert_overview_dir/external.json" ) &
  kv_expert_overview_external_pid=$!
  wait "$kv_expert_overview_traffic_pid" 2>/dev/null || true
  wait "$kv_expert_overview_external_pid" 2>/dev/null || true

  kv_expert_overview_read scan_status > "$kv_expert_overview_dir/scan.json" 2>/dev/null \
    || printf '{"ok":false,"error":"scan status unavailable"}\n' > "$kv_expert_overview_dir/scan.json"

  if jq -c -n \
    --slurpfile status "$kv_expert_overview_dir/status.json" \
    --slurpfile router "$kv_expert_overview_dir/router.json" \
    --slurpfile scan "$kv_expert_overview_dir/scan.json" \
    --slurpfile metrics "$kv_expert_overview_dir/metrics.json" \
    --slurpfile alerts "$kv_expert_overview_dir/alerts.json" \
    --slurpfile traffic "$kv_expert_overview_dir/traffic.json" \
    --slurpfile external "$kv_expert_overview_dir/external.json" '
      ($status[0] // {ok:false,error:"status unavailable"}) as $st |
      ($router[0] // {ok:false,error:"router unavailable"}) as $r |
      ($scan[0] // {ok:false,error:"scan unavailable"}) as $s |
      ($metrics[0] // {ok:false,error:"metrics unavailable"}) as $m |
      ($alerts[0] // {ok:false,error:"alerts unavailable"}) as $a |
      ($traffic[0] // {ok:false,error:"traffic plan unavailable"}) as $t |
      ($external[0] // {ok:false,error:"external IP unavailable"}) as $e |
      {
        ok:(($st.ok // false) and ($r.ok // false) and ($m.ok // false) and ($a.ok // false)),
        version:($st.version // ""),
        api_version:($st.api_version // 0),
        running:($st.running // false),
        selected:($st.selected // ""),
        selected_health:($st.selected_health // ""),
        selected_latency_ms:($st.selected_latency_ms // ""),
        route_base_sources:($st.route_base_sources // ""),
        route_sources:($st.route_sources // ""),
        health_last:($st.health_last // {}),
        watchdog_state:($st.watchdog_state // {}),
        mobile_watchdog_state:($st.mobile_watchdog_state // {}),
        router:$r,
        metrics:($m.last // {}),
        alerts:($a.alerts // []),
        alert_summary:($a.summary // {}),
        update_state:"idle",
        update_version:""
      } as $d |
      (if ($e.warming // false) then
        $e + {
          proxy_running:($d.running // false),
          proxy:{
            via:"health",
            ipify:($d.health_last.current_server.ip // ""),
            yandex:"",
            checked_at:($d.health_last.checked_at // 0)
          }
        }
      else $e end) as $external_ip |
      {
        ok:(($d.ok // false) and ($s.ok // false) and ($m.ok // false) and ($t.ok // false) and ($e.ok // false)),
        dashboard:$d,
        scanStatus:$s,
        routerInfo:($d.router // {}),
        statsHistory:$m,
        alerts:{ok:true,alerts:($d.alerts // []),summary:($d.alert_summary // {})},
        trafficPlan:$t,
        externalIp:$external_ip
      }' > "$kv_expert_overview_dir/result.json" 2>/dev/null; then
    cat "$kv_expert_overview_dir/result.json"
  else
    printf '{"ok":false,"error":"expert overview readers returned invalid JSON"}\n'
  fi

  rm -f "$kv_expert_overview_dir/status.json" "$kv_expert_overview_dir/router.json" \
    "$kv_expert_overview_dir/metrics.json" "$kv_expert_overview_dir/alerts.json" \
    "$kv_expert_overview_dir/external.json" "$kv_expert_overview_dir/traffic.json" \
    "$kv_expert_overview_dir/scan.json" "$kv_expert_overview_dir/result.json" 2>/dev/null || true
  rmdir "$kv_expert_overview_dir" 2>/dev/null || true
  return 0
}

# Once a valid aggregate exists, an expired TTL must not turn the next page
# opening into another multi-second cold build.  Return that generation-valid
# snapshot immediately and refresh all secondary data in one single-flight
# background job. The Angular shell has already loaded the current status before
# requesting this endpoint, so reading it again would only add another CGI wait.
# API mutations remove the cache and change its generation, therefore a
# pre-mutation snapshot is never served.
kv_expert_overview_emit_stale() {
  kv_expert_stale_file="$1"
  kv_expert_stale_age="$2"
  jq -c --arg age "$kv_expert_stale_age" \
    '.cache={stale:true,age_sec:($age|tonumber),refreshing:true}' \
    "$kv_expert_stale_file" 2>/dev/null || cat "$kv_expert_stale_file"
}

kv_expert_overview() {
  kv_expert_overview_client="${1:-$client_ip}"
  kv_expert_overview_destinations="${2:-}"
  kv_expert_overview_key="$(printf '%s\n%s' "$kv_expert_overview_client" "$kv_expert_overview_destinations" | cksum 2>/dev/null | awk '{print $1}')"
  case "$kv_expert_overview_key" in ''|*[!0-9]*) kv_expert_overview_key=default ;; esac
  kv_expert_overview_cache_key="expert_overview_$kv_expert_overview_key"
  kv_expert_overview_cache="$KV_CACHE_DIR/$kv_expert_overview_cache_key.json"
  kv_expert_overview_stamp="$KV_CACHE_DIR/$kv_expert_overview_cache_key.json.at"
  kv_expert_overview_cache_generation="$KV_CACHE_DIR/$kv_expert_overview_cache_key.json.generation"
  kv_expert_overview_current_generation="$(cat "$KV_CACHE_GENERATION" 2>/dev/null || echo 0)"
  kv_expert_overview_saved_generation="$(cat "$kv_expert_overview_cache_generation" 2>/dev/null || true)"
  KV_CACHE_FILE_AGE=-1
  if [ "$kv_expert_overview_saved_generation" = "$kv_expert_overview_current_generation" ]; then
    kv_cache_file_age "$kv_expert_overview_cache" "$kv_expert_overview_stamp"
  fi
  kv_expert_overview_age="$KV_CACHE_FILE_AGE"

  if [ "$KV_EXPERT_OVERVIEW_CACHE_TTL" -gt 0 ] \
    && [ "$kv_expert_overview_age" -ge "$KV_EXPERT_OVERVIEW_CACHE_TTL" ] \
    && [ "$kv_expert_overview_age" -le "$KV_EXPERT_OVERVIEW_MAX_STALE" ]; then
    KV_PERF_CACHE=hit_stale
    kv_expert_overview_emit_stale "$kv_expert_overview_cache" "$kv_expert_overview_age"
    kv_heavy_start_refresh "$kv_expert_overview_cache_key" __expert-overview \
      "$kv_expert_overview_client" "$kv_expert_overview_destinations"
    return 0
  fi

  kv_cache_json_swr_with_max_stale "$kv_expert_overview_cache_key" \
    "$KV_EXPERT_OVERVIEW_CACHE_TTL" "$KV_EXPERT_OVERVIEW_MAX_STALE" __expert-overview \
    "$kv_expert_overview_client" "$kv_expert_overview_destinations"
}

case "$action" in
  update|scan|scan_current|scan_async|scan_cancel|select|select_async|select_raw|set_config|set_dest_config|apply_profile|apply_scenario|enable|start|disable|stop|watchdog|mobile_watchdog|dns_monitor|route_on|route_off|route_batch|set_watchdog|set_mobile_watchdog|set_dns_monitor|set_server_group|set_favorites|device_group_save|device_group_delete|device_group_apply|rule_apply|route_preset_save|route_preset_apply|route_preset_delete|client_mode|manual_add|manual_rename|manual_duplicate|manual_delete|import_config|restore_backup|set_web_auth|set_yandex_oauth|set_remote_web|remote_web_apply|remote_web_off|update_apply|update_compact|update_cancel|update_cleanup|storage_cleanup|xray_candidate_install|update_github|install_auto|disable_auto|bootstrap|rules_import|apply_config|router_local_name|router_target_add|router_target_delete)
    kv_cache_invalidate
    ;;
esac

case "$action" in
  status|profiles|manual_list|alerts|metrics_history|health_history|router_info|external_ip|dashboard_summary|router_targets)
    if kv_native_read "$action"; then
      exit 0
    fi
    ;;
esac

if [ "$action" = "home_snapshot" ]; then
  kv_home_snapshot
  exit 0
fi

if [ "$action" = "app_bootstrap" ]; then
  kv_app_bootstrap
  exit 0
fi

if [ "$action" = "expert_snapshot" ]; then
  kv_expert_snapshot
  exit 0
fi

if [ "$action" = "expert_overview" ]; then
  kv_expert_overview "${client:-$client_ip}" "$route_destinations"
  exit 0
fi

if [ "$action" = "performance_metrics" ]; then
  kv_performance_metrics_json
  exit 0
fi

if [ "$action" = "overview_snapshot" ]; then
  kv_overview_snapshot
  exit 0
fi

if [ "$action" = "traffic_plan" ]; then
  kv_traffic_plan_cached "${client:-$client_ip}" "$route_destinations"
  exit 0
fi

kv_cache_key=""
kv_cache_ttl_value=0
kv_cache_command=""
case "$action" in
  status|"") kv_cache_key="status"; kv_cache_ttl_value="$KV_STATUS_CACHE_TTL"; kv_cache_command="status" ;;
  dashboard_summary) kv_cache_key="dashboard_summary"; kv_cache_ttl_value="$KV_DASHBOARD_CACHE_TTL"; kv_cache_command="dashboard-summary" ;;
  profiles) kv_cache_key="profiles"; kv_cache_ttl_value="$KV_PROFILES_CACHE_TTL"; kv_cache_command="profiles" ;;
  manual_list) kv_cache_key="manual_list"; kv_cache_ttl_value="$KV_MANUAL_LIST_CACHE_TTL"; kv_cache_command="manual-list" ;;
  alerts) kv_cache_key="alerts"; kv_cache_ttl_value="$KV_ALERTS_CACHE_TTL"; kv_cache_command="alerts" ;;
  metrics_history) kv_cache_key="metrics_history"; kv_cache_ttl_value="$KV_METRICS_CACHE_TTL"; kv_cache_command="metrics-history" ;;
  health_history) kv_cache_key="health_history"; kv_cache_ttl_value="$KV_HEALTH_HISTORY_CACHE_TTL"; kv_cache_command="health-history" ;;
  router_info) kv_cache_key="router_info"; kv_cache_ttl_value="$KV_ROUTER_INFO_CACHE_TTL"; kv_cache_command="router-info" ;;
  router_targets) kv_cache_key="router_targets"; kv_cache_ttl_value="$KV_ROUTER_TARGETS_CACHE_TTL"; kv_cache_command="router-targets" ;;
  external_ip) kv_cache_key="external_ip"; kv_cache_ttl_value="$KV_EXTERNAL_IP_CACHE_TTL"; kv_cache_command="external-ip" ;;
esac
if [ -n "$kv_cache_key" ]; then
  if [ "$kv_cache_key" = "dashboard_summary" ] || [ "$kv_cache_key" = "external_ip" ]; then
    kv_cache_json_swr "$kv_cache_key" "$kv_cache_ttl_value" "$kv_cache_command"
  else
    kv_cache_json "$kv_cache_key" "$kv_cache_ttl_value" "$kv_cache_command"
  fi
  exit 0
fi

case "$action" in
  status|"") /opt/bin/keenvless status ;;
  version) /opt/bin/keenvless version ;;
  list) /opt/bin/keenvless list ;;
  update) /opt/bin/keenvless update ;;
  scan) /opt/bin/keenvless scan ;;
  scan_current) /opt/bin/keenvless scan "$server" ;;
  scan_async) /opt/bin/keenvless scan-async "$server" ;;
  scan_status)
    kv_scan_status_out="$(/opt/bin/keenvless scan-status)"
    printf '%s\n' "$kv_scan_status_out"
    if printf '%s' "$kv_scan_status_out" | grep -Eq '"running"[[:space:]]*:[[:space:]]*false'; then
      kv_scan_finished="$(printf '%s' "$kv_scan_status_out" | jq -r '.finished_at // 0' 2>/dev/null || echo 0)"
      case "$kv_scan_finished" in ''|*[!0-9]*) kv_scan_finished=0 ;; esac
      [ "$kv_scan_finished" -le 0 ] || kv_cache_invalidate_once scan "$kv_scan_finished"
    fi
    ;;
  scan_cancel) /opt/bin/keenvless scan-cancel ;;
  watchdog) /opt/bin/keenvless watchdog ;;
  watchdog_status) /opt/bin/keenvless watchdog-status ;;
  watchdog_candidates) /opt/bin/keenvless watchdog-candidates ;;
  route_guard) /opt/bin/keenvless route-guard ;;
  set_watchdog) /opt/bin/keenvless set-watchdog "${watchdog_enabled:-0}" "${watchdog_interval_min:-5}" "${watchdog_probe_after_fails:-3}" "${watchdog_switch_after_fails:-6}" "${watchdog_candidate_count:-5}" "${watchdog_switch_cooldown_min:-15}" "${watchdog_fallback_direct:-1}" "${watchdog_restore_original:-1}" "${watchdog_quarantine_min:-30}" "${watchdog_restore_ok_count:-2}" "${watchdog_flap_window_min:-60}" "${watchdog_max_switches_window:-3}" ;;
  mobile_watchdog) /opt/bin/keenvless mobile-watchdog-now ;;
  mobile_watchdog_status) /opt/bin/keenvless mobile-watchdog-status ;;
  set_mobile_watchdog) /opt/bin/keenvless set-mobile-watchdog "${mobile_watchdog_enabled:-1}" "${mobile_watchdog_interval_min:-5}" "${mobile_watchdog_fail_min:-60}" "${mobile_watchdog_usb_off_sec:-10}" "${mobile_watchdog_iface:-auto}" ;;
  dns_monitor) /opt/bin/keenvless dns-monitor ;;
  dns_monitor_status) /opt/bin/keenvless dns-monitor-status ;;
  set_dns_monitor) /opt/bin/keenvless set-dns-monitor "${dns_monitor_enabled:-0}" "${dns_monitor_interval_min:-15}" "$dns_monitor_hosts" ;;
  external_ip) /opt/bin/keenvless external-ip ;;
  manual_list) /opt/bin/keenvless manual-list ;;
  manual_add)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-add "$manual_name" "$manual_link"
    ;;
  manual_rename)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-rename "$manual_id" "$manual_name"
    ;;
  manual_duplicate)
    manual_name="$(printf '%s' "$manual_name_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-duplicate "$manual_id" "$manual_name"
    ;;
  manual_test)
    manual_link="$(printf '%s' "$manual_link_b64" | base64 -d 2>/dev/null)"
    /opt/bin/keenvless manual-test "$manual_link"
    ;;
  provider_debug) /opt/bin/keenvless provider-debug "$server" ;;
  xray_env) /opt/bin/keenvless xray-env ;;
  profiles) /opt/bin/keenvless profiles ;;
  hysteria_diagnostics) /opt/bin/keenvless hysteria-diagnostics ;;
  dependency_doctor|doctor) /opt/bin/keenvless dependency-doctor ;;
  bootstrap_script) /opt/bin/keenvless bootstrap-script ;;
  rescue_status|rescue_wg_status) /opt/bin/keenvless rescue-status ;;
  rescue_wireguard|rescue_wg_plan|rescue_plan) /opt/bin/keenvless rescue-wireguard ;;
  manual_delete) /opt/bin/keenvless manual-delete "$manual_id" ;;
  install_auto) /opt/bin/keenvless install-auto ;;
  disable_auto) /opt/bin/keenvless disable-auto ;;
  clients) /opt/bin/keenvless clients ;;
  backup_config) /opt/bin/keenvless backup-config ;;
  backups) /opt/bin/keenvless backups ;;
  storage_cleanup) /opt/bin/keenvless storage-cleanup ;;
  backup_preview) /opt/bin/keenvless backup-preview "$backup" ;;
  restore_backup) /opt/bin/keenvless restore-backup "$backup" ;;
  favorites) /opt/bin/keenvless favorites ;;
  set_favorites) /opt/bin/keenvless set-favorites "$favorites" ;;
  export_config) /opt/bin/keenvless export-config ;;
  import_config) /opt/bin/keenvless import-config-b64 "$import_b64" ;;
  route_profiles) /opt/bin/keenvless route-profiles ;;
  apply_profile) /opt/bin/keenvless apply-profile "${route_profile:-geo}" ;;
  route_scenarios) /opt/bin/keenvless route-scenarios ;;
  apply_scenario) /opt/bin/keenvless apply-scenario "${route_scenario:-geo_home}" ;;
  client_mode) /opt/bin/keenvless client-mode "${client:-$client_ip}" "${client_mode:-inherit}" ;;
  device_groups) /opt/bin/keenvless device-groups ;;
  device_group_save) /opt/bin/keenvless device-group-save "$group_id" "$group_name" "${group_mode:-inherit}" "$group_members" ;;
  device_group_delete) /opt/bin/keenvless device-group-delete "$group_id" ;;
  device_group_apply) /opt/bin/keenvless device-group-apply "$group_id" ;;
  rule_center) /opt/bin/keenvless rule-center "${client:-$client_ip}" ;;
  rule_preview) /opt/bin/keenvless rule-preview "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$route_destinations" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  rule_apply) /opt/bin/keenvless rule-apply "${client:-$client_ip}" "${client_mode:-inherit}" "${route_scenario:-current}" "$group_id" "${rule_apply_dest:-0}" "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  route_presets) /opt/bin/keenvless route-presets ;;
  route_preset_save) /opt/bin/keenvless route-preset-save "$preset_name" "$preset_id" ;;
  route_preset_apply) /opt/bin/keenvless route-preset-apply "$preset_id" ;;
  route_preset_delete) /opt/bin/keenvless route-preset-delete "$preset_id" ;;
  server_groups) /opt/bin/keenvless server-groups ;;
  set_server_group) /opt/bin/keenvless set-server-group "${server_group:-auto}" ;;
  route_explain) /opt/bin/keenvless route-explain "${client:-$client_ip}" "$destination" ;;
  dns_check) /opt/bin/keenvless dns-check "$destination" ;;
  connections) /opt/bin/keenvless connections ;;
  events) /opt/bin/keenvless events "${event_kind:-all}" ;;
  update_history) /opt/bin/keenvless update-history ;;
  alerts) /opt/bin/keenvless alerts ;;
  dashboard_summary) /opt/bin/keenvless dashboard-summary ;;
  route_batch) /opt/bin/keenvless route-batch "${client:-$client_ip}" "$route_destinations" ;;
  traffic_plan) /opt/bin/keenvless traffic-plan "${client:-$client_ip}" "$route_destinations" ;;
  support_report) /opt/bin/keenvless support-report ;;
  rules_export) /opt/bin/keenvless rules-export ;;
  rules_import) /opt/bin/keenvless rules-import-b64 "$rules_b64" ;;
  logs) /opt/bin/keenvless logs ;;
  check_current) /opt/bin/keenvless check-current ;;
  whoami) printf '{"ok":true,"ip":"%s","remote_addr":"%s","auth":"%s","phone":"%s"}\n' "$client_ip" "$REMOTE_ADDR" "$auth_method" "${KVX_AUTH_PHONE:-}" ;;
  diagnostics) /opt/bin/keenvless diagnostics ;;
  health_report) /opt/bin/keenvless health-report "$health_client" ;;
  health_history) /opt/bin/keenvless health-history ;;
  system_monitor) /opt/bin/keenvless system-monitor ;;
  system_monitor_sample) /opt/bin/keenvless system-monitor-sample ;;
  metrics_history) /opt/bin/keenvless metrics-history ;;
  self_test) /opt/bin/keenvless self-test ;;
  router_info) /opt/bin/keenvless router-info ;;
  update_status) /opt/bin/keenvless update-status ;;
  update_compact) /opt/bin/keenvless update-compact ;;
  update_begin) /opt/bin/keenvless update-begin "$update_version" "$update_size" "$update_sha256" ;;
  update_chunk) /opt/bin/keenvless update-chunk "$update_id" "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  update_apply) /opt/bin/keenvless update-apply "$update_id" ;;
  xray_candidate_begin) /opt/bin/keenvless xray-candidate-begin "$update_size" "$update_sha256" ;;
  xray_candidate_chunk) /opt/bin/keenvless xray-candidate-chunk "$update_chunk_b64" "$update_offset" "$update_chunk_sha256" ;;
  xray_candidate_status) /opt/bin/keenvless xray-candidate-status ;;
  xray_candidate_check) /opt/bin/keenvless xray-candidate-check ;;
  xray_candidate_fetch) /opt/bin/keenvless xray-candidate-fetch "$xray_url" "$update_sha256" ;;
  xray_candidate_provider_debug) /opt/bin/keenvless xray-candidate-provider-debug "$server" ;;
  xray_candidate_install) /opt/bin/keenvless xray-candidate-install "$update_sha256" ;;
  update_cancel) /opt/bin/keenvless update-cancel "$update_id" ;;
  update_cleanup) /opt/bin/keenvless update-cleanup "$update_id" ;;
  update_export) /opt/bin/keenvless update-export ;;
  github_check) /opt/bin/keenvless github-check "$github_repo" ;;
  update_github)
    id="github-$(date +%s)-$$"
    jq -n --arg id "$id" --arg tag "$github_tag" --arg repo "$github_repo" '{ok:true,state:"github_queued",id:$id,tag:$tag,repo:$repo}' > /opt/var/lib/keenvless/update-status.json 2>/dev/null || true
    ( /opt/bin/keenvless update-github "$github_tag" "$github_repo" "$github_token" >> /opt/var/log/keenvless-update.log 2>&1 ) &
    printf '{"ok":true,"state":"github_started","id":"%s"}\n' "$id"
    ;;
  github_probe) /opt/bin/keenvless github-probe "$github_tag" "$github_repo" ;;
  github_asset_probe) /opt/bin/keenvless github-asset-probe "$github_tag" "$github_repo" ;;
  router_targets) /opt/bin/keenvless router-targets ;;
  router_local_name) /opt/bin/keenvless router-local-name "$router_local_name" ;;
  router_target_add) /opt/bin/keenvless router-target-add "$router_name" "$router_url" "$router_token" "$router_resolve_ip" ;;
  router_target_delete) /opt/bin/keenvless router-target-delete "$router_id" ;;
  router_target_test) /opt/bin/keenvless router-target-test "${router_id:-local}" ;;
  router_compare) /opt/bin/keenvless router-compare ;;
  router_sync_rules) /opt/bin/keenvless router-sync-rules "${sync_from:-$router_id}" "${sync_to:-$update_id}" ;;
  router_backup_all) /opt/bin/keenvless router-backup-all ;;
  native_backend_status) /opt/bin/keenvless native-backend-status ;;
  native_backend_canary_start) /opt/bin/keenvless native-backend-canary-start ;;
  native_backend_stop) /opt/bin/keenvless native-backend-stop ;;
  native_backend_probe) /opt/bin/keenvless native-backend-probe ;;
  native_backend_benchmark) /opt/bin/keenvless native-backend-benchmark ;;
  native_backend_enable) /opt/bin/keenvless native-backend-enable ;;
  native_backend_disable) /opt/bin/keenvless native-backend-disable ;;
  native_backend_guard) /opt/bin/keenvless native-backend-guard ;;
  bootstrap) /opt/bin/keenvless bootstrap ;;
  select) /opt/bin/keenvless select "$server" ;;
  select_async) /opt/bin/keenvless select-async "$server" "$request_id" ;;
  select_status)
    kv_select_status_out="$(/opt/bin/keenvless select-status "$select_id" "$request_id")"
    printf '%s\n' "$kv_select_status_out"
    if printf '%s' "$kv_select_status_out" | grep -Eq '"done"[[:space:]]*:[[:space:]]*true'; then
      kv_select_finished="$(printf '%s' "$kv_select_status_out" | jq -r '.id // ""' 2>/dev/null || true)"
      [ -z "$kv_select_finished" ] || kv_cache_invalidate_once select "$kv_select_finished"
    fi
    ;;
  select_raw) /opt/bin/keenvless select-raw "$server" ;;
  enable|start) /opt/bin/keenvless enable ;;
  disable|stop) /opt/bin/keenvless disable ;;
  route_on) /opt/bin/keenvless route-on "${client:-$client_ip}" ;;
  route_off) /opt/bin/keenvless route-off "$client" ;;
  config) /opt/bin/keenvless config ;;
  set_config) /opt/bin/keenvless set-config "${sources:-$client_ip}" "${ports:-80,443}" "${block_udp443:-1}" "$proxy_sources" "$direct_sources" ;;
  set_dest_config) /opt/bin/keenvless set-dest-config "$proxy_domains" "$proxy_ips" "$direct_domains" "$direct_ips" ;;
  set_web_auth) /opt/bin/keenvless set-web-auth "${token_required:-0}" "$web_token" ;;
  set_yandex_oauth) /opt/bin/keenvless set-yandex-oauth "${yandex_oauth_enabled:-0}" "$yandex_client_id" "$yandex_client_secret" "$yandex_allowed_phones" "$yandex_session_ttl_sec" "$yandex_redirect_uri" ;;
  set_remote_web) /opt/bin/keenvless set-remote-web "${remote_web_enabled:-0}" "${remote_web_port:-8088}" "$remote_web_sources" ;;
  apply_config) /opt/bin/keenvless route-on "${sources:-$client_ip}" ;;
  *) printf '{"ok":false,"error":"unknown action"}\n' ;;
esac
