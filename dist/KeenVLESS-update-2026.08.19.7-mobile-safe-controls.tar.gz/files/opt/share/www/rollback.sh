#!/bin/sh
set -eu

PATH=/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin
CONF=/opt/etc/keenvless/keenvless.conf
ARCHIVE=/opt/share/www/.keenvless-rollback/previous-release.tar.gz
ARCHIVE_SHA=/opt/share/www/.keenvless-rollback/previous-release.tar.gz.sha256
EXPECTED_VERSION=2026.08.18.4-vpn-correctness
DATA_DIR=/opt/var/lib/keenvless
APP_BACKUPS_DIR="$DATA_DIR/app-backups"
NATIVE_BACKEND_BIN="$DATA_DIR/native-backend/keenvlessd"
NATIVE_BACKEND_PID_FILE=/opt/var/run/keenvlessd.pid
NATIVE_BACKEND_GUARD_PID_FILE=/opt/var/run/keenvlessd-guard.pid
OPT_ROOT=/opt

request_params="${QUERY_STRING:-}"
if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
  content_length="${CONTENT_LENGTH:-0}"
  case "$content_length" in ''|*[!0-9]*) content_length=0 ;; esac
  post_body="$(head -c "$content_length" 2>/dev/null || true)"
  if [ -n "$post_body" ]; then
    [ -n "$request_params" ] && request_params="$request_params&$post_body" || request_params="$post_body"
  fi
fi

param() {
  printf '%s' "$request_params" | awk -v RS='&' -F= -v k="$1" '$1 == k {print substr($0, length(k) + 2); exit}'
}

json_error() {
  rollback_message="$1"
  printf '{"ok":false,"error":%s}\n' "$(printf '%s' "$rollback_message" | jq -Rs . 2>/dev/null || printf '"rollback error"')"
  exit 1
}

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

[ -r "$CONF" ] || json_error "configuration not found"
. "$CONF"
[ -r /opt/share/www/oauth-yandex-lib.sh ] && . /opt/share/www/oauth-yandex-lib.sh
request_token="$(param token)"
rollback_auth_ok=0
if [ -n "${TOKEN:-}" ] && [ "$request_token" = "$TOKEN" ]; then
  rollback_auth_ok=1
elif command -v kvx_session_valid >/dev/null 2>&1 && kvx_session_valid; then
  rollback_auth_ok=1
fi
[ "$rollback_auth_ok" = "1" ] || json_error "unauthorized"

rollback_work="/tmp/keenvless-release-rollback-$$"
rollback_stage="/opt/share/.keenvless-rollback-www-$$"
rollback_old="/opt/share/.keenvless-before-rollback-$$"
rollback_candidate=""
rollback_candidate_version=""
rollback_candidate_sha=""
rollback_current_version=""
rollback_saved_current=""

cleanup() {
  rm -rf "$rollback_work" "$rollback_stage" 2>/dev/null || true
}
trap cleanup 0 1 2 15

disable_native_backend_config() {
  if [ -x /opt/bin/keenvless ]; then
    /opt/bin/keenvless native-backend-disable >/dev/null 2>&1 || true
  fi
  if grep -Eq "^NATIVE_READ_ENABLED=('0'|\"0\"|0)$" "$CONF" 2>/dev/null; then
    return 0
  fi
  rollback_native_conf_tmp="$CONF.native-off.$$"
  awk '
    BEGIN { found=0 }
    /^NATIVE_READ_ENABLED=/ { print "NATIVE_READ_ENABLED=0"; found=1; next }
    { print }
    END { if (!found) print "NATIVE_READ_ENABLED=0" }
  ' "$CONF" > "$rollback_native_conf_tmp" 2>/dev/null || {
    rm -f "$rollback_native_conf_tmp" 2>/dev/null || true
    return 1
  }
  chmod 0600 "$rollback_native_conf_tmp" 2>/dev/null || true
  mv "$rollback_native_conf_tmp" "$CONF" 2>/dev/null || {
    rm -f "$rollback_native_conf_tmp" 2>/dev/null || true
    return 1
  }
  grep -Eq "^NATIVE_READ_ENABLED=('0'|\"0\"|0)$" "$CONF" 2>/dev/null
}

stop_native_backend() {
  disable_native_backend_config || json_error "cannot disable native backend before rollback"
  for rollback_native_file in "$NATIVE_BACKEND_GUARD_PID_FILE" "$NATIVE_BACKEND_PID_FILE"; do
    [ -s "$rollback_native_file" ] || continue
    read -r rollback_native_pid rollback_native_ticks < "$rollback_native_file" 2>/dev/null || continue
    case "$rollback_native_pid" in ''|*[!0-9]*) continue ;; esac
    case "$rollback_native_ticks" in ''|*[!0-9]*) continue ;; esac
    [ -d "/proc/$rollback_native_pid" ] || continue
    rollback_native_actual_ticks="$(awk '{print $22}' "/proc/$rollback_native_pid/stat" 2>/dev/null || true)"
    [ "$rollback_native_actual_ticks" = "$rollback_native_ticks" ] || continue
    if [ "$rollback_native_file" = "$NATIVE_BACKEND_PID_FILE" ]; then
      rollback_native_cmdline="$(tr '\000' ' ' < "/proc/$rollback_native_pid/cmdline" 2>/dev/null || true)"
      printf '%s' "$rollback_native_cmdline" | grep -F "$NATIVE_BACKEND_BIN" >/dev/null 2>&1 || continue
    fi
    kill "$rollback_native_pid" 2>/dev/null || true
  done
  rm -f "$NATIVE_BACKEND_PID_FILE" "$NATIVE_BACKEND_GUARD_PID_FILE" /opt/var/run/keenvlessd.mode
}

prepare_archive() {
  [ -s "$ARCHIVE" ] || json_error "rollback archive not found"
  [ -s "$ARCHIVE_SHA" ] || json_error "rollback checksum not found"
  rollback_expected_sha="$(cat "$ARCHIVE_SHA" 2>/dev/null || true)"
  rollback_actual_sha="$(sha256sum "$ARCHIVE" 2>/dev/null | awk '{print $1}')"
  [ -n "$rollback_expected_sha" ] && [ "$rollback_actual_sha" = "$rollback_expected_sha" ] \
    || json_error "rollback archive checksum mismatch"
  rm -rf "$rollback_work"
  mkdir -p "$rollback_work" || json_error "cannot prepare rollback directory"
  tar -xzf "$ARCHIVE" -C "$rollback_work" >/dev/null 2>&1 || json_error "cannot unpack rollback archive"
  jq -e --arg version "$EXPECTED_VERSION" '.app == "KeenVLESS" and .package_version == 1 and .version == $version' \
    "$rollback_work/manifest.json" >/dev/null 2>&1 || json_error "unexpected rollback package"
  [ -s "$rollback_work/files/opt/bin/keenvless" ] || json_error "rollback core is missing"
  [ -s "$rollback_work/files/opt/share/www/api.sh" ] || json_error "rollback API is missing"
}

backup_archive_valid() {
  rollback_backup_archive="$1"
  case "$rollback_backup_archive" in
    "$APP_BACKUPS_DIR"/app-*.tar.gz) ;;
    *) return 1 ;;
  esac
  [ -s "$rollback_backup_archive" ] || return 1
  [ -s "$rollback_backup_archive.sha256" ] || return 1
  rollback_backup_expected_sha="$(cat "$rollback_backup_archive.sha256" 2>/dev/null || true)"
  rollback_backup_actual_sha="$(sha256sum "$rollback_backup_archive" 2>/dev/null | awk '{print $1}')"
  case "$rollback_backup_expected_sha" in
    [0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]*) ;;
    *) return 1 ;;
  esac
  [ "$rollback_backup_actual_sha" = "$rollback_backup_expected_sha" ] || return 1
  tar -tzf "$rollback_backup_archive" > "$rollback_work/archive-list.txt" 2>/dev/null || return 1
  [ -s "$rollback_work/archive-list.txt" ] || return 1
  while IFS= read -r rollback_backup_entry; do
    case "$rollback_backup_entry" in
      ''|/*|*\\*|../*|*/../*|*/..) return 1 ;;
      application-backup.json|opt|opt/|opt/bin|opt/bin/|opt/bin/keenvless|opt/share|opt/share/|opt/share/www|opt/share/www/*|opt/etc|opt/etc/|opt/etc/init.d|opt/etc/init.d/|opt/etc/init.d/S99keenvless|opt/etc/lighttpd|opt/etc/lighttpd/|opt/etc/lighttpd/conf.d|opt/etc/lighttpd/conf.d/|opt/etc/lighttpd/conf.d/99-keenvless.conf) ;;
      *) return 1 ;;
    esac
  done < "$rollback_work/archive-list.txt"
}

backup_version_from_tree() {
  rollback_backup_tree="$1"
  rollback_backup_version=""
  if [ -s "$rollback_backup_tree/application-backup.json" ]; then
    rollback_backup_version="$(jq -r '.version // empty' "$rollback_backup_tree/application-backup.json" 2>/dev/null || true)"
  fi
  if [ -z "$rollback_backup_version" ] && [ -s "$rollback_backup_tree/opt/bin/keenvless" ]; then
    rollback_backup_version="$(sed -n 's/^APP_VERSION=${APP_VERSION:-\([^}]*\)}$/\1/p' "$rollback_backup_tree/opt/bin/keenvless" | head -n 1)"
  fi
  case "$rollback_backup_version" in
    ''|*[!A-Za-z0-9._-]*) return 1 ;;
  esac
  printf '%s\n' "$rollback_backup_version"
}

find_previous_backup() {
  rollback_current_json="$("$OPT_ROOT/bin/keenvless" version 2>/dev/null || true)"
  rollback_current_version="$(printf '%s' "$rollback_current_json" | jq -r '.version // empty' 2>/dev/null || true)"
  case "$rollback_current_version" in
    ''|*[!A-Za-z0-9._-]*) return 1 ;;
  esac
  rm -rf "$rollback_work"
  mkdir -p "$rollback_work" || return 1
  rollback_candidate=""
  rollback_candidate_version=""
  rollback_candidate_sha=""
  rollback_backup_list="$rollback_work/backups.txt"
  rollback_backup_sorted="$rollback_work/backups-sorted.txt"
  : > "$rollback_backup_list"
  for rollback_backup_item in "$APP_BACKUPS_DIR"/app-*.tar.gz; do
    [ -e "$rollback_backup_item" ] || continue
    printf '%s\n' "$rollback_backup_item" >> "$rollback_backup_list"
  done
  [ -s "$rollback_backup_list" ] || return 1
  sort -r "$rollback_backup_list" > "$rollback_backup_sorted" || return 1
  while IFS= read -r rollback_backup_item; do
    rm -rf "$rollback_work/candidate"
    mkdir -p "$rollback_work/candidate" || return 1
    backup_archive_valid "$rollback_backup_item" || continue
    tar -xzf "$rollback_backup_item" -C "$rollback_work/candidate" >/dev/null 2>&1 || continue
    [ -s "$rollback_work/candidate/opt/bin/keenvless" ] || continue
    [ -s "$rollback_work/candidate/opt/share/www/api.sh" ] || continue
    [ -s "$rollback_work/candidate/opt/share/www/index.html" ] || continue
    [ -s "$rollback_work/candidate/opt/etc/init.d/S99keenvless" ] || continue
    [ -s "$rollback_work/candidate/opt/etc/lighttpd/conf.d/99-keenvless.conf" ] || continue
    rollback_backup_version="$(backup_version_from_tree "$rollback_work/candidate" 2>/dev/null || true)"
    [ -n "$rollback_backup_version" ] || continue
    [ "$rollback_backup_version" != "$rollback_current_version" ] || continue
    rollback_candidate="$rollback_backup_item"
    rollback_candidate_version="$rollback_backup_version"
    rollback_candidate_sha="$(sha256sum "$rollback_backup_item" 2>/dev/null | awk '{print $1}')"
    return 0
  done < "$rollback_backup_sorted"
  rm -rf "$rollback_work/candidate"
  return 1
}

save_current_application_backup() {
  rollback_preserve_backup="$1"
  rollback_saved_current=""
  rollback_current_check="$rollback_work/current-backup-check"
  while IFS= read -r rollback_current_item; do
    rm -rf "$rollback_current_check"
    mkdir -p "$rollback_current_check" || return 1
    backup_archive_valid "$rollback_current_item" || continue
    tar -xzf "$rollback_current_item" -C "$rollback_current_check" >/dev/null 2>&1 || continue
    rollback_current_item_version="$(backup_version_from_tree "$rollback_current_check" 2>/dev/null || true)"
    if [ "$rollback_current_item_version" = "$rollback_current_version" ]; then
      rollback_saved_current="$rollback_current_item"
      break
    fi
  done < "$rollback_work/backups-sorted.txt"
  rm -rf "$rollback_current_check"

  if [ -z "$rollback_saved_current" ]; then
    rollback_saved_current="$("$OPT_ROOT/bin/keenvless" application-backup-create 2>/dev/null || true)"
    backup_archive_valid "$rollback_saved_current" || return 1
    rm -rf "$rollback_current_check"
    mkdir -p "$rollback_current_check" || return 1
    tar -xzf "$rollback_saved_current" -C "$rollback_current_check" >/dev/null 2>&1 || return 1
    rollback_current_item_version="$(backup_version_from_tree "$rollback_current_check" 2>/dev/null || true)"
    rm -rf "$rollback_current_check"
    [ "$rollback_current_item_version" = "$rollback_current_version" ] || return 1
  fi

  for rollback_prune_item in "$APP_BACKUPS_DIR"/app-*.tar.gz; do
    [ -e "$rollback_prune_item" ] || continue
    [ "$rollback_prune_item" = "$rollback_preserve_backup" ] && continue
    [ "$rollback_prune_item" = "$rollback_saved_current" ] && continue
    rm -f "$rollback_prune_item" "$rollback_prune_item.sha256"
  done
  printf '%s\n' "$rollback_saved_current"
}

copy_atomic() {
  rollback_source="$1"
  rollback_target="$2"
  rollback_mode="$3"
  [ -s "$rollback_source" ] || return 1
  cp "$rollback_source" "$rollback_target.rollback-new" || return 1
  chmod "$rollback_mode" "$rollback_target.rollback-new" 2>/dev/null || true
  mv "$rollback_target.rollback-new" "$rollback_target" || return 1
}

install_previous_www() {
  rollback_www_source="${1:-$rollback_work/files/opt/share/www}"
  [ -s "$rollback_www_source/index.html" ] && [ -s "$rollback_www_source/api.sh" ] || return 1
  rm -rf "$rollback_stage" "$rollback_old"
  mkdir -p "$rollback_stage" || return 1
  cp -R "$rollback_www_source/." "$rollback_stage/" || return 1
  cp "$0" "$rollback_stage/rollback.sh" 2>/dev/null || true
  [ -d /opt/share/www/.keenvless-rollback ] \
    && cp -R /opt/share/www/.keenvless-rollback "$rollback_stage/.keenvless-rollback" 2>/dev/null || true
  chmod 0755 "$rollback_stage/api.sh" "$rollback_stage/oauth-yandex-start.sh" "$rollback_stage/oauth-yandex-callback.sh" "$rollback_stage/rollback.sh" 2>/dev/null || true
  mv /opt/share/www "$rollback_old" || return 1
  if mv "$rollback_stage" /opt/share/www; then
    return 0
  fi
  mv "$rollback_old" /opt/share/www 2>/dev/null || true
  return 1
}

restore_previous_www() {
  [ -d "$rollback_old" ] || return 0
  rollback_failed="/opt/share/.keenvless-failed-rollback-$$"
  rm -rf "$rollback_failed"
  mv /opt/share/www "$rollback_failed" 2>/dev/null || true
  mv "$rollback_old" /opt/share/www 2>/dev/null || true
  rm -rf "$rollback_failed"
}

backup_current_application() {
  rollback_current="$rollback_work/current"
  mkdir -p "$rollback_current" || return 1
  cp /opt/bin/keenvless "$rollback_current/keenvless" \
    && cp /opt/etc/init.d/S99keenvless "$rollback_current/S99keenvless" \
    && cp /opt/etc/lighttpd/conf.d/99-keenvless.conf "$rollback_current/99-keenvless.conf"
}

restore_current_application() {
  restore_previous_www
  copy_atomic "$rollback_work/current/S99keenvless" /opt/etc/init.d/S99keenvless 0755 2>/dev/null || true
  copy_atomic "$rollback_work/current/99-keenvless.conf" /opt/etc/lighttpd/conf.d/99-keenvless.conf 0644 2>/dev/null || true
  copy_atomic "$rollback_work/current/keenvless" /opt/bin/keenvless 0755 2>/dev/null || true
}

validate_installed_application() {
  validate_application_version "$EXPECTED_VERSION"
}

validate_application_version() {
  rollback_validate_version="$1"
  rollback_response="$rollback_work/validate-response.txt"
  rollback_body="$rollback_work/validate-body.json"
  /opt/bin/keenvless version 2>/dev/null \
    | jq -e --arg version "$rollback_validate_version" '.ok == true and .version == $version' >/dev/null 2>&1 \
    || return 1
  /opt/bin/keenvless self-test 2>/dev/null | jq -e '.ok == true' >/dev/null 2>&1 || return 1
  REQUEST_METHOD=GET QUERY_STRING="action=status&token=$request_token" CONTENT_LENGTH=0 REMOTE_ADDR=127.0.0.1 \
    /bin/sh /opt/share/www/api.sh > "$rollback_response" 2>/dev/null || return 1
  tr -d '\r' < "$rollback_response" | awk 'body {print} /^$/ {body=1}' > "$rollback_body"
  jq -e --arg version "$rollback_validate_version" '.ok == true and .version == $version' \
    "$rollback_body" >/dev/null 2>&1
}

action="$(param action)"
[ -n "$action" ] || action=verify
case "$action" in
  verify)
    prepare_archive
    jq -n --arg version "$EXPECTED_VERSION" --arg sha256 "$rollback_actual_sha" \
      '{ok:true,state:"ready",rollback_version:$version,sha256:$sha256,changes_vpn:false}'
    ;;
  rollback)
    [ "${REQUEST_METHOD:-GET}" = "POST" ] || json_error "rollback requires POST"
    [ "$(param confirm)" = "rollback" ] || json_error "rollback confirmation missing"
    prepare_archive
    backup_current_application || json_error "cannot preserve current application before rollback"
    stop_native_backend
    install_previous_www || json_error "cannot install previous web files"
    if ! copy_atomic "$rollback_work/files/opt/etc/init.d/S99keenvless" /opt/etc/init.d/S99keenvless 0755 \
      || ! copy_atomic "$rollback_work/files/opt/etc/lighttpd/conf.d/99-keenvless.conf" /opt/etc/lighttpd/conf.d/99-keenvless.conf 0644 \
      || ! copy_atomic "$rollback_work/files/opt/bin/keenvless" /opt/bin/keenvless 0755; then
      restore_current_application
      json_error "cannot restore previous application files"
    fi
    if ! validate_installed_application; then
      restore_current_application
      json_error "restored application did not pass validation"
    fi
    rm -rf "$rollback_old"
    mkdir -p "$DATA_DIR"
    jq -n --arg version "$EXPECTED_VERSION" '{ok:true,state:"rolled_back",version:$version,rolled_back_at:(now|floor),changes_vpn:false}' \
      > "$DATA_DIR/release-rollback-last.json" 2>/dev/null || true
    jq -n --arg version "$EXPECTED_VERSION" '{ok:true,state:"rolled_back",version:$version,changes_vpn:false}'
    ;;
  verify_previous)
    find_previous_backup || json_error "previous application backup is not available"
    jq -n \
      --arg current_version "$rollback_current_version" \
      --arg previous_version "$rollback_candidate_version" \
      --arg sha256 "$rollback_candidate_sha" \
      '{ok:true,state:"ready",current_version:$current_version,previous_version:$previous_version,sha256:$sha256,reversible:true,changes_vpn:false}'
    ;;
  rollback_previous)
    [ "${REQUEST_METHOD:-GET}" = "POST" ] || json_error "previous rollback requires POST"
    [ "$(param confirm)" = "rollback_previous" ] || json_error "previous rollback confirmation missing"
    find_previous_backup || json_error "previous application backup is not available"
    rollback_from_version="$rollback_current_version"
    rollback_to_version="$rollback_candidate_version"
    rollback_from_backup="$(save_current_application_backup "$rollback_candidate" 2>/dev/null || true)"
    [ -n "$rollback_from_backup" ] || json_error "cannot preserve current application before previous rollback"
    backup_current_application || json_error "cannot prepare immediate recovery before previous rollback"
    stop_native_backend
    install_previous_www "$rollback_work/candidate/opt/share/www" || json_error "cannot install previous application web files"
    if ! copy_atomic "$rollback_work/candidate/opt/etc/init.d/S99keenvless" /opt/etc/init.d/S99keenvless 0755 \
      || ! copy_atomic "$rollback_work/candidate/opt/etc/lighttpd/conf.d/99-keenvless.conf" /opt/etc/lighttpd/conf.d/99-keenvless.conf 0644 \
      || ! copy_atomic "$rollback_work/candidate/opt/bin/keenvless" /opt/bin/keenvless 0755; then
      restore_current_application
      json_error "cannot restore previous application files"
    fi
    if ! validate_application_version "$rollback_to_version"; then
      restore_current_application
      json_error "restored previous application did not pass validation"
    fi
    rm -rf "$rollback_old"
    mkdir -p "$DATA_DIR"
    jq -n \
      --arg from_version "$rollback_from_version" \
      --arg version "$rollback_to_version" \
      --arg saved_current "$rollback_from_backup" \
      '{ok:true,state:"rolled_back_previous",from_version:$from_version,version:$version,saved_current:$saved_current,rolled_back_at:(now|floor),reversible:true,changes_vpn:false}' \
      > "$DATA_DIR/release-rollback-last.json" 2>/dev/null || true
    jq -n \
      --arg from_version "$rollback_from_version" \
      --arg version "$rollback_to_version" \
      --arg saved_current "$rollback_from_backup" \
      '{ok:true,state:"rolled_back_previous",from_version:$from_version,version:$version,saved_current:$saved_current,reversible:true,changes_vpn:false}'
    ;;
  *)
    json_error "unknown rollback action"
    ;;
esac
