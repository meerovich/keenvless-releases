#!/bin/sh

umask 077

KVX_CONF=${CONF:-/opt/etc/keenvless/keenvless.conf}
KVX_DATA_DIR=${DATA_DIR:-/opt/var/lib/keenvless}
KVX_OAUTH_DIR=${KVX_OAUTH_DIR:-$KVX_DATA_DIR/oauth-yandex}
KVX_OAUTH_STATE_DIR="$KVX_OAUTH_DIR/states"
KVX_OAUTH_SESSION_DIR="$KVX_OAUTH_DIR/sessions"
KVX_OAUTH_COOKIE=${KVX_OAUTH_COOKIE:-kvx_session}

YANDEX_OAUTH_ENABLED=${YANDEX_OAUTH_ENABLED:-0}
YANDEX_CLIENT_ID=${YANDEX_CLIENT_ID:-}
YANDEX_CLIENT_SECRET=${YANDEX_CLIENT_SECRET:-}
YANDEX_ALLOWED_PHONES=${YANDEX_ALLOWED_PHONES:-}
YANDEX_SESSION_TTL_SEC=${YANDEX_SESSION_TTL_SEC:-2592000}

kvx_csrf_valid() {
  [ "${HTTP_X_KEENVLESS_REQUEST:-}" = "1" ] || return 1
  kvx_csrf_host="${HTTP_HOST:-}"
  kvx_csrf_origin="${HTTP_ORIGIN:-}"
  [ -n "$kvx_csrf_host" ] || return 1
  case "$kvx_csrf_origin" in
    "https://$kvx_csrf_host"|"http://$kvx_csrf_host"|"") return 0 ;;
    *) return 1 ;;
  esac
}
YANDEX_SESSION_SECRET=${YANDEX_SESSION_SECRET:-}
YANDEX_AUTH_ENDPOINT=${YANDEX_AUTH_ENDPOINT:-https://oauth.yandex.ru/authorize}
YANDEX_TOKEN_ENDPOINT=${YANDEX_TOKEN_ENDPOINT:-https://oauth.yandex.ru/token}
YANDEX_INFO_ENDPOINT=${YANDEX_INFO_ENDPOINT:-https://login.yandex.ru/info}
YANDEX_REDIRECT_URI=${YANDEX_REDIRECT_URI:-}

kvx_now() {
  date +%s
}

kvx_json_quote() {
  printf '%s' "$1" | jq -Rs .
}

kvx_random_id() {
  value="$(dd if=/dev/urandom bs=32 count=1 2>/dev/null | base64 2>/dev/null | tr -dc 'A-Za-z0-9' | cut -c1-48)"
  if [ -z "$value" ]; then
    value="$(printf '%s:%s:%s' "$(kvx_now)" "$$" "${REMOTE_ADDR:-}" | sha256sum | awk '{print substr($1,1,48)}')"
  fi
  printf '%s' "$value"
}

kvx_save_conf_value() {
  key="$1"
  value="$2"
  tmp="$KVX_CONF.tmp"
  mkdir -p "$(dirname "$KVX_CONF")" 2>/dev/null || true
  [ -f "$KVX_CONF" ] || : > "$KVX_CONF"
  quoted="$(printf "%s" "$value" | sed "s/'/'\\\\''/g")"
  found=0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      "$key="*) printf "%s='%s'\n" "$key" "$quoted"; found=1 ;;
      *) printf "%s\n" "$line" ;;
    esac
  done < "$KVX_CONF" > "$tmp"
  [ "$found" = "1" ] || printf "%s='%s'\n" "$key" "$quoted" >> "$tmp"
  mv "$tmp" "$KVX_CONF"
}

kvx_ensure_session_secret() {
  if [ -z "${YANDEX_SESSION_SECRET:-}" ]; then
    YANDEX_SESSION_SECRET="$(kvx_random_id)$(kvx_random_id)"
    kvx_save_conf_value YANDEX_SESSION_SECRET "$YANDEX_SESSION_SECRET"
  fi
}

kvx_urlenc() {
  jq -nr --arg v "$1" '$v|@uri'
}

kvx_urldecode() {
  printf '%s' "$1" | sed 's/+/ /g;s/%21/!/Ig;s/%22/"/Ig;s/%23/#/Ig;s/%24/$/Ig;s/%25/%/Ig;s/%26/\&/Ig;s/%27/'"'"'/Ig;s/%28/(/Ig;s/%29/)/Ig;s/%2A/*/Ig;s/%2B/+/Ig;s/%2C/,/Ig;s/%2D/-/Ig;s/%2E/./Ig;s/%2F/\//Ig;s/%3A/:/Ig;s/%3B/;/Ig;s/%3D/=/Ig;s/%3F/?/Ig;s/%40/@/Ig;s/%5B/[/Ig;s/%5D/]/Ig;s/%5F/_/Ig;s/%7B/{/Ig;s/%7D/}/Ig;s/%7E/~/Ig;s/%20/ /Ig'
}

kvx_param() {
  key="$1"
  printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | awk -F= -v k="$key" '$1 == k {print substr($0, length(k) + 2); exit}'
}

kvx_html_escape() {
  printf '%s' "$1" | sed 's/\&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

kvx_safe_return() {
  clean="$(printf '%s' "${1:-/}" | tr -d '\r\n')"
  case "$clean" in
    ""|//*) printf '/' ;;
    /*) printf '%s' "$clean" ;;
    *) printf '/' ;;
  esac
}

kvx_public_base() {
  host="${HTTP_X_FORWARDED_HOST:-${HTTP_X_ORIGINAL_HOST:-${HTTP_HOST:-}}}"
  host="$(printf '%s' "$host" | sed 's/,.*//' | tr -cd 'A-Za-z0-9.:-')"
  [ -n "$host" ] || host="localhost"
  printf 'https://%s' "$host"
}

kvx_redirect_uri() {
  if [ -n "${YANDEX_REDIRECT_URI:-}" ]; then
    printf '%s' "$YANDEX_REDIRECT_URI"
  else
    printf '%s/oauth-yandex-callback.sh' "$(kvx_public_base)"
  fi
}

kvx_oauth_ready() {
  [ "${YANDEX_OAUTH_ENABLED:-0}" = "1" ] || return 1
  [ -n "${YANDEX_CLIENT_ID:-}" ] || return 1
  [ -n "${YANDEX_CLIENT_SECRET:-}" ] || return 1
  [ -n "${YANDEX_ALLOWED_PHONES:-}" ] || return 1
  return 0
}

kvx_phone_normalize() {
  phone="$(printf '%s' "$1" | tr -d ' .()-')"
  case "$phone" in
    8??????????) phone="+7${phone#8}" ;;
    7??????????) phone="+$phone" ;;
  esac
  printf '%s' "$phone"
}

kvx_phone_allowed() {
  phone="$(kvx_phone_normalize "$1")"
  [ -n "$phone" ] || return 1
  old_ifs="$IFS"
  IFS=',; '
  set -- ${YANDEX_ALLOWED_PHONES:-}
  IFS="$old_ifs"
  for allowed do
    [ -n "$allowed" ] || continue
    [ "$(kvx_phone_normalize "$allowed")" = "$phone" ] && return 0
  done
  return 1
}

kvx_oauth_sign() {
  kvx_ensure_session_secret
  printf '%s:%s' "$YANDEX_SESSION_SECRET" "$1" | sha256sum | awk '{print $1}'
}

kvx_cookie_value() {
  name="$1"
  printf '%s' "${HTTP_COOKIE:-}" | tr ';' '\n' | sed 's/^[[:space:]]*//' | awk -F= -v k="$name" '$1 == k {print substr($0, length(k) + 2); exit}'
}

kvx_session_create() {
  phone="$1"
  login="$2"
  uid="$3"
  kvx_ensure_session_secret
  mkdir -p "$KVX_OAUTH_SESSION_DIR"
  chmod 0700 "$KVX_OAUTH_DIR" "$KVX_OAUTH_SESSION_DIR" 2>/dev/null || true
  sid="$(kvx_random_id)"
  now="$(kvx_now)"
  ttl="${YANDEX_SESSION_TTL_SEC:-2592000}"
  case "$ttl" in
    ''|*[!0-9]*) ttl=2592000 ;;
  esac
  [ "$ttl" -ge 3600 ] 2>/dev/null || ttl=3600
  [ "$ttl" -le 31536000 ] 2>/dev/null || ttl=31536000
  expires="$((now + ttl))"
  jq -n \
    --arg sid "$sid" \
    --arg phone "$phone" \
    --arg login "$login" \
    --arg uid "$uid" \
    --arg remote "${REMOTE_ADDR:-}" \
    --argjson created_at "$now" \
    --argjson expires_at "$expires" \
    '{sid:$sid,phone:$phone,login:$login,uid:$uid,remote_addr:$remote,created_at:$created_at,expires_at:$expires_at}' > "$KVX_OAUTH_SESSION_DIR/$sid.json"
  printf '%s.%s' "$sid" "$(kvx_oauth_sign "$sid")"
}

kvx_session_valid() {
  cookie="$(kvx_cookie_value "$KVX_OAUTH_COOKIE")"
  [ -n "$cookie" ] || return 1
  sid="${cookie%%.*}"
  sig="${cookie#*.}"
  [ "$sid" != "$cookie" ] || return 1
  printf '%s' "$sid" | grep -Eq '^[A-Za-z0-9]{16,80}$' || return 1
  printf '%s' "$sig" | grep -Eq '^[0-9a-f]{64}$' || return 1
  [ "$(kvx_oauth_sign "$sid")" = "$sig" ] || return 1
  session_file="$KVX_OAUTH_SESSION_DIR/$sid.json"
  [ -s "$session_file" ] || return 1
  now="$(kvx_now)"
  expires="$(jq -r '.expires_at // 0' "$session_file" 2>/dev/null || echo 0)"
  case "$expires" in
    ''|*[!0-9]*) expires=0 ;;
  esac
  if [ "$expires" -lt "$now" ] 2>/dev/null; then
    rm -f "$session_file" 2>/dev/null || true
    return 1
  fi
  KVX_AUTH_PHONE="$(jq -r '.phone // ""' "$session_file" 2>/dev/null || true)"
  KVX_AUTH_LOGIN="$(jq -r '.login // ""' "$session_file" 2>/dev/null || true)"
  KVX_AUTH_UID="$(jq -r '.uid // ""' "$session_file" 2>/dev/null || true)"
  export KVX_AUTH_PHONE KVX_AUTH_LOGIN KVX_AUTH_UID
  return 0
}

kvx_state_create() {
  return_to="$(kvx_safe_return "$1")"
  redirect_uri="$2"
  mkdir -p "$KVX_OAUTH_STATE_DIR"
  chmod 0700 "$KVX_OAUTH_DIR" "$KVX_OAUTH_STATE_DIR" 2>/dev/null || true
  state="$(kvx_random_id)"
  now="$(kvx_now)"
  expires="$((now + 600))"
  jq -n \
    --arg state "$state" \
    --arg return_to "$return_to" \
    --arg redirect_uri "$redirect_uri" \
    --arg remote "${REMOTE_ADDR:-}" \
    --argjson created_at "$now" \
    --argjson expires_at "$expires" \
    '{state:$state,return_to:$return_to,redirect_uri:$redirect_uri,remote_addr:$remote,created_at:$created_at,expires_at:$expires_at}' > "$KVX_OAUTH_STATE_DIR/$state.json"
  printf '%s' "$state"
}

kvx_state_read_and_delete() {
  state="$1"
  printf '%s' "$state" | grep -Eq '^[A-Za-z0-9]{16,80}$' || return 1
  state_file="$KVX_OAUTH_STATE_DIR/$state.json"
  [ -s "$state_file" ] || return 1
  now="$(kvx_now)"
  expires="$(jq -r '.expires_at // 0' "$state_file" 2>/dev/null || echo 0)"
  case "$expires" in
    ''|*[!0-9]*) expires=0 ;;
  esac
  if [ "$expires" -lt "$now" ] 2>/dev/null; then
    rm -f "$state_file" 2>/dev/null || true
    return 1
  fi
  cat "$state_file"
  rm -f "$state_file" 2>/dev/null || true
  return 0
}

kvx_html_error() {
  title="$1"
  detail="$2"
  printf 'Content-Type: text/html; charset=utf-8\r\n'
  printf 'Cache-Control: no-store\r\n\r\n'
  printf '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>%s</title><style>body{font:15px system-ui;margin:32px;color:#17212b}main{max-width:680px;margin:auto;border:1px solid #d8e0e8;border-radius:16px;padding:20px;background:#fff;box-shadow:0 8px 28px #0001}h1{margin-top:0}.muted{color:#5f7080;line-height:1.45}a{color:#0b5cad}</style><main><h1>%s</h1><p class="muted">%s</p><p><a href="/">Вернуться в пульт</a></p></main>' \
    "$(kvx_html_escape "$title")" "$(kvx_html_escape "$title")" "$(kvx_html_escape "$detail")"
}
